(function($){
	$.fn.flexBackground = function(options){
	'use strict';

		/**------------------ SETTING PARAMETERS ------------------**/
		
		var height;
		var width;
		
		var numberOfPoints = 200;
		var radius = 1;
		var interval = 50;
		var color = {r:256, g:256, b:256};
		
		var config = {};
		if(options){
			$.extend(config, options);
		}
		
		
		
		
		/**------------------ BEGIN FUNCTION BODY ------------------**/
		
		
		
			var selector = $(this);
			var selectorCan = $(this).find("canvas");
			
			if(config.numberOfPoints)
				numberOfPoints = parseInt(config.numberOfPoints, 10);
			
			if(config.radius)
				radius = parseInt(config.radius, 10);
			
			if(config.interval)
				interval = parseInt(config.interval, 10);
			
			if(config.color){
				var regExp = new RegExp("\\d+", "g");
				color.r = regExp.exec(config.color);
				color.g = regExp.exec(config.color);
				color.b = regExp.exec(config.color);
			}
			
			
			/**------------------------------------------------  SETTING FUNCTIONS ------------------------------------------------- **/

			width = selector.width();
			height = selector.height();
			
			selectorCan.attr('height', height);
			selectorCan.attr('width', width);
			
			var canvas = selectorCan[0];
			var ctx = canvas.getContext("2d");

			var tempx = 60;
			var tempy = 60;
			
			
			function drawStar(posX, posY){
				ctx.fillStyle = "rgba(" + color.r + "," + color.g + "," + color.b + ", .7)";
				ctx.beginPath();
				ctx.arc(posX, posY, radius/2, 0, Math.PI*2, true);
				ctx.closePath();
				ctx.fill();
				
				ctx.fillStyle = "rgba(" + color.r + "," + color.g + "," + color.b + ", .2)";
				ctx.beginPath();
				ctx.arc(posX, posY, radius, 0, Math.PI*2, true);
				ctx.closePath();
				ctx.fill();
				
				ctx.fillStyle = "rgba(" + color.r + "," + color.g + "," + color.b + ", .1)";
				ctx.beginPath();
				ctx.arc(posX, posY, radius*1.5, 0, Math.PI*2, true);
				ctx.closePath();
				ctx.fill();

			}
			
						
			var starX = new Array();			
			var starY = new Array();	
			var destStarX = new Array();			
			var destStarY = new Array();	
			var timeOut = 1;
			
			function refresh(){
				width = selector.width();
				height = selector.height();
				
				selectorCan.attr('height', height);
				selectorCan.attr('width', width);

				for(var i = 0; i < numberOfPoints; i++){
					starX[i] = Math.random()*width;
					starY[i] = Math.random()*height;
				}

				for(var i = 0; i < numberOfPoints; i++){
					destStarX[i] = Math.random()*width;
					destStarY[i] = Math.random()*height;
				}
			}

			
			function setBackground(){
					ctx.clearRect(0, 0, width, height);
					for(var i =0; i < numberOfPoints; i++){
						tempx = starX[i] - (starX[i] - destStarX[i])*timeOut/400;
						tempy = starY[i] - (starY[i] - destStarY[i])*timeOut/400;
						drawStar(tempx, tempy);
					}
					
					if(timeOut < 400){
						timeOut++;
					}else{
						timeOut = 1;
						refreshPosition();
					}
			}
			
			function refreshPosition(){
				for(var i = 0; i < 200; i++){
					starX[i] = destStarX[i];
					starY[i] = destStarY[i];
				}
				
				for(var i = 0; i < 200; i++){
					destStarX[i] = Math.random()*width;
					destStarY[i] = Math.random()*height;
				}
			}
			
			refresh();
			setInterval(setBackground, interval);
			
			$(window).resize(function(){
				refresh();
			})

	}
})(jQuery)
