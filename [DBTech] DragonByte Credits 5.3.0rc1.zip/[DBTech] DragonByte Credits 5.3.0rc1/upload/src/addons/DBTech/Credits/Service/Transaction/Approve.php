<?php

namespace DBTech\Credits\Service\Transaction;

use DBTech\Credits\Entity\Transaction;

/**
 * Class Approve
 *
 * @package DBTech\Credits\Service\Transaction
 */
class Approve extends \XF\Service\AbstractService
{
	/**
	 * @var Transaction
	 */
	protected $transaction;
	
	/**
	 * @var bool
	 */
	protected $notify = true;
	
	/**
	 * @var int
	 */
	protected $notifyRunTime = 3;
	
	/**
	 * @var string
	 */
	protected $reason = '';
	
	/**
	 * Approve constructor.
	 *
	 * @param \XF\App $app
	 * @param Transaction $transaction
	 */
	public function __construct(\XF\App $app, Transaction $transaction)
	{
		parent::__construct($app);
		$this->transaction = $transaction;
	}
	
	/**
	 * @return Transaction
	 */
	public function getUpdate()
	{
		return $this->transaction;
	}
	
	/**
	 * @param $notify
	 */
	public function setNotify($notify)
	{
		$this->notify = (bool)$notify;
	}
	
	/**
	 * @param $time
	 */
	public function setNotifyRunTime($time)
	{
		$this->notifyRunTime = $time;
	}
	
	/**
	 * @param $reason
	 */
	public function setReason($reason)
	{
		$this->reason = $reason;
	}
	
	/**
	 * @return bool
	 * @throws \LogicException
	 * @throws \Exception
	 * @throws \XF\PrintableException
	 */
	public function approve()
	{
		if ($this->transaction->transaction_state == 'moderated')
		{
			$this->transaction->transaction_state = 'visible';
			$this->transaction->save();
			
			$this->onApprove();
			return true;
		}
		
		return false;
	}
	
	/**
	 * @return bool
	 * @throws \LogicException
	 * @throws \Exception
	 * @throws \XF\PrintableException
	 */
	public function reject()
	{
		if ($this->transaction->transaction_state == 'moderated')
		{
			$this->transaction->delete();
			
			$this->onReject();
			return true;
		}
		
		return false;
	}
	
	/**
	 *
	 */
	protected function onApprove()
	{
		if ($this->notify)
		{
			$transactionRepo = $this->getTransactionRepo();
			$transactionRepo->sendModeratorActionAlert($this->transaction, 'approve', $this->reason);
		}
	}
	
	/**
	 * @throws \Exception
	 */
	protected function onReject()
	{
		$eventTriggerRepo = $this->getEventTriggerRepo();
		$handler = $eventTriggerRepo->getHandler($this->transaction->event_trigger_id);
		
		$handler->onReject($this->transaction);
		
		if ($this->notify)
		{
			$transactionRepo = $this->getTransactionRepo();
			$transactionRepo->sendModeratorActionAlert($this->transaction, 'reject', $this->reason);
		}
	}
	
	/**
	 * @return \DBTech\Credits\Repository\Transaction|\XF\Mvc\Entity\Repository
	 */
	protected function getTransactionRepo()
	{
		return $this->repository('DBTech\Credits:Transaction');
	}
	
	/**
	 * @return \DBTech\Credits\Repository\EventTrigger|\XF\Mvc\Entity\Repository
	 */
	protected function getEventTriggerRepo()
	{
		return $this->repository('DBTech\Credits:EventTrigger');
	}
}