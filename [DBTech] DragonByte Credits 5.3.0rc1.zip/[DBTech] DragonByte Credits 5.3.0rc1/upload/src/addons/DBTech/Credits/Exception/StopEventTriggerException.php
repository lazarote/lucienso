<?php

namespace DBTech\Credits\Exception;

/**
 * Class StopEventTriggerException
 *
 * @package DBTech\Credits\Exception
 */
class StopEventTriggerException extends \Exception
{
}