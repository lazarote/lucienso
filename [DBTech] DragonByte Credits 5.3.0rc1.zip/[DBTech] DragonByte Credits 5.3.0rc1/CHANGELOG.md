# Changelog

#### v5.3.0rc1

* **Feature:** Smart event negation (beta) *2019-04-24*
* **Feature:** Event transaction moderation *2019-04-24*
* **Feature:** AdminCP transaction list / transaction view now displays the transaction state *2019-04-24*
* **Change:** Editing posts will no longer produce an alert *2019-04-24*
* **Change:** Rework the way Interest, Paycheck and Taxation events are applied in an attempt to reduce race conditions where events would apply into the future *2019-04-24*
* **Change:** AdminCP transaction list now hides "Skipped" and "Skipped (maximum applications)" by default *2019-04-24*
* **Change:** Renamed the Credits alert content types for consistency *2019-04-24*
* **Change:** Number boxes in the AdminCP now use the XF spinbox style *2019-04-24*
* **Fix:** It was not possible to select "both users" for the Taxation setting for certain events *2019-04-24*
* **Fix:** The taxation feature did not function as described in the explanation text *2019-04-24*
* **Fix:** Transaction messages would not respect the forum's censoring *2019-04-24*
* **Fix:** Resolved a server error when limiting the Trophy event *2019-04-24*
* **Fix:** Ensure thread owners won't trigger their own Reply events *2019-04-24*


#### v5.3.0b3

* **Feature:** Added FontAwesome icons for right-side menu entries *2019-03-28*
* **Feature:** Added ability to disable the navbar text for right-side menu entries *2019-03-28*
* **Change:** Updated the style of right-side menu entries to better fit into the surrounding entries *2019-03-28*


#### v5.3.0b2

* **Change:** Switch various "delete" actions to use XF 2.1's deletion plugin *2019-03-23*
* **Fix:** Fix issue where transaction log search in the AdminCP would always return no results *2019-03-23*
* **Fix:** The "Filter" drop-down will no longer produce a server error if no valid events were found *2019-03-23*
* **Fix:** Fix an issue with the Purchase Transaction table that could lead to server errors *2019-03-23*
* **Fix:** Prevent server error when integrating with Shop but the Shop navigation is missing *2019-03-23*


#### v5.3.0b1

* **Feature:** Rebuild transactions *2019-03-15*
* **Feature:** Adjust, Donate, Redeem and Transfer events now have dedidcated log tables to aid in rebuilds *2019-03-15*
* **Feature:** Add missing (unused) permission *2019-03-15*
* **Feature:** Certain permissions are now available to assign to individual moderators as moderator permissions *2019-03-15*
* **Change:** Internally rename some permissions to follow XF standards *2019-03-15*
* **Change:** Ensure only valid users are displayed in the Richest Users widget *2019-03-15*
* **Fix:** Fix an issue causing reduced performance on the Transactions page *2019-03-15*


#### v5.2.1

* **Feature:** React / Reacted event triggers *2019-03-09*


#### v5.2.0

* **Feature:** Add donation reason to donation event alert / push message *2019-02-06*
* **Change:** Updated widgets to feature avatars and a cleaner design *2019-02-06*
* **Fix:** Fix events reverting incorrectly when an entity is saved multiple times in succession *2019-02-06*
* **Fix:** Update FontAwesome icon for Charge tag to be compatible with XF 2.1 FontAwesome changes *2019-02-06*
* **Fix:** Fixed Shop version number check in the installer *2019-02-06*


#### v5.1.0rc3

* **Change:** Added install-upgrade.json file *2018-11-05*
* **Change:** Currency formatting is now applied more universally *2018-11-05*
* **Fix:** The editor.js file is now no longer loaded even on pages where the editor isn't loaded *2018-11-05*
* **Fix:** The "Richest user" widget now respects the limits in the widget settings *2018-11-05*
* **Fix:** The "Frequency" setting for events would cause too many events to be skipped *2018-11-05*


#### v5.1.0rc2

* **Feature:** You can now search for source user and target user separately when searching transaction logs *2018-10-04*
* **Feature:** The CHARGE BBCode now uses an overlay to prompt users for the amount they wish to charge. Only works if the BBCode is still called "CHARGE" *2018-10-19*
* **Fix:** The transaction log searcher in the AdminCP now works as intended *2018-10-04*


#### v5.1.0b7

* **Feature:** New permission: Trigger events - whether user can trigger any event *2018-09-24*
* **Change:** Removed "Block all cancelable event triggers" permission *2018-09-24*
* **Change:** The time zone used for calculating "today" when awarding daily credits has been normalised to use the "Guests' time zone" setting *2018-09-18*
* **Change:** [CHARGE] BBCode tags are now more resilient to post content changes *2018-09-17*
* **Fix:** Fixed an issue with merging or deleting users as a result of a removed database table *2018-09-18*
* **Fix:** Fixed an issue where the currency popup would display an error if no Donate, Adjust, Purchase, Redeem or Transfer events exist in the system *2018-09-17*


#### v5.1.0b6

* **Fix:** Fixed an issue where editing an existing event could erase the contents of the "event_trigger_id" column *2018-09-17*
* **Fix:** Fixed an issue where guests would be unable to view threads and perform certain other actions *2018-09-17*
* **Fix:** Fixed an issue where you would be unable to adjust your own account *2018-09-16*
* **Fix:** Fixed a phrase issue with the alert for Adjust events *2018-09-16*


#### v5.1.0b5

* **Fix:** Fixed an issue preventing adding new events, or saving existing events in a clean install of v5.1 *2018-09-16*


#### v5.1.0b4

* **Fix:** Fixed an issue where the "Frequency" setting in Daily, Interest, Paycheck and Transaction events would not work as intended *2018-09-14*


#### v5.1.0b3

* **Feature:** Individual currencies can now be hidden from the postbit *2018-09-13*
* **Feature:** Individual currencies can now be displayed in the "member dropdown" (A.K.A. "visitor menu") when clicking your own user name *2018-09-13*
* **Change:** Fresh installations will now apply sensible permission defaults *2018-09-13*
* **Change:** The transaction log searcher sort orders can now be extended via a new code event *2018-09-13*
* **Change:** The "Upload" event's integration with attachments has been changed to take advantage of a new feature in XF 2.0.10 *2018-09-13*
* **Change:** This mod now requires XenForo 2.0.10 to install & run *2018-09-13*
* **Fix:** The "Member Stats" integration wasn't working *2018-09-13*


#### v5.1.0b2

* **Change:** Greatly reduced the number of queries executed when viewing a thread *2018-09-01*
* **Fix:** (Hopefully) fixed an issue that could produce a server error when upgrading from v5.0.x *2018-09-01*


#### v5.1.0b1

* **Feature:** New user group permission: Bypass Charge tags *2018-08-31*
* **Change:** Completely rewrote the modification to be a native XenForo 2 modification *2018-08-31*
* **Change:** Removed the "Manage Event Triggers" page, and moved its settings into the XenForo Options *2018-08-31*
* **Change:** If a user attempts to redeem a code that is invalid, they will now receive a message saying so *2018-08-31*
* **Fix:** Fixed permissions issues with viewing transaction log entries *2018-08-31*


#### v5.0.3

* **Fix:** Fixed an issue where the Punish and Warned events could prevent a warning from being given in certain scenarios *2018-07-11*


#### v5.0.2-hotfix2

* Potential fix for template modification *2018-07-06*


#### v5.0.2-hotfix1

* /** *2018-07-06*
* * @param $product *2018-07-06*
* * @param $version *2018-07-06*
* * @param array $opts *2018-07-06*
* */ *2018-07-06*
* public function release($product, $version, $opts = ['dir' => NULL]) *2018-07-06*
* { *2018-07-06*
* $ds = DIRECTORY_SEPARATOR; *2018-07-06*


#### v5.0.2

* *Fix:* Fixed an issue where the addon would not correctly detect it was in the AdminCP *2018-07-05*
* *Fix:* Moderated threads being approved would award the Thread event credits twice *2018-07-05*
* *Fix:* Fix for Post and Reply event negations triggering twice or not correctly *2018-07-05*
