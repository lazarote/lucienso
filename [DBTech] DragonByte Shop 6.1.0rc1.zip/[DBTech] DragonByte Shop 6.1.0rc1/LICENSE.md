SOFTWARE LICENSE AGREEMENT

This Product is licensed, not sold, to You for use only under the terms of this license. The Licensor, DRAGONBYTE TECHNOLOGIES LTD., reserves all rights not expressly granted to You.

The License herein is comprised of two parts: a license to obtain, and a license to use. Please read the distinction carefully.

1. SCOPE OF LICENSES. This license is non-transferable. You may not rent, lease, sell, redistribute, sub-license, or transfer the Product without the express permission of the Licensor.

2. LICENSE TO OBTAIN. Until the expiry date listed in your account, You are entitled to obtain any version of the Product which may be available from the Licensor.

3. LICENSE TO USE. Unless and until You choose to terminate this license, You are entitled to, with any version of the Product you have obtained pursuant to this license:

   a. Run a single instance of the Product on a single installation of the forum software on one domain which is accessible to the public;
   
   AND
   
   b.  You may create additional test installations for the purpose of testing the Software. Any test installation of this kind must be password protected, installed at a URL that makes the testing purpose clear, not used for production purposes and access to it must be limited to You and Your website staff.

   You may not use the Product on a different domain from the domain on which it is licensed. You must, prior to obtaining the Product, indicate which domain the Product will be licensed on.

   You may not change the domain on the Product is licensed without the express permission of the Licensor. If the Licensor makes available a tool by which You are able to update the registration of a domain for a license, that shall be the express permission of the Licensor to transfer that license to that domain.

   You may continue to use any version of the Product that has been made available to you under the LICENSE TO OBTAIN even after the expiry date listed in your account has passed.

4. NO WARRANTY. The Product is provided AS-IS, with no warranty, claim of fitness for purpose, or any guarantee of any kind, whether implied, explicit, or statutory, as to suitability, capability, or anything else. The Licensor does not guarantee that any discovered errors will be corrected or that the Product will continue to be maintained. You are entirely responsible for ensuring that the Product is satisfactorily functional for the purpose to which You put it.

5. LIMITATION OF LIABILITY. Under no circumstances shall the Licensor be responsible for any damages, of any kind, which may result from Your use of the Product, however caused, even if the Licensor has been advised of the risk of those damages occurring. In no event shall the liability for the use of the Product exceed the price that You paid for this license and any renewal thereof.

6. CHOICE OF LAWS. The laws of Scotland govern this license and your use of the Product. The Scottish courts shall have exclusive jurisdiction to settle any claim or dispute which might arise out of or in connection with this License.

7. TERMINATION. At any time, you may choose to terminate this License by ceasing use of the Product, destroying all copies of the Product you have obtained, and providing notice in writing to the Licensor.
   
   If, at any time, Your payment for the Product is reversed, charged-back, or otherwise disputed, or a voluntary refund is made to you, this License will immediately terminate. You will have no further entitlement of any kind to obtain or use the Product, and you must destroy all copies of the Product you have obtained.

8. NON-CONFLICT WITH DISTRIBUTION TERMS OF USE. Nothing in this License shall override the Terms of Service put in place by the Licensor for the use of its distribution platform. If you do anything to violate those Terms of Service, your License to Obtain granted under this License shall immediately terminate and you shall have no further entitlement to acquire the Product. Your license to use the Product, however, shall not be affected, unless otherwise specified in this License or in the Terms of Service.