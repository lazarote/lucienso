# Changelog

#### v6.1.0rc1

* **Feature:** Discarding a purchase now logs additional information about why the purchase was discarded *2019-04-24*
* **Feature:** Added "{tagline}" and "{description}" as phrase variables for various notification phrases *2019-04-24*
* **Feature:** Pricing label is now a button in List view *2019-04-24*
* **Feature:** Added purchase button in Grid view *2019-04-24*
* **Feature:** Transfers are now logged in the transaction log *2019-04-24*
* **Feature:** Ability to disable item icon scaling *2019-04-24*
* **Feature:** Ability to change an item's configuration in the AdminCP *2019-04-24*
* **Change:** Shop transactions inserted into DB Credits will no longer be "strikethrough" in the transaction log going forward *2019-04-24*
* **Change:** Number boxes in the AdminCP now use the XF spinbox style *2019-04-24*
* **Change:** Updated various notification phrases to put any custom messages in [QUOTE] tags *2019-04-24*
* **Change:** Added various "_nomessage" phrases for notification phrases where this is relevant *2019-04-24*
* **Change:** Updated "description" to "tagline" in a few phrases *2019-04-24*
* **Change:** Standardise various spellings of "colo(u)r" to default to US English *2019-04-24*
* **Change:** Attempting to add an item to cart that the user cannot purchase will now display an error message rather than silently discarding the item from the user's cart *2019-04-24*
* **Change:** During purchase, attempting to gift an item that cannot be gifted will now display an error message rather than silently discarding the item from the user's cart *2019-04-24*
* **Change:** Replaced date created / date updated with stock / purchases in List and Grid view *2019-04-24*
* **Change:** AutoBump cron now runs every hour *2019-04-24*
* **Change:** Changed the way user title styles are previewed *2019-04-24*
* **Fix:** Adding a new purchase via the AdminCP would not work as intended *2019-04-24*
* **Fix:** Fix content change integration *2019-04-24*
* **Fix:** Fix missing bookmark template *2019-04-24*
* **Fix:** Gift messages would not respect the forum's censoring *2019-04-24*
* **Fix:** Transactions were not logged correctly if the currency was integrated with DragonByte Credits *2019-04-24*
* **Fix:** The "Shadow" value in the various configuration notice phrases was wrong *2019-04-24*
* **Fix:** Fixed an issue where the default admin config would not work as intended for certain item types *2019-04-24*
* **Fix:** The "Custom Item" item type will no longer display empty blocks in configuration notices / gift conversations if there are no defined fields *2019-04-24*
* **Fix:** When displaying the configuration list in a conversation, correctly say "not set" if the corresponding item setting is turned off, even if a configured value exists internally *2019-04-24*
* **Fix:** Fixed server error when attempting to edit in the AdminCP a purchase for a non-configurable item *2019-04-24*
* **Fix:** Fixed "{name}" showing up in the news feed instead of the user's name when a new review is written *2019-04-24*
* **Fix:** Only display active item types in the User Criteria (such as trophies) *2019-04-24*
* **Fix:** The "Start conversation on gift" option is now actually implemented *2019-04-24*
* **Fix:** Bankable currencies are now more accurately filtered from the Bank page *2019-04-24*
* **Fix:** Gift alert was not added when purchasing item as a gift *2019-04-24*
* **Fix:** Users can no longer gift items to themselves *2019-04-24*
* **Fix:** New Lottery History entries were not being inserted *2019-04-24*
* **Fix:** Items that were activated during purchase should now take effect immediately, unless those items are only giftable *2019-04-24*
* **Fix:** Fixed a template error with the news feed entry for an item review *2019-04-24*
* **Fix:** Fixed a server error in the purchase settings page related to checking whether an item has been gifted *2019-04-24*
* **Fix:** It is now possible to gift an item to another user during purchase even if the item is Exclusive or Unique, and the buyer would not be able to buy the item for themselves *2019-04-24*
* **Fix:** The Unique and Exclusive flags are now checked for recipient users during gifting and trading *2019-04-24*
* **Fix:** The correct user will now be charged for the purchase when gifting an item during purchase *2019-04-24*
* **Fix:** Thread Highlight (Pre-Defined) was not loading the thread information into the configuration view template *2019-04-24*
* **Fix:** User title style classes are now properly applied when running older versions of PHP *2019-04-24*
* **Fix:** The news feed item, alert and push notifications for a reaction to a trade post would create a server error *2019-04-24*
* **Fix:** Do not allow changing the quantity of Exclusive or Unique items during checkout *2019-04-24*
* **Fix:** Fixed an issue where the "Forum statistics" cron would produce a server error if the latest valid user had purchased any item *2019-04-24*
* **Fix:** Prevent a scenario in which it's possible for multiple copies of a unique item to be added to the cart *2019-04-24*
* **Fix:** Gift and Trade events were not logged correctly in the transaction log *2019-04-24*
* **Fix:** Fixed an issue where the configured color for the "User Title Style" would not show in the configuration information window *2019-04-24*
* **Fix:** Fixed an issue where the "Preview" field would be empty for the two "User Title Style" item types if the user did not have a custom user title *2019-04-24*
* **Fix:** The check for unique items now excludes items currently in cart. This means if you change the unique flag after an item is already in a user's cart, they will still be able to complete that particular order. *2019-04-24*


#### v6.1.0b5

* **Feature:** Added FontAwesome icons for right-side menu entries *2019-03-28*
* **Feature:** Added ability to disable the navbar text for right-side menu entries *2019-03-28*
* **Change:** Updated the style of right-side menu entries to better fit into the surrounding entries *2019-03-28*


#### v6.1.0b4

* **Fix:** Fix an issue where it was not possible to edit a user's currency in the AdminCP *2019-03-23*
* **Fix:** The "Filter" drop-down will no longer produce a server error if no valid items were found *2019-03-23*
* **Fix:** Added missing template *2019-03-23*
* **Fix:** Fixed an issue where you could choose more than the intended amount of lottery numbers *2019-03-23*
* **Fix:** Fixed an issue where uninstalling the add-on could leave some residual data *2019-03-23*


#### v6.1.0b3

* **Feature:** New setting for controlling item icon dimensions *2019-03-15*
* **Feature:** Add "items sold" and "stock" to the item overview sidebar *2019-03-15*
* **Feature:** New option for hiding an item from the shop list *2019-03-15*
* **Change:** Only valid users are displayed in the Richest User widget *2019-03-15*
* **Change:** Rework username style and user title style to use CSS instead of inline styles *2019-03-15*
* **Fix:** Fixed missing phrase *2019-03-15*
* **Fix:** Fix thread title showing the raw style value rather than the actual stylised title *2019-03-15*
* **Fix:** Make sure the canPurchase check takes stock into account *2019-03-15*
* **Fix:** Validate stock when adding items to cart & when completing a purchase *2019-03-15*


#### v6.1.0b2

* **Feature:** The trade creator can now modify the trade before the other person accepts the invitation *2019-03-08*
* **Fix:** Fix currency trade offer not displaying on edit *2019-03-08*
* **Fix:** Fixed a potential issue with the Beta 1 upgrade if the Trade or Trade Offer tables did not exist *2019-03-08*
* **Fix:** Fixed a potential error from occurring when deleting a user *2019-03-08*
* **Fix:** Fix issue where setting prefixes via inline moderation would cause a server error *2019-03-08*


#### v6.1.0b1

* **Feature:** Trade system *2019-03-04*
* **Feature:** Trade discussions *2019-03-04*
* **Feature:** New currency setting: Can be traded *2019-03-04*
* **Change:** Changed certain Alert moderator actions around to make them display even if the content is no longer viewable *2019-03-04*
* **Fix:** Fix the phrase used when a currency is set to display in the navbar *2019-03-04*
* **Fix:** Fix a potential database error if an admin tried to add an item with a title that's too long *2019-03-04*
* **Fix:** Fix possibility of DB error when discarding items *2019-03-04*
* **Fix:** Fix issue where turning off steal loss would break steal *2019-03-04*
* **Fix:** Fix issue where the wrong user gets credited with the sale price *2019-03-04*


#### v6.1.0a4

* **Feature:** Lottery *2019-02-15*
* **Change:** Converted some database columns to JSON *2019-02-15*


#### v6.1.0a3

* **Feature:** Steal *2019-02-13*
* **Change:** The "Autoplay" setting for the "Profile Music" item is now only controlled via widget settings *2019-02-13*
* **Change:** Slimmed the UI for configuring shop settings *2019-02-13*
* **Change:** Pruned a bunch of legacy code / templates / settings / phrases *2019-02-13*
* **Fix:** Fixed a typo in the "automatic interest: minimum activity" setting *2019-02-13*


#### v6.1.0a2

* **Feature:** Admin Search support for Categories and Items *2019-02-10*
* **Feature:** Bookmarks and Reactions for Items *2019-02-10*
* **Feature:** Added tracking for how many items each user has created *2019-02-10*
* **Feature:** Added a new Member Stat for displaying how many items each user has created *2019-02-10*
* **Feature:** Added new rebuild tools for purchase counter and item creation counter *2019-02-10*
* **Feature:** What's New integration *2019-02-10*
* **Feature:** Daily statistics for Items Added, Item Reactions, Item Ratings and Purchases *2019-02-10*
* **Feature:** User Search integration for Items Added and Purchases *2019-02-10*
* **Feature:** Author profile for displaying items added *2019-02-10*
* **Feature:** Bank *2019-02-10*
* **Fix:** Username Style item would not work as intended *2019-02-10*
* **Fix:** The navbar tab in any of the "Right" positions would not display due to a renamed "Can view" permission *2019-02-10*


#### v6.1.0a1

* **Feature:** Per-item permissions using XF2's content permissions system *2019-02-03*
* **Feature:** Prefix support for items *2019-02-03*
* **Feature:** Custom fields for items *2019-02-03*
* **Feature:** Full category tree support *2019-02-03*
* **Feature:** Per-category permissions using XF2's content permissions system *2019-02-03*
* **Feature:** Extended item information in the Inventory screen *2019-02-03*
* **Feature:** Items can be added/edited/managed via the front-end *2019-02-03*
* **Feature:** Report system integration *2019-02-03*
* **Feature:** Approval Queue integration *2019-02-03*
* **Feature:** News Feed integration *2019-02-03*
* **Feature:** Inline Moderation integration *2019-02-03*
* **Feature:** Moderator Log integration *2019-02-03*
* **Feature:** Search engine integration *2019-02-03*
* **Feature:** Warning system integration *2019-02-03*
* **Change:** Merged "Shops" and "Categories" into just "categories" *2019-02-03*
* **Change:** Items can only belong to one category (shop), items currently stocked in multiple shops will be duplicated *2019-02-03*
* **Change:** Vastly improved DragonByte Credits integration *2019-02-03*
* **Change:** Items that take a thread ID or post ID in their configuration now also accept a thread or post link *2019-02-03*
* **Change:** Item configuration notification conversations now contain more info, such as a link to the content in question *2019-02-03*
* **Change:** Changed item feeedback into a standard "Review" system *2019-02-03*
* **Change:** Removed the old per-item permissions and access criteria *2019-02-03*
* **Change:** Completely overhauled item management and category management UI *2019-02-03*
