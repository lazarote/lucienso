var DBTechShop = window.DBTechShop || {};

!function($, window, document)
{
	// ################################## --- ###########################################
	DBTechShop.InfiniteScroll = XF.Element.newHandler(
	{
		init: function()
		{
			$grid = this.$target;

			var $scroller = $grid.infiniteScroll({
				button: '.item-button',
				append: '.itemList-item',
				hideNav: '.block-outer--pagination',
				path: '.block-outer--pagination .pageNav-jump--next',
				status: '.item-status',
				history: $grid.data('infinite-scroll-history') ? 'push' : false
			});

			$scroller.on('last.infiniteScroll', function()
			{
				$('.item-status').hide();
				$('.item-loader').hide();
			});

			if ($grid.data('infinite-scroll-click'))
			{
				if ($grid.data('infinite-scroll-after'))
				{
					$scroller.on('load.infiniteScroll', function onPageLoad()
					{
						if ($scroller.data('infiniteScroll').loadCount == $grid.data('infinite-scroll-after'))
						{
							$('.item-loader').show();
							$scroller.infiniteScroll('option', { loadOnScroll: false });
							$scroller.off('load.infiniteScroll', onPageLoad);
						}
					});
				}
				else
				{
					$('.item-loader').show();
					$scroller.infiniteScroll('option', { loadOnScroll: false });
				}
			}
		}
	});

	// ################################## --- ###########################################

	XF.Element.register('dbtech-shop-infinite-scroll', 'DBTechShop.InfiniteScroll');
}
(window.jQuery, window, document);