<?php

namespace DBTech\Shop\Bookmark;

use XF\Bookmark\AbstractHandler;
use XF\Mvc\Entity\Entity;

class Item extends AbstractHandler
{
	public function getContentTitle(Entity $content)
	{
		/** @var \DBTech\Shop\Entity\Item $content */
		
		return \XF::phrase('dbtech_shop_item_x', [
			'title' => $content->title
		]);
	}
	
	/**
	 * @param Entity $content
	 *
	 * @return string
	 */
	public function getContentRoute(Entity $content)
	{
		/** @var \DBTech\Shop\Entity\Item $content */
		
		return 'dbtech-shop';
	}

	/**
	 * @return string
	 */
	public function getCustomIconTemplateName()
	{
		return 'public:dbtech_shop_item_bookmark_custom_icon';
	}
	
	/**
	 * @return array
	 */
	public function getEntityWith()
	{
		$visitor = \XF::visitor();

		return ['Category', 'Category.Permissions|' . $visitor->permission_combination_id, 'User'];
	}
}