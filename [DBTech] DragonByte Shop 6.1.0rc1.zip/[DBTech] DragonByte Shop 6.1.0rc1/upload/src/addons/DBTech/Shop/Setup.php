<?php

namespace DBTech\Shop;

use XF\AddOn\AbstractSetup;
use XF\AddOn\StepRunnerInstallTrait;
use XF\AddOn\StepRunnerUninstallTrait;
use XF\AddOn\StepRunnerUpgradeTrait;
use XF\Db\Schema\Alter;
use XF\Db\Schema\Create;

/**
 * Class Setup
 *
 * @package DBTech\Shop
 */
class Setup extends AbstractSetup
{
	use StepRunnerInstallTrait;
	use StepRunnerUpgradeTrait;
	use StepRunnerUninstallTrait;
	
	
	/**
	 * @param array $errors
	 * @param array $warnings
	 */
	public function checkRequirements(&$errors = [], &$warnings = [])
	{
		$addOns = $this->app->container('addon.cache');
		
		if (array_key_exists('DBTech/Credits', $addOns) && $addOns['DBTech/Credits'] < 905010031)
		{
			$warnings[] = "Your version of DragonByte Credits is not compatible with this version of DragonByte Shop.
			The integration between these two products will not function until you also update DragonByte Credits,
			and may cause errors. Please consider deactivating DragonByte Credits, or upgrade it if an upgrade is available.";
		}
		
		return;
	}
	
	// ################################ INSTALLATION ####################
	
	/**
	 *
	 */
	public function installStep1()
	{
		$sm = $this->schemaManager();
		
		foreach ($this->getTables() AS $tableName => $closure)
		{
			$sm->createTable($tableName, $closure);
		}
	}
	
	/**
	 *
	 */
	public function installStep2()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_user', function(Alter $table)
		{
			$table->addColumn('dbtech_shop_points', 'double')->setDefault(0);
			$table->addColumn('dbtech_shop_purchase', 'mediumblob')->nullable(true);
			$table->addColumn('dbtech_shop_purchases', 'int')->setDefault(0);
			$table->addColumn('dbtech_shop_immunity', 'int')->setDefault(0);
			$table->addColumn('dbtech_shop_pendingtrades', 'int')->setDefault(0);
			$table->addColumn('dbtech_shop_item_count', 'int')->setDefault(0);
			$table->addKey('dbtech_shop_item_count', 'dbtech_shop_item_count');
		});
	}
	
	/**
	 * @throws \XF\Db\Exception
	 */
	public function installStep3()
	{
		$this->query("
			INSERT IGNORE INTO xf_dbtech_shop_bank
				(`user_id`, `currency_id`, `points`)
			SELECT
				`user_id`,
				'1',
				'0.00'
			FROM `xf_user` AS `user`
			ORDER BY `user_id`
		");
		
		$this->query("
			INSERT IGNORE INTO `xf_dbtech_shop_currency`
				(`currency_id`, `title`, `description`, `active`, `display_order`, `table`, `use_table_prefix`, `column`, `use_user_id`, `user_id_column`, `decimals`, `privacy`, `blacklist`, `prefix`, `suffix`, `is_display_currency`, `can_bank`, `can_steal`, `can_trade`, `steal_protect`, `interest`, `customshops`, `per_reply`, `per_thread`, `credits_currency_id`)
			VALUES
				(1, 'Points', X'5468652064656661756C7420447261676F6E427974652053686F702063757272656E63792E', 1, 10, 'user', 1, 'dbtech_shop_points', 1, 'user_id', 0, 2, 1, '', '', 0, 1, 1, 1, -1.00, 0.00, 1, 1, 5, 0)
		");
		
		$this->db()->query("
			REPLACE INTO `xf_dbtech_shop_category`
				(`category_id`,
				`title`,
				`description`,
				`parent_category_id`, `display_order`, `lft`, `rgt`, `depth`,
				`breadcrumb_data`, `item_count`,
				`last_update`, `last_item_title`,
				`last_item_id`, `prefix_cache`, `field_cache`,
				`item_filters`, `require_prefix`, `thread_node_id`,
				`thread_prefix_id`, `item_update_notify`,
				`always_moderate_create`, `always_moderate_update`,
				`min_tags`, `sales`, `sales_amounts`,
				`latest_customer_id`, `latest_sale_id`, `beneficiary`,
				`beneficiary_split`, `num_ratings`, `average_rating`,
				`positive_percent`, `negative_percent`,
				`neutral_percent`)
			VALUES
				(1,
				'Example category',
				'This is an example Shop category. You can manage the Shop categories via the <a href=\"admin.php?dbtech-shop/categories/\" target=\"_blank\">Admin control panel</a>. From there, you can setup more categories or change the Shop options.',
				0, 1, 1, 2, 0, X'613A303A7B7D', 0, 0, '',
				0, X'', X'', X'', 0, 0, 0, 'thread', 0, 0,
				0, 0, NULL, 0, 0, -1, 100, 0, 0, 0, 0, 0)
		");
		
		foreach ($this->getAdminPermissions() AS $permissionId)
		{
			$this->db()->query("
				REPLACE INTO xf_admin_permission_entry
					(user_id, admin_permission_id)
				SELECT user_id, '$permissionId'
				FROM xf_admin_permission_entry
				WHERE admin_permission_id = 'option'
			");
		}
		
		foreach ($this->getDefaultWidgetSetup() AS $widgetKey => $widgetFn)
		{
			$widgetFn($widgetKey);
		}
	}
	
	/**
	 * @param array $stateChanges
	 *
	 * @throws \Exception
	 */
	public function postInstall(array &$stateChanges)
	{
		if ($this->applyDefaultPermissions())
		{
			// since we're running this after data imports, we need to trigger a permission rebuild
			// if we changed anything
			$this->app->jobManager()->enqueueUnique(
				'permissionRebuild',
				'XF:PermissionRebuild',
				[],
				false
			);
		}
		
		/** @var \XF\Service\RebuildNestedSet $service */
		$service = \XF::service('XF:RebuildNestedSet', 'DBTech\Shop:Category', [
			'parentField' => 'parent_category_id'
		]);
		$service->rebuildNestedSetInfo();
		
		/** @var \DBTech\Shop\Repository\ItemPrefix $itemPrefixRepo */
		$itemPrefixRepo = \XF::repository('DBTech\Shop:ItemPrefix');
		$itemPrefixRepo->rebuildPrefixCache();
		
		/** @var \DBTech\Shop\Repository\ItemField $itemFieldRepo */
		$itemFieldRepo = \XF::repository('DBTech\Shop:ItemField');
		$itemFieldRepo->rebuildFieldCache();
	}
	
	
	// ################################ UPGRADES ####################
	
	/**
	 *
	 */
	public function upgrade20160202Step1()
	{
		$sm = $this->schemaManager();
		
		$this->db()->emptyTable('xf_dbtech_shop_shoppingcart');
		
		foreach (['prepurchase', 'postpurchase', 'sellback', 'configure', 'gift', 'discard'] as $key)
		{
			$sm->alterTable('xf_dbtech_shop_item', function(Alter $table) use ($key)
			{
				$table->addColumn($key . '_callback_class', 'varchar', 75)->setDefault('');
				$table->addColumn($key . '_callback_method', 'varchar', 50)->setDefault('');
			});
		}
		
		$sm->alterTable('xf_dbtech_shop_shoppingcart', function(Alter $table)
		{
			$table->dropPrimaryKey();
			$table->dropColumns(['items']);
			$table->addColumn('shopid', 'int')->after('userid');
			$table->addColumn('itemid', 'int')->after('shopid');
			$table->addColumn('quantity', 'int')->setDefault(0)->after('itemid');
			$table->addPrimaryKey(['userid', 'shopid', 'itemid']);
		});
		
		$sm->alterTable('xf_dbtech_shop_purchase', function(Alter $table)
		{
			$table->addColumn('expirydate', 'int')->setDefault(0);
		});
		
		$sm->alterTable('xf_user', function(Alter $table)
		{
			$table->addColumn('dbtech_shop_purchases', 'int')->setDefault(0);
		});
	}
	
	/**
	 * @throws \XF\Db\Exception
	 */
	public function upgrade20160202Step2()
	{
		$this->query("
			UPDATE `xf_dbtech_shop_purchase`
				SET `expirydate` = 1
		");
		
		$this->query("
			UPDATE `xf_user`
				SET `dbtech_shop_purchase` = NULL
		");
		
		$this->query("
			UPDATE `xf_user`
				SET `dbtech_shop_purchases` = (
					SELECT COUNT(*)
					FROM `xf_dbtech_shop_purchase`
					WHERE `userid` = `xf_user`.`user_id`
				)
		");
	}
	
	/**
	 * @throws \XF\Db\Exception
	 */
	public function upgrade20160209Step1()
	{
		foreach ([
					 'threadhighlight' 	=> [
						 'title' 		=> 'Thread Highlight',
						 'description' 	=> 'Purchase the ability to highlight a thread on forum display.',
					 ],
					 'postbithighlight' 	=> [
						 'title' 		=> 'Postbit Highlight',
						 'description' 	=> 'Purchase the ability to highlight your postbit on show thread.',
					 ],
				 ] as $filename => $info)
		{
			$this->query("
				REPLACE INTO `xf_dbtech_shop_itemtype`
					(`itemtypeid`, `title`, `description`)
				VALUES (
					" . $this->db()->quote($filename) . ",
					" . $this->db()->quote($info['title']) . ",
					" . $this->db()->quote($info['description']) . "
				)
			");
		}
	}
	
	/**
	 * @throws \XF\Db\Exception
	 */
	public function upgrade20160308Step1()
	{
		foreach (array(
					 'threadhighlight2' 	=> array(
						 'title' 		=> 'Thread Highlight (Pre-Defined)',
						 'description' 	=> 'Purchase the ability to highlight a thread on forum display.',
					 ),
					 'postbithighlight2' => array(
						 'title' 		=> 'Postbit Highlight (Pre-Defined)',
						 'description' 	=> 'Purchase the ability to highlight your postbit on show thread.',
					 ),
				 ) as $filename => $info)
		{
			$this->query("
				REPLACE INTO `xf_dbtech_shop_itemtype`
					(`itemtypeid`, `title`, `description`)
				VALUES (
					" . $this->db()->quote($filename) . ",
					" . $this->db()->quote($info['title']) . ",
					" . $this->db()->quote($info['description']) . "
				)
			");
		}
		
		// Purge the cache
		\XF::registry()->delete([
			'dbtech_shop_itemtype',
		]);
	}
	
	/**
	 * @throws \XF\Db\Exception
	 */
	public function upgrade20160322Step1()
	{
		$this->query("
			UPDATE `xf_option`
				SET `option_value` = 'a:3:{s:7:\"enabled\";s:1:\"1\";s:13:\"left_position\";s:3:\"end\";s:14:\"right_position\";b:0;}'
				WHERE `option_id` = 'dbtech_shop_navbar'
		");
	}
	
	/**
	 *
	 */
	public function upgrade20160328Step1()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_currency', function(Alter $table)
		{
			$table->dropColumns(['bitfield']);
			$table->changeColumn('description', 'blob')->nullable(true);
			$table->changeColumn('pointstable', 'varchar', 255)->setDefault('')->renameTo('table');
			$table->addColumn('useprefix', 'tinyint', 3)->setDefault(1)->after('table');
			$table->changeColumn('pointscolumn', 'varchar', 255)->setDefault('')->renameTo('column')->after('useprefix');
			$table->addColumn('userid', 'tinyint', 3)->setDefault(1)->after('column');
			$table->addColumn('usercol', 'varchar', 255)->setDefault('user_id')->after('userid');
			$table->changeColumn('rounding', 'tinyint', 2)->setDefault(0)->renameTo('decimals')->after('usercol');
			$table->changeColumn('privacy', 'tinyint', 3)->setDefault(2)->after('decimals');
			$table->addColumn('blacklist', 'tinyint', 3)->setDefault(0)->after('privacy');
			$table->addColumn('prefix', 'varchar', 50)->setDefault('')->after('blacklist');
			$table->addColumn('suffix', 'varchar', 50)->setDefault('')->after('prefix');
		});
	}
	
	/**
	 * @throws \XF\Db\Exception
	 */
	public function upgrade20160328Step2()
	{
		$this->query("
			UPDATE `xf_dbtech_shop_currency`
				SET `privacy` = 2
		");
		
		// Purge the cache
		\XF::registry()->delete([
			'dbtech_shop_currency',
		]);
	}
	
	/**
	 *
	 */
	public function upgrade20160329Step1()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_user', function(Alter $table)
		{
			$table->changeColumn('dbtech_shop_points', 'double')->unsigned(false)->setDefault(0);
		});
	}
	
	/**
	 *
	 */
	public function upgrade20160403Step1()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_item', function(Alter $table)
		{
			$table->addColumn('customshops', 'tinyint', 3)->setDefault(0)->after('threadpage');
			$table->addColumn('stealthed', 'tinyint', 3)->setDefault(0)->after('customshops');
		});
	}
	
	/**
	 *
	 */
	public function upgrade20160408Step1()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_lottery', function(Alter $table)
		{
			$table->addColumn('ticketssold', 'int')->setDefault(0);
		});
	}
	
	/**
	 * @throws \XF\Db\Exception
	 */
	public function upgrade20160408Step2()
	{
		$this->query("
			UPDATE xf_dbtech_shop_lottery AS lottery
			SET `ticketssold` = (
				SELECT COUNT(*) FROM `xf_dbtech_shop_lotteryticket` WHERE `lotteryid` = `lottery`.`lotteryid`
			)
		");
	}
	
	/**
	 *
	 */
	public function upgrade20160410Step1()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_currency', function(Alter $table)
		{
			$table->addColumn('creditscurrencyid', 'int')->setDefault(0);
		});
	}
	
	/**
	 *
	 */
	public function upgrade20160418Step1()
	{
		$sm = $this->schemaManager();
		
		$sm->createTable('xf_dbtech_shop_lotteryticket', function(Create $table)
		{
			$table->addColumn('lotteryticketid', 'int')->autoIncrement();
			$table->addColumn('lotteryid', 'int')->setDefault(0);
			$table->addColumn('userid', 'int')->setDefault(0);
			$table->addColumn('lotterydraw', 'int')->setDefault(0);
			$table->addColumn('numbers', 'mediumblob')->nullable(true);
			$table->addColumn('prizeid', 'int')->setDefault(0);
			$table->addKey(['lotteryid', 'userid'], 'lotteryid');
			$table->addKey(['lotteryid', 'lotterydraw'], 'lotteryid_2');
		});
	}
	
	/**
	 * @throws \XF\Db\Exception
	 */
	public function upgrade20160426Step1()
	{
		$this->query("
			UPDATE `xf_dbtech_shop_category`
				SET `permissions` = NULL
		");
		
		$this->query("
			UPDATE `xf_dbtech_shop_item`
				SET `permissions` = NULL
		");
		
		$this->query("
			UPDATE `xf_dbtech_shop_shop`
				SET `permissions` = NULL
		");
		
		// Purge the cache
		\XF::registry()->delete([
			'dbtech_shop_category',
			'dbtech_shop_item',
			'dbtech_shop_shop',
		]);
	}
	
	/**
	 *
	 */
	public function upgrade20160430Step1()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_lotteryticket', function(Create $table)
		{
			$table->addColumn('dateline', 'int')->setDefault(0)->after('userid');
		});
	}
	
	/**
	 * @throws \XF\Db\Exception
	 */
	public function upgrade20160430Step2()
	{
		$this->query("
			UPDATE `xf_dbtech_shop_lotteryticket`
				SET `dateline` = `lotterydraw`
		");
	}
	
	/**
	 * @throws \XF\Db\Exception
	 */
	public function upgrade20160508Step1()
	{
		$this->query("
			UPDATE `xf_dbtech_shop_item`
				SET `icon` = IF(SUBSTRING(`icon`, 1, 6) = 'items/', CONCAT('styles/DBTech/Shop/', `icon`), `icon`)
		");
		
		$this->query("
			UPDATE `xf_dbtech_shop_item`
				SET `shopicon` = IF(SUBSTRING(`shopicon`, 1, 6) = 'items/', CONCAT('styles/DBTech/Shop/', `shopicon`), `shopicon`)
		");
		
		// Purge the cache
		\XF::registry()->delete([
			'dbtech_shop_item',
		]);
	}
	
	/**
	 *
	 */
	public function upgrade20160517Step1()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_bank', function(Alter $table)
		{
			$table->changeColumn('points', 'double')->unsigned(false)->setDefault(0);
		});
		
		// Purge the cache
		\XF::registry()->delete([
			'dbtech_shop_shop',
		]);
	}
	
	/**
	 *
	 */
	public function upgrade20160519Step1()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_feedback', function(Alter $table)
		{
			$table->addColumn('shopid', 'int', 10)->setDefault(0)->after('userid');
			$table->addColumn('numratings', 'int', 10)->setDefault(0)->after('beneficiary_split');
		});
	}
	
	/**
	 *
	 */
	public function upgrade20160623Step1()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_user', function(Alter $table)
		{
			$table->addColumn('dbtech_shop_pendingtrades', 'int')->setDefault(0)->after('dbtech_shop_purchases');
		});
	}
	
	/**
	 *
	 */
	public function upgrade20160703Step1()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_transactionlog', function(Alter $table)
		{
			$table->changeColumn('ipaddress', 'varchar', 45)->setDefault('');
		});
	}
	
	/**
	 *
	 */
	public function upgrade20160722Step1()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_item', function(Alter $table)
		{
			$table->addColumn('exclusiveitem', 'tinyint', 3)->setDefault(0);
		});
	}
	
	/**
	 *
	 */
	public function upgrade20160724Step1()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_itemtype', function(Alter $table)
		{
			$table->addColumn('item_class', 'varchar', 75)->setDefault('');
		});
	}
	
	/**
	 * @throws \XF\Db\Exception
	 */
	public function upgrade20160724Step2()
	{
		foreach ([
					 'autobump' 			=> 'DBTech_Shop_Item_AutoBump',
					 'avatarchange' 		=> 'DBTech_Shop_Item_AvatarChange',
					 'createforum' 		=> 'DBTech_Shop_Item_Forum_Create',
					 'custom' 			=> 'DBTech_Shop_Item_Custom',
					 'customicon' 		=> 'DBTech_Shop_Item_CustomIcon',
					 'deletethread' 		=> 'DBTech_Shop_Item_DeleteThread',
					 'firemoderator' 	=> 'DBTech_Shop_Item_FireModerator',
					 'forumdescription' 	=> 'DBTech_Shop_Item_Forum_Description',
					 'forumpassword' 	=> 'DBTech_Shop_Item_ForumPassword',
					 'forumpermission' 	=> 'DBTech_Shop_Item_Permission_Forum',
					 'immunity' 			=> 'DBTech_Shop_Item_Immunity',
					 'intpermission' 	=> 'DBTech_Shop_Item_Permission_Int',
					 'moderateforum' 	=> 'DBTech_Shop_Item_Forum_Moderate',
					 'movethread' 		=> 'DBTech_Shop_Item_MoveThread',
					 'permission' 		=> 'DBTech_Shop_Item_Permission_Value',
					 'postbithighlight' 	=> 'DBTech_Shop_Item_Style_Highlight_Postbit',
					 'postbithighlight2' => 'DBTech_Shop_Item_Style_Highlight_Postbit_PreDefined',
					 'poststyle' 		=> 'DBTech_Shop_Item_Style_Post',
					 'poststyle2' 		=> 'DBTech_Shop_Item_Style_Post_PreDefined',
					 'profilemusic' 		=> 'DBTech_Shop_Item_ProfileMusic',
					 'signaturechange' 	=> 'DBTech_Shop_Item_SignatureChange',
					 'smilie' 			=> 'DBTech_Shop_Item_Smilie',
					 'smiliecategory' 	=> 'DBTech_Shop_Item_SmilieCategory',
					 'stealchance' 		=> 'DBTech_Shop_Item_Steal_Chance',
					 'stealmore' 		=> 'DBTech_Shop_Item_Steal_Amount',
					 'sticky' 			=> 'DBTech_Shop_Item_Sticky',
					 'threadban' 		=> 'DBTech_Shop_Item_ThreadBan',
					 'threadbump' 		=> 'DBTech_Shop_Item_ThreadBump',
					 'threadhighlight' 	=> 'DBTech_Shop_Item_Style_Highlight_Thread',
					 'threadhighlight2' 	=> 'DBTech_Shop_Item_Style_Highlight_Thread_PreDefined',
					 'threadtitlestyle' 	=> 'DBTech_Shop_Item_Style_ThreadTitle',
					 'threadtitlestyle2' => 'DBTech_Shop_Item_Style_ThreadTitle_PreDefined',
					 'usergroupchange' 	=> 'DBTech_Shop_Item_Change_UserGroup',
					 'usernamechange' 	=> 'DBTech_Shop_Item_Change_UserName',
					 'usernamestyle' 	=> 'DBTech_Shop_Item_Style_UserName',
					 'usernamestyle2' 	=> 'DBTech_Shop_Item_Style_UserName_PreDefined',
					 'usertitlechange' 	=> 'DBTech_Shop_Item_Change_UserTitle',
					 'usertitlechange2' 	=> 'DBTech_Shop_Item_Change_UserTitle_PreDefined',
					 'usertitlestyle' 	=> 'DBTech_Shop_Item_Style_UserTitle',
					 'usertitlestyle2' 	=> 'DBTech_Shop_Item_Style_UserTitle_PreDefined',
				 ] as $itemTypeId => $itemClass)
		{
			$this->query("
				UPDATE `xf_dbtech_shop_itemtype`
					SET `item_class` = " . $this->db()->quote($itemClass) . "
					WHERE `itemtypeid` = " . $this->db()->quote($itemTypeId)
			);
		}
		
		// Purge the cache
		\XF::registry()->delete([
			'dbtech_shop_itemtype',
		]);
	}
	
	/**
	 * @throws \XF\Db\Exception
	 */
	public function upgrade20160726Step1()
	{
		foreach ([
					 'autobump' 			=> 'DBTech_Shop_Item_AutoBump',
					 'avatarchange' 		=> 'DBTech_Shop_Item_AvatarChange',
					 'createforum' 		=> 'DBTech_Shop_Item_Forum_Create',
					 'custom' 			=> 'DBTech_Shop_Item_Custom',
					 'customicon' 		=> 'DBTech_Shop_Item_CustomIcon',
					 'deletethread' 		=> 'DBTech_Shop_Item_DeleteThread',
					 'firemoderator' 	=> 'DBTech_Shop_Item_FireModerator',
					 'forumdescription' 	=> 'DBTech_Shop_Item_Forum_Description',
					 'forumpassword' 	=> 'DBTech_Shop_Item_ForumPassword',
					 'forumpermission' 	=> 'DBTech_Shop_Item_Permission_Forum',
					 'immunity' 			=> 'DBTech_Shop_Item_Immunity',
					 'intpermission' 	=> 'DBTech_Shop_Item_Permission_Int',
					 'moderateforum' 	=> 'DBTech_Shop_Item_Forum_Moderate',
					 'movethread' 		=> 'DBTech_Shop_Item_MoveThread',
					 'permission' 		=> 'DBTech_Shop_Item_Permission_Value',
					 'postbithighlight' 	=> 'DBTech_Shop_Item_Style_Highlight_Postbit',
					 'postbithighlight2' => 'DBTech_Shop_Item_Style_Highlight_Postbit_PreDefined',
					 'poststyle' 		=> 'DBTech_Shop_Item_Style_Post',
					 'poststyle2' 		=> 'DBTech_Shop_Item_Style_Post_PreDefined',
					 'profilemusic' 		=> 'DBTech_Shop_Item_ProfileMusic',
					 'signaturechange' 	=> 'DBTech_Shop_Item_SignatureChange',
					 'smilie' 			=> 'DBTech_Shop_Item_Smilie',
					 'smiliecategory' 	=> 'DBTech_Shop_Item_SmilieCategory',
					 'stealchance' 		=> 'DBTech_Shop_Item_Steal_Chance',
					 'stealmore' 		=> 'DBTech_Shop_Item_Steal_Amount',
					 'sticky' 			=> 'DBTech_Shop_Item_Sticky',
					 'threadban' 		=> 'DBTech_Shop_Item_ThreadBan',
					 'threadbump' 		=> 'DBTech_Shop_Item_ThreadBump',
					 'threadhighlight' 	=> 'DBTech_Shop_Item_Style_Highlight_Thread',
					 'threadhighlight2' 	=> 'DBTech_Shop_Item_Style_Highlight_Thread_PreDefined',
					 'threadtitlestyle' 	=> 'DBTech_Shop_Item_Style_ThreadTitle',
					 'threadtitlestyle2' => 'DBTech_Shop_Item_Style_ThreadTitle_PreDefined',
					 'usergroupchange' 	=> 'DBTech_Shop_Item_Change_UserGroup',
					 'usernamechange' 	=> 'DBTech_Shop_Item_Change_UserName',
					 'usernamestyle' 	=> 'DBTech_Shop_Item_Style_UserName',
					 'usernamestyle2' 	=> 'DBTech_Shop_Item_Style_UserName_PreDefined',
					 'usertitlechange' 	=> 'DBTech_Shop_Item_Change_UserTitle',
					 'usertitlechange2' 	=> 'DBTech_Shop_Item_Change_UserTitle_PreDefined',
					 'usertitlestyle' 	=> 'DBTech_Shop_Item_Style_UserTitle',
					 'usertitlestyle2' 	=> 'DBTech_Shop_Item_Style_UserTitle_PreDefined',
				 ] as $itemTypeId => $itemClass)
		{
			$this->query("
				UPDATE `xf_dbtech_shop_itemtype`
					SET `item_class` = " . $this->db()->quote($itemClass) . "
					WHERE `itemtypeid` = " . $this->db()->quote($itemTypeId)
			);
		}
		
		// Purge the cache
		\XF::registry()->delete([
			'dbtech_shop_itemtype',
		]);
	}
	
	/**
	 *
	 */
	public function upgrade20160729Step1()
	{
		$sm = $this->schemaManager();
		
		$sm->createTable('xf_dbtech_shop_trade', function(Create $table)
		{
			$table->addColumn('tradeid', 'int')->autoIncrement();
			$table->addColumn('user1', 'int')->setDefault(0);
			$table->addColumn('user2', 'int')->setDefault(0);
			$table->addColumn('created_date', 'int')->setDefault(0);
			$table->addColumn('updated_date', 'int')->setDefault(0);
			$table->addColumn('status', 'enum')->values(['pending','open','awaiting_accept','accepted','cancelled'])->setDefault('pending');
			$table->addColumn('user1_accepted', 'tinyint', 3)->setDefault(0);
			$table->addColumn('user2_accepted', 'tinyint', 3)->setDefault(0);
			$table->addColumn('conversation_id', 'int')->setDefault(0);
			$table->addKey('user1');
			$table->addKey('user2');
		});
		
		$sm->createTable('xf_dbtech_shop_trade_offer', function(Create $table)
		{
			$table->addColumn('tradeid', 'int');
			$table->addColumn('userid', 'int')->setDefault(0);
			$table->addColumn('feature', 'enum')->values(['item','currency'])->setDefault('item');
			$table->addColumn('featureid', 'int');
			$table->addColumn('quantity', 'int')->setDefault(0);
			$table->addPrimaryKey(['tradeid', 'userid', 'feature', 'featureid']);
		});
	}
	
	/**
	 *
	 */
	public function upgrade20160730Step1()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_currency', function(Alter $table)
		{
			$table->addColumn('cantrade', 'tinyint', 3)->setDefault(1)->after('cansteal');
		});
		
		// Purge the cache
		\XF::registry()->delete([
			'dbtech_shop_currency',
		]);
	}
	
	/**
	 *
	 */
	public function upgrade20160928Step1()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_currency', function(Alter $table)
		{
			$table->addColumn('displaycurrency', 'tinyint', 3)->setDefault(0)->after('suffix');
		});
		
		// Purge the cache
		\XF::registry()->delete([
			'dbtech_shop_currency',
		]);
	}
	
	/**
	 *
	 */
	public function upgrade20161005Step1()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_item', function(Alter $table)
		{
			$table->addColumn('autodiscard', 'tinyint', 3)->setDefault(0)->after('exclusiveitem');
		});
		
		// Purge the cache
		\XF::registry()->delete([
			'dbtech_shop_item',
		]);
	}
	
	/**
	 *
	 */
	public function upgrade20161012Step1()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_item', function(Alter $table)
		{
			$table->addColumn('autodiscard_expiry', 'tinyint', 3)->setDefault(0)->after('autodiscard');
		});
		
		// Purge the cache
		\XF::registry()->delete([
			'dbtech_shop_item',
		]);
	}
	
	/**
	 *
	 */
	public function upgrade20161019Step1()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_shopinventory', function(Alter $table)
		{
			$table->addColumn('buybackcurrencyid', 'int')->setDefault(0)->after('price');
			$table->addColumn('dateline', 'int')->setDefault(0)->after('active');
		});
	}
	
	/**
	 * @throws \XF\Db\Exception
	 */
	public function upgrade20161019Step2()
	{
		$this->query("
			UPDATE `xf_dbtech_shop_shopinventory`
				SET `buybackcurrencyid` = `currencyid`
		");
		
		$this->query("
			UPDATE `xf_dbtech_shop_shopinventory`
				SET `dateline` = UNIX_TIMESTAMP()
		");
	}
	
	/**
	 * @throws \XF\Db\Exception
	 */
	public function upgrade20161122Step1()
	{
		$this->query("
			INSERT INTO `xf_dbtech_shop_itemtype`
				(`itemtypeid`, `title`, `description`, `active`, `item_class`)
			VALUES
				('postbackground', 'Post Background', X'507572636861736520746865206162696C69747920746F206368616E676520746865206261636B67726F756E64206F6620796F757220706F7374732E', 1, 'DBTech_Shop_Item_Style_PostBackground')
		");
		
		$this->query("
			INSERT INTO `xf_dbtech_shop_itemtype`
				(`itemtypeid`, `title`, `description`, `active`, `item_class`)
			VALUES
				('postbackground2', 'Post Background (Pre-Defined)', X'507572636861736520746865206162696C69747920746F206368616E676520746865206261636B67726F756E64206F6620796F757220706F73747320746F2061207072652D646566696E6564207374796C652E', 1, 'DBTech_Shop_Item_Style_PostBackground_PreDefined')
		");
		
		// Purge the cache
		\XF::registry()->delete([
			'dbtech_shop_itemtype',
		]);
	}
	
	/**
	 *
	 */
	public function upgrade20161201Step1()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_item', function(Alter $table)
		{
			$table->addColumn('user_criteria', 'mediumblob')->nullable(true)->after('permissions');
		});
		
		$sm->alterTable('xf_dbtech_shop_purchase', function(Alter $table)
		{
			$table->addColumn('gifted', 'tinyint', 3)->setDefault(0)->after('hidden');
			$table->addColumn('traded', 'tinyint', 3)->setDefault(0)->after('gifted');
		});
	}
	
	/**
	 * @throws \XF\Db\Exception
	 */
	public function upgrade20161201Step2()
	{
		$this->query("
			UPDATE `xf_dbtech_shop_purchase`
			SET `gifted` = 1
			WHERE `userid` != `buyer`
		");
	}
	
	/**
	 * @throws \XF\Db\Exception
	 */
	public function upgrade20170314Step1()
	{
		$this->query("
			UPDATE `xf_dbtech_shop_itemtype`
				SET `item_class` = REPLACE(`item_class`, '_', '\\\')
				WHERE `item_class` LIKE 'DBTech_Shop_%'
		");
		
		$this->query("
			UPDATE `xf_dbtech_shop_itemtype`
				SET `item_class` = 'DBTech\\\Shop\\\Item\\\Permission\\\IntValue'
				WHERE `itemtypeid` = 'intpermission'
		");
		
		$this->query("
			UPDATE `xf_dbtech_shop_itemtype`
				SET `item_class` = 'DBTech\\\Shop\\\Item\\\Permission\\\RawValue'
				WHERE `itemtypeid` = 'permission'
		");
		
		// Purge the cache
		\XF::registry()->delete([
			'dbt_shop_itemtype',
		]);
	}
	
	/**
	 *
	 */
	public function upgrade806000031Step1()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_currency', function(Alter $table)
		{
			$table->addColumn('sidebar', 'tinyint', 3)->setDefault(1);
		});
	}
	
	/**
	 *
	 */
	public function upgrade906000031Step1()
	{
		$this->insertNamedWidget('dbtech_shop_profilemusic');
		$this->insertNamedWidget('dbtech_shop_wallet');
		$this->insertNamedWidget('dbtech_shop_cart');
		
		// Purge the cache
		\XF::registry()->delete([
			'dbt_shop_category',
			'dbt_shop_currency',
			'dbt_shop_item',
			'dbt_shop_itemtype',
			'dbt_shop_lottery',
			'dbt_shop_lotteryprize',
			'dbt_shop_shop',
			
			'dbtech_shop_category',
			'dbtech_shop_currency',
			'dbtech_shop_item',
			'dbtech_shop_itemtype',
			'dbtech_shop_lottery',
			'dbtech_shop_lotteryprize',
			'dbtech_shop_shop',
		]);
	}
	
	
	/**
	 *
	 */
	public function upgrade906010030Step1()
	{
		// Purge the cache
		\XF::registry()->delete([
			'dbt_shop_category',
			'dbt_shop_currency',
			'dbt_shop_item',
			'dbt_shop_itemtype',
			'dbt_shop_lottery',
			'dbt_shop_lotteryprize',
			'dbt_shop_shop',
			
			'dbtech_shop_category',
			'dbtech_shop_currency',
			'dbtech_shop_item',
			'dbtech_shop_itemtype',
			'dbtech_shop_lottery',
			'dbtech_shop_lotteryprize',
			'dbtech_shop_shop',
		]);
	}
	
	/**
	 *
	 */
	public function upgrade906010011Step1()
	{
		$sm = $this->schemaManager();
		
		if (!$sm->tableExists('xf_dbtech_shop_tradingcard'))
		{
			$sm->createTable('xf_dbtech_shop_tradingcard', function(Create $table)
			{
				$table->addColumn('tradingcardid', 'int')->autoIncrement();
				$table->addColumn('title', 'varchar', 50)->setDefault('');
				$table->addColumn('description', 'mediumblob')->nullable(true);
				$table->addColumn('active', 'tinyint', 1)->setDefault(1);
				$table->addColumn('rarity', 'tinyint', 1)->setDefault(1);
				$table->addColumn('filename', 'varchar', 255)->setDefault('');
			});
		}
		
		if (!$sm->tableExists('xf_dbtech_shop_tradingcard_collection'))
		{
			$sm->createTable('xf_dbtech_shop_tradingcard_collection', function(Create $table)
			{
				$table->addColumn('tradingcardid', 'int');
				$table->addColumn('userid', 'int');
				$table->addColumn('trade_locked', 'tinyint', 1)->setDefault(0);
				$table->addPrimaryKey(['tradingcardid', 'userid']);
			});
		}
		
		if ($sm->tableExists('xf_dbtech_shop_lotteryprize'))
		{
			$sm->renameTable('xf_dbtech_shop_lotteryprize', 'xf_dbtech_shop_lottery_prize');
		}
		
		if ($sm->tableExists('xf_dbtech_shop_lotteryticket'))
		{
			$sm->renameTable('xf_dbtech_shop_lotteryticket', 'xf_dbtech_shop_lottery_ticket');
		}
		
		if ($sm->tableExists('xf_dbtech_shop_shoppingcart'))
		{
			$sm->renameTable('xf_dbtech_shop_shoppingcart', 'xf_dbtech_shop_cart');
		}
		
		if ($sm->tableExists('xf_dbtech_shop_threadban'))
		{
			$sm->renameTable('xf_dbtech_shop_threadban', 'xf_dbtech_shop_thread_ban');
		}
		
		if ($sm->tableExists('xf_dbtech_shop_tradingcard'))
		{
			$sm->renameTable('xf_dbtech_shop_tradingcard', 'xf_dbtech_shop_trading_card');
		}
		
		if ($sm->tableExists('xf_dbtech_shop_tradingcard_collection'))
		{
			$sm->renameTable('xf_dbtech_shop_tradingcard_collection', 'xf_dbtech_shop_trading_card_collection');
		}
		
		if ($sm->tableExists('xf_dbtech_shop_transactionlog'))
		{
			$sm->renameTable('xf_dbtech_shop_transactionlog', 'xf_dbtech_shop_transaction_log');
		}
	}
	
	/**
	 *
	 */
	public function upgrade906010011Step2()
	{
		$sm = $this->schemaManager();
		
		$tables = $this->getTables();
		
		$key = 'xf_dbtech_shop_category_field';
		$sm->createTable($key, $tables[$key]);
		
		$key = 'xf_dbtech_shop_category_field';
		$sm->createTable($key, $tables[$key]);
		
		$key = 'xf_dbtech_shop_category_prefix';
		$sm->createTable($key, $tables[$key]);
		
		$key = 'xf_dbtech_shop_category_watch';
		$sm->createTable($key, $tables[$key]);
		
		$key = 'xf_dbtech_shop_item_field';
		$sm->createTable($key, $tables[$key]);
		
		$key = 'xf_dbtech_shop_item_field_value';
		$sm->createTable($key, $tables[$key]);
		
		$key = 'xf_dbtech_shop_item_filter_map';
		$sm->createTable($key, $tables[$key]);
		
		$key = 'xf_dbtech_shop_item_prefix';
		$sm->createTable($key, $tables[$key]);
		
		$key = 'xf_dbtech_shop_item_prefix_group';
		$sm->createTable($key, $tables[$key]);
		
		$key = 'xf_dbtech_shop_item_rating';
		$sm->createTable($key, $tables[$key]);
		
		$key = 'xf_dbtech_shop_item_watch';
		$sm->createTable($key, $tables[$key]);
		
		$key = 'xf_dbtech_shop_lottery_history';
		$sm->createTable($key, $tables[$key]);
		
		$key = 'xf_dbtech_shop_lottery_prize_map';
		$sm->createTable($key, $tables[$key]);
		
		$sm->dropTable('xf_dbtech_shop_itemtype');
	}
	
	/**
	 *
	 */
	public function upgrade906010011Step3()
	{
		$db = $this->db();
		
		$db->beginTransaction();
		
		$lotteries = $db->fetchAll('
			SELECT lotteryid, prizes
			FROM xf_dbtech_shop_lottery
		');
		foreach ($lotteries as $lottery)
		{
			$prizes = @unserialize($lottery['prizes']);
			$prizes = is_array($prizes) ? $prizes : [];
			
			$newPrizes = [];
			foreach ($prizes as $prize)
			{
				if (empty($prize['prizeid'])
					|| empty($prize['currencyid'])
					|| empty($prize['prize'])
				)
				{
					continue;
				}
				
				$prizeData = [
					'lottery_id' => $lottery['lotteryid'],
					'lottery_prize_id' => $prize['prizeid'],
					'currency_id' => $prize['currencyid'],
					'prize_amount' => $prize['prize']
				];
				
				$newPrizes[] = $prizeData;
				
				$db->insert('xf_dbtech_shop_lottery_prize_map', $prizeData, false, false, 'IGNORE');
			}
			
			$db->update('xf_dbtech_shop_lottery', [
				'prizes' => json_encode($newPrizes)
			], null);
		}
		
		$db->commit();
	}
	
	/**
	 *
	 */
	public function upgrade906010011Step4()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_cart', function(Alter $table)
		{
			$table->addColumn('recipient_user_id', 'int')->after('itemid');
			$table->addColumn('recipient_username', 'varchar', 50)->after('recipient_user_id');
			$table->addColumn('message', 'mediumblob')->nullable(true)->after('quantity');
		});
		
		$sm->alterTable('xf_dbtech_shop_category', function(Alter $table)
		{
			$table->dropColumns([
				'permissions',
				'bitfield',
				'active',
				'customshops'
			]);
			$table->addColumn('parent_category_id', 'int')->setDefault(0)->after('description');
			$table->addColumn('lft', 'int')->setDefault(0);
			$table->addColumn('rgt', 'int')->setDefault(0);
			$table->addColumn('depth', 'smallint', 5)->setDefault(0);
			$table->addColumn('breadcrumb_data', 'blob');
			$table->addColumn('item_count', 'int')->setDefault(0);
			$table->addColumn('last_update', 'int')->setDefault(0);
			$table->addColumn('last_item_title', 'varchar', 100)->setDefault('');
			$table->addColumn('last_item_id', 'int')->setDefault(0);
			$table->addColumn('prefix_cache', 'mediumblob');
			$table->addColumn('field_cache', 'mediumblob');
			$table->addColumn('item_filters', 'blob');
			$table->addColumn('require_prefix', 'tinyint', 3)->setDefault(0);
			$table->addColumn('thread_node_id', 'int')->setDefault(0);
			$table->addColumn('thread_prefix_id', 'int')->setDefault(0);
			$table->addColumn('item_update_notify', 'enum')->values(['thread', 'reply'])->setDefault('thread');
			$table->addColumn('always_moderate_create', 'tinyint', 3)->setDefault(0);
			$table->addColumn('always_moderate_update', 'tinyint', 3)->setDefault(0);
			$table->addColumn('min_tags', 'smallint', 5)->setDefault(0);
			$table->addColumn('sales', 'int')->setDefault(0);
			$table->addColumn('sales_amounts', 'mediumblob')->nullable(true);
			$table->addColumn('latest_customer_id', 'int')->setDefault(0);
			$table->addColumn('latest_sale_id', 'int')->setDefault(0);
			$table->addColumn('beneficiary', 'int')->unsigned(false)->setDefault(-1);
			$table->addColumn('beneficiary_split', 'tinyint', 3)->setDefault(100);
			$table->addColumn('num_ratings', 'int')->setDefault(0);
			$table->addColumn('average_rating', 'double')->setDefault(0);
			$table->addColumn('positive_percent', 'double')->setDefault(0);
			$table->addColumn('negative_percent', 'double')->setDefault(0);
			$table->addColumn('neutral_percent', 'double')->setDefault(0);
			$table->addColumn('can_have_feedback', 'tinyint', 3)->setDefault(1);
			$table->addKey(['parent_category_id', 'lft']);
			$table->addKey(['lft', 'rgt']);
		});
		
		$sm->alterTable('xf_dbtech_shop_currency', function(Alter $table)
		{
			$table->dropColumns(['postbit']);
			$table->addColumn('postbit', 'tinyint', 3)->setDefault(1);
		});
		
		$sm->alterTable('xf_dbtech_shop_feedback', function(Alter $table)
		{
			$table->dropColumns(['shopid']);
		});
		
		$sm->alterTable('xf_dbtech_shop_item', function(Alter $table)
		{
			$table->addColumn('category_id', 'int')->after('itemid');
			$table->addColumn('creation_date', 'int')->setDefault(0)->after('displayorder');
			$table->addColumn('last_update', 'int')->setDefault(0)->after('creation_date');
			$table->addColumn('_old_item_id', 'int')->setDefault(0);
			
			$table->dropColumns([
				'shop',
				'permissions',
				'prepurchase_callback_class',
				'prepurchase_callback_method',
				'postpurchase_callback_class',
				'postpurchase_callback_method',
				'sellback_callback_class',
				'sellback_callback_method',
				'configure_callback_class',
				'configure_callback_method',
				'gift_callback_class',
				'gift_callback_method',
				'discard_callback_class',
				'discard_callback_method',
			]);
			$table->addColumn('item_state', 'enum')->values(['visible', 'moderated', 'deleted'])->setDefault('visible')->after('active');
			$table->addColumn('length_amount', 'tinyint', 3)->after('duration');
			$table->addColumn('length_unit', 'enum')->values(['day', 'month', 'year', ''])->after('length_amount');
			$table->addColumn('currency_id', 'int')->setDefault(0);
			$table->addColumn('price', 'double')->setDefault(0);
			$table->addColumn('buyback_currency_id', 'int')->setDefault(0);
			$table->addColumn('buyback_price', 'double')->setDefault(0);
			$table->addColumn('buyback_time', 'int')->setDefault(0);
			$table->addColumn('buyback_replenish', 'tinyint', 3)->setDefault(1);
			$table->addColumn('notifications', 'mediumblob')->nullable(true);
			$table->addColumn('notifications_config', 'mediumblob')->nullable(true);
			$table->addColumn('stock', 'int')->unsigned(false)->setDefault('0');
			$table->addColumn('maxstock', 'int')->unsigned(false)->setDefault('0');
			$table->addColumn('refill_time', 'int')->setDefault(0);
			$table->addColumn('last_refill_date', 'int')->setDefault(0);
			$table->addColumn('username', 'varchar', 50)->after('ownerid');
			$table->addColumn('ip_id', 'int')->setDefault(0)->after('username');
			$table->addColumn('warning_id', 'int')->setDefault(0)->after('ip_id');
			$table->addColumn('warning_message', 'varchar', 255)->setDefault('')->after('warning_id');
			$table->addColumn('thread_node_id', 'int')->setDefault(0)->after('itemtypeid');
			$table->addColumn('thread_prefix_id', 'int')->setDefault(0)->after('thread_node_id');
			$table->addColumn('discussion_thread_id', 'int')->setDefault(0)->after('thread_prefix_id');
			$table->addColumn('field_cache', 'mediumblob')->after('discussion_thread_id');
			$table->addColumn('item_fields', 'mediumblob')->after('field_cache');
			$table->addColumn('item_filters', 'blob')->after('item_fields');
			$table->addColumn('rating_count', 'int')->setDefault(0);
			$table->addColumn('rating_sum', 'int')->setDefault(0);
			$table->addColumn('rating_avg', 'float', '')->setDefault(0);
			$table->addColumn('rating_weighted', 'float', '')->setDefault(0);
			$table->addColumn('review_count', 'int')->setDefault(0);
			$table->addColumn('icon_date', 'int')->setDefault(0);
			$table->addColumn('prefix_id', 'int')->setDefault(0);
			$table->addColumn('tags', 'mediumblob');
			$table->addKey(['category_id', 'last_update'], 'category_last_update');
			$table->addKey(['category_id', 'rating_weighted'], 'category_rating_weighted');
			$table->addKey('last_update');
			$table->addKey('rating_weighted');
			$table->addKey(['ownerid', 'last_update']);
			$table->addKey('discussion_thread_id');
			$table->addKey('prefix_id');
		});
		
		$sm->alterTable('xf_dbtech_shop_lottery', function(Alter $table)
		{
			$table->dropColumns([
				'permissions',
				'bitfield'
			]);
		});
		
		$sm->alterTable('xf_dbtech_shop_lottery_prize', function(Alter $table)
		{
			$table->dropColumns(['bitfield']);
		});
	}
	
	/**
	 *
	 */
	public function upgrade906010011Step5()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_purchase', function(Alter $table)
		{
			$table->addColumn('category_id', 'int')->after('dateline');
			$table->addColumn('buyer_username', 'varchar', 50)->setDefault('')->after('buyer');
			$table->addColumn('configured', 'tinyint', 3)->setDefault(0)->after('hidden');
			$table->addColumn('discussion_thread_id', 'int')->setDefault(0);
			$table->dropColumns(['feature']);
			$table->addKey('discussion_thread_id');
		});
	}
	
	/**
	 *
	 */
	public function upgrade906010011Step6()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_transaction_log', function(Alter $table)
		{
			$table->addColumn('content_type', 'varbinary', 25)->after('action');
			$table->addColumn('content_id', 'int')->setDefault(0)->after('content_type');
			$table->addColumn('ip_id', 'int', 10)->setDefault(0)->after('dateline');
			$table->dropColumns(['ipaddress']);
		});
	}
	
	/**
	 *
	 */
	public function upgrade906010011Step7()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_shopinventory', function(Alter $table)
		{
			$table->addColumn('category_id', 'int')->after('itemid');
		});
	}
	
	/**
	 *
	 */
	public function upgrade906010011Step8()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_bank', function(Alter $table)
		{
			$table->renameColumn('userid', 'user_id');
			$table->renameColumn('currencyid', 'currency_id');
			$table->renameColumn('lastinterest', 'last_interest_date');
		});

		$this->db()->emptyTable('xf_dbtech_shop_cart');
		
		$sm->alterTable('xf_dbtech_shop_cart', function(Alter $table)
		{
			$table->dropPrimaryKey();
			$table->dropColumns(['shopid']);
			$table->renameColumn('userid', 'user_id');
			$table->renameColumn('itemid', 'item_id');
			$table->addPrimaryKey(['user_id', 'item_id']);
		});

		$sm->alterTable('xf_dbtech_shop_category', function(Alter $table)
		{
			$table->renameColumn('categoryid', 'category_id');
			$table->renameColumn('displayorder', 'display_order');
		});
	}
	
	/**
	 *
	 */
	public function upgrade906010011Step9()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_currency', function(Alter $table)
		{
			$table->renameColumn('currencyid', 'currency_id');
			$table->renameColumn('displayorder', 'display_order');
			$table->renameColumn('useprefix', 'use_table_prefix');
			$table->renameColumn('userid', 'use_user_id');
			$table->renameColumn('usercol', 'user_id_column');
			$table->renameColumn('displaycurrency', 'is_display_currency');
			$table->renameColumn('canbank', 'can_bank');
			$table->renameColumn('cansteal', 'can_steal');
			$table->renameColumn('cantrade', 'can_trade');
			$table->renameColumn('stealprotect', 'steal_protect');
			$table->renameColumn('perreply', 'per_reply');
			$table->renameColumn('perthread', 'per_thread');
			$table->renameColumn('creditscurrencyid', 'credits_currency_id');
		});
		
		$sm->alterTable('xf_dbtech_shop_feedback', function(Alter $table)
		{
			$table->renameColumn('feedbackid', 'feedback_id');
			$table->renameColumn('userid', 'user_id');
			$table->renameColumn('purchaseid', 'purchase_id');
		});
		
		$sm->alterTable('xf_dbtech_shop_item', function(Alter $table)
		{
			$table->renameColumn('itemid', 'item_id');
			$table->renameColumn('displayorder', 'display_order');
			$table->renameColumn('categoryid', 'category_id');
			$table->renameColumn('shopicon', 'shop_icon');
			$table->renameColumn('itemtypeid', 'item_type_id');
			$table->renameColumn('giftable', 'is_giftable');
			$table->renameColumn('giftpm', 'send_gift_pm');
			$table->renameColumn('exclusiveitem', 'is_exclusive');
			$table->renameColumn('autodiscard', 'auto_discard');
			$table->renameColumn('autodiscard_expiry', 'auto_discard_expiry');
			$table->renameColumn('ownerid', 'user_id');
			$table->renameColumn('uniqueitem', 'is_unique');
			$table->renameColumn('onlygiftable', 'is_only_giftable');
			$table->renameColumn('reconfigure', 'can_reconfigure');
			$table->renameColumn('regift', 'can_regift');
			$table->renameColumn('nodisplay', 'is_always_hidden');
			$table->renameColumn('threadcreation', 'purchasable_thread_creation');
			$table->renameColumn('threadpage', 'purchasable_thread_page');
			$table->renameColumn('customshops', 'enabled_custom_shops');
			$table->renameColumn('stealthed', 'is_stealth_item');
		});
	}
	
	/**
	 *
	 */
	public function upgrade906010011Step10()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_lottery', function(Alter $table)
		{
			$table->renameColumn('lotteryid', 'lottery_id');
			$table->renameColumn('ticketprice', 'ticket_price');
			$table->renameColumn('currencyid', 'currency_id');
			$table->renameColumn('drawnnumbers', 'drawn_numbers');
			$table->renameColumn('drawinterval', 'draw_interval_days');
			$table->renameColumn('nextdraw', 'next_draw_date');
			$table->renameColumn('prevdraw', 'previous_draw_date');
			$table->renameColumn('ticketssold', 'tickets_sold');
		});
		
		$sm->alterTable('xf_dbtech_shop_lottery_prize', function(Alter $table)
		{
			$table->renameColumn('lotteryprizeid', 'lottery_prize_id');
		});
		
		$sm->alterTable('xf_dbtech_shop_lottery_ticket', function(Alter $table)
		{
			$table->renameColumn('lotteryticketid', 'lottery_ticket_id');
			$table->renameColumn('lotteryid', 'lottery_id');
			$table->renameColumn('userid', 'user_id');
			$table->renameColumn('dateline', 'ticket_date');
			$table->renameColumn('lotterydraw', 'draw_date');
			$table->renameColumn('prizeid', 'lottery_prize_id');
		});
	}
	
	/**
	 *
	 */
	public function upgrade906010011Step11()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_purchase', function(Alter $table)
		{
			$table->renameColumn('purchaseid', 'purchase_id');
			$table->renameColumn('userid', 'user_id');
			$table->renameColumn('buyer', 'buyer_user_id');
			$table->renameColumn('featureid', 'item_id');
			$table->renameColumn('feedbackstatus', 'feedback_status');
			$table->renameColumn('expirydate', 'expiry_date');
		});
		
		$sm->alterTable('xf_dbtech_shop_thread_ban', function(Alter $table)
		{
			$table->renameColumn('threadid', 'thread_id');
			$table->renameColumn('userid', 'user_id');
		});
		
		$sm->alterTable('xf_dbtech_shop_trade', function(Alter $table)
		{
			$table->renameColumn('tradeid', 'trade_id');
		});
	}
	
	/**
	 *
	 */
	public function upgrade906010011Step12()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_trade_offer', function(Alter $table)
		{
			$table->renameColumn('tradeid', 'trade_id');
			$table->renameColumn('userid', 'user_id');
		});
		
		$sm->alterTable('xf_dbtech_shop_trading_card', function(Alter $table)
		{
			$table->renameColumn('tradingcardid', 'trading_card_id');
		});
		
		$sm->alterTable('xf_dbtech_shop_trading_card_collection', function(Alter $table)
		{
			$table->renameColumn('tradingcardid', 'trading_card_id');
			$table->renameColumn('userid', 'user_id');
		});
	}
	
	/**
	 *
	 */
	public function upgrade906010011Step13()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_transaction_log', function(Alter $table)
		{
			$table->renameColumn('transactionlogid', 'transaction_log_id');
			$table->renameColumn('userid', 'user_id');
			$table->renameColumn('recipient', 'recipient_user_id');
		});
	}
	
	/**
	 * @throws \XF\Db\Exception
	 */
	public function upgrade906010011Step14()
	{
		$db = $this->db();
		
		$db->beginTransaction();
		
		$this->renamePermission('dbtech_shop', 'canview', 'dbtech_shop', 'view');
		$this->renamePermission('dbtech_shop', 'ismanager', 'dbtech_shop', 'moderateShop');
		$this->renamePermission('dbtech_shop', 'canbank', 'dbtech_shop', 'bank');
		$this->renamePermission('dbtech_shop', 'canlottery', 'dbtech_shop', 'viewLottery');
		$this->renamePermission('dbtech_shop', 'cantrade', 'dbtech_shop', 'trade');
		$this->renamePermission('dbtech_shop', 'defaults_canbuyitem', 'dbtech_shop', 'purchase');
		
		$db->commit();
	}
	
	/**
	 * @throws \XF\Db\Exception
	 */
	public function upgrade906010011Step15()
	{
		$db = $this->db();
		
		$db->beginTransaction();
		
		$db->query('
			UPDATE xf_dbtech_shop_item
			SET creation_date = UNIX_TIMESTAMP(), last_update = UNIX_TIMESTAMP()
		');
		
		$db->query('
			UPDATE xf_dbtech_shop_item AS item
			LEFT JOIN xf_user AS user ON(user.user_id = item.user_id)
			SET item.username = user.username
			WHERE user.username IS NOT NULL
		');
		
		$db->query('
			UPDATE xf_dbtech_shop_item
			SET code = \'a:0:{}\'
			WHERE code IS NULL
		');
		
		$db->query('
			UPDATE xf_dbtech_shop_item
			SET item_state = \'visible\'
			WHERE active = 1
		');
		
		$db->query('
			UPDATE xf_dbtech_shop_item
			SET item_state = \'deleted\'
			WHERE active = 0
		');
		
		$db->query('
			UPDATE xf_dbtech_shop_purchase AS purchase
			LEFT JOIN xf_user AS user ON(user.user_id = purchase.buyer_user_id)
			SET purchase.buyer_username = user.username
			WHERE user.username IS NOT NULL
		');
		
		$db->query('
			UPDATE xf_dbtech_shop_purchase
			SET configuration = \'a:0:{}\'
			WHERE configuration IS NULL
		');
		
		$db->query('
			UPDATE xf_dbtech_shop_purchase
			SET configured = 1
			WHERE configuration != \'a:0:{}\'
		');
		
		$db->commit();
	}
	
	/**
	 *
	 */
	public function upgrade906010011Step16()
	{
		$db = $this->db();
		
		$db->beginTransaction();
		
		$purchases = $db->fetchAll('
			SELECT purchase.purchase_id, purchase.dateline, item.duration
			FROM xf_dbtech_shop_purchase AS purchase
			LEFT JOIN xf_dbtech_shop_item AS item USING(item_id)
			WHERE purchase.expiry_date = 1
		');
		foreach ($purchases as $purchase)
		{
			$db->update('xf_dbtech_shop_purchase',
				['expiry_date' => ($purchase['duration'] ? ($purchase['dateline'] + ($purchase['duration'] * 86400)) : 0)],
				'purchase_id = ?', $purchase['purchase_id']
			);
		}
		
		$db->commit();
	}
	
	/**
	 *
	 */
	public function upgrade906010011Step17()
	{
		$db = $this->db();
		
		$db->beginTransaction();
		
		$db->update('xf_user',
			['dbtech_shop_purchase' => NULL],
			null
		);
		
		$db->commit();
	}
	
	/**
	 *
	 */
	public function upgrade906010011Step18()
	{
		$db = $this->db();
		
		$db->beginTransaction();
		
		$shops = $db->fetchAll('
			SELECT * FROM xf_dbtech_shop_shop
		');
		foreach ($shops as $shop)
		{
			$salesAmounts = @unserialize($shop['salesamounts']);
			$salesAmounts = is_array($salesAmounts) ? $salesAmounts : [];
			
			$category = [
				'title' => $shop['title'],
				'description' => $shop['description'],
				'display_order' => $shop['displayorder'],
				'prefix_cache' => '',
				'field_cache' => '',
				'item_filters' => '',
				'breadcrumb_data' => serialize([]),
				'sales' => $shop['sales'],
				'sales_amounts' => json_encode($salesAmounts),
				'latest_customer_id' => $shop['latestcustomer'],
				'latest_sale_id' => $shop['latestsale'],
				'beneficiary' => ($shop['beneficiary'] == -1 ? 0 : $shop['beneficiary']),
				'beneficiary_split' => $shop['beneficiary_split'],
				'num_ratings' => $shop['numratings'],
				'average_rating' => $shop['averagerating'],
				'positive_percent' => $shop['positivepercent'],
				'negative_percent' => $shop['negativepercent'],
				'neutral_percent' => $shop['neutralpercent'],
				'can_have_feedback' => $shop['canhavefeedback']
			];

			$db->insert('xf_dbtech_shop_category', $category);
			$categoryId = $db->lastInsertId();
			
			$db->update('xf_dbtech_shop_purchase', [
				'category_id' => $categoryId
			], 'shopid = ?', $shop['shopid']);
			
			$db->update('xf_dbtech_shop_shopinventory', [
				'category_id' => $categoryId
			], 'shopid = ?', $shop['shopid']);
		}
		
		$db->query('
			UPDATE xf_dbtech_shop_category
			SET sales_amounts = \'[]\'
			WHERE sales_amounts IS NULL
		');
		
		$db->commit();
	}
	
	/**
	 * @throws \XF\Db\Exception
	 */
	public function upgrade906010011Step19()
	{
		$db = $this->db();
		
		$db->beginTransaction();
		
		$entries = $db->fetchAll('
			SELECT * FROM xf_dbtech_shop_shopinventory
			WHERE active = 1
			ORDER BY itemid, category_id
		');
		
		$seenItemIds = [];
		foreach ($entries as $entry)
		{
			$data = [
				'category_id'  => $entry['category_id'],
				'currency_id' => $entry['currencyid'],
				'price' => $entry['price'],
				'buyback_currency_id' => $entry['buybackcurrencyid'],
				'buyback_price' => $entry['buybackprice'],
				'buyback_time' => $entry['buybacktime'],
				'buyback_replenish' => $entry['buybackreplenish'],
				'notifications' => $entry['notifications'],
				'notifications_config' => $entry['notifications_config'],
				'stock' => $entry['stock'],
				'maxstock' => $entry['maxstock'],
				'refill_time' => $entry['refilltime'],
				'last_refill_date' => $entry['lastrefill']
			];
			
			if (!isset($seenItemIds[$entry['itemid']]))
			{
				$db->update('xf_dbtech_shop_item', $data, 'item_id = ?', $entry['itemid']);
				
				$seenItemIds[$entry['itemid']] = true;
			}
			else
			{
				// Get old item and add new data
				$item = $db->fetchRow('SELECT * FROM xf_dbtech_shop_item WHERE item_id = ?', $entry['itemid']);
				$item = array_merge($item, $data, [
					'_old_item_id' => $entry['itemid']
				]);
				unset($item['item_id']);
				
				// Insert new item
				$db->insert('xf_dbtech_shop_item', $item);
				$itemId = $db->lastInsertId();
				
				// Update the record
				$db->update('xf_dbtech_shop_purchase', [
					'item_id' => $itemId
				], 'item_id = ? AND category_id = ?', [
					$entry['itemid'],
					$entry['category_id']
				]);
				
				$seenItemIds[$itemId] = true;
			}
		}
		
		$db->query("
			UPDATE xf_dbtech_shop_purchase AS purchase
			LEFT JOIN xf_dbtech_shop_item AS item USING(item_id)
			SET purchase.category_id = item.category_id
			WHERE purchase.category_id = 0
		");
		
		$db->commit();
	}
	
	/**
	 *
	 */
	public function upgrade906010011Step20()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_purchase', function(Alter $table)
		{
			$table->dropColumns(['shopid', 'category_id']);
		});
	}
	
	/**
	 *
	 */
	public function upgrade906010011Step21()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_item', function(Alter $table)
		{
			$table->dropColumns(['active']);
			$table->dropColumns(['_old_item_id']);
		});
	}
	
	/**
	 *
	 */
	public function upgrade906010011Step22()
	{
		$sm = $this->schemaManager();
		
		$sm->dropTable('xf_dbtech_shop_shopinventory');
		$sm->dropTable('xf_dbtech_shop_shop');
	}
	
	/**
	 *
	 */
	public function upgrade906010011Step23()
	{
		$db = $this->db();
		
		$db->beginTransaction();
		
		$items = $db->fetchAll('
			SELECT *
			FROM xf_dbtech_shop_item
			WHERE duration > 0
		');
		foreach ($items as $item)
		{
			$amount = $item['duration'];
			$unit = 'day';
			
			if ($item['duration'] > 255)
			{
				if (($item['duration'] % 365) == 0)
				{
					// Divided cleanly by year
					$amount = $item['duration'] / 365;
					$unit = 'year';
				}
				else if (($item['duration'] % 30) == 0)
				{
					// Divided cleanly by month
					$amount = $item['duration'] / 30;
					$unit = 'month';
				}
				else
				{
					// Default values
					$amount = 1;
					$unit = 'year';
				}
			}
			
			$db->update('xf_dbtech_shop_item',
				['length_amount' => $amount, 'length_unit' => $unit],
				'item_id = ?', $item['item_id']
			);
		}
		
		$db->commit();
	}
	
	/**
	 * @throws \XF\PrintableException
	 */
	public function upgrade906010011Step24()
	{
		$items = $this->db()->fetchAll('
			SELECT *
			FROM xf_dbtech_shop_item
			WHERE shop_icon <> \'\'
		');
		foreach ($items as $item)
		{
			$itemEntity = $this->app->em()
				->instantiateEntity('DBTech\Shop:Item', $item)
			;
			
			/** @var \DBTech\Shop\Service\Item\Icon $iconService */
			$iconService = $this->app->service('DBTech\Shop:Item\Icon', $itemEntity);
			$iconService->logIp(false);
			
			if (!$iconService->setImage($item['shop_icon']))
			{
				continue;
			}
			
			$iconService->updateIcon();
		}
	}
	
	/**
	 *
	 */
	public function upgrade906010011Step25()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_item', function(Alter $table)
		{
			$table->dropColumns([
				'duration',
				'shop_icon',
				'icon'
			]);
		});
	}
	
	/**
	 *
	 */
	public function upgrade906010011Step26()
	{
		$this->deleteWidget('dbtech_shop_wallet');
		$this->deleteWidget('dbtech_shop_cart');
		
		$this->insertNamedWidget('dbtech_shop_wallet');
		$this->insertNamedWidget('dbtech_shop_cart');
		$this->insertNamedWidget('dbtech_shop_list_top_items');
		$this->insertNamedWidget('dbtech_shop_overview_latest_reviews');
		$this->insertNamedWidget('dbtech_shop_overview_top_authors');
		$this->insertNamedWidget('dbtech_shop_whats_new_overview_new_items');
		$this->insertNamedWidget('dbtech_shop_forum_overview_new_items');
	}
	
	/**
	 *
	 */
	public function upgrade906010012Step1()
	{
		$sm = $this->schemaManager();
		
		$this->db()->update('xf_dbtech_shop_currency', [
			'steal_protect' => '100.00'
		], 'steal_protect = -1');
		
		$sm->alterTable('xf_dbtech_shop_currency', function(Alter $table)
		{
			$table->changeColumn('steal_protect')->resetDefinition()->type('double')->setDefault('100.00');
		});
		
		$sm->alterTable('xf_dbtech_shop_item', function(Alter $table)
		{
			$table->addColumn('reaction_score', 'int')->setDefault(0)->after('ip_id');
			$table->addColumn('reactions', 'blob')->after('reaction_score');
			$table->addColumn('reaction_users', 'blob')->after('reactions');
		});
	}
	
	/**
	 *
	 */
	public function upgrade906010012Step2()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_user', function(Alter $table)
		{
			$table->addColumn('dbtech_shop_item_count', 'int')->setDefault(0)->after('dbtech_shop_pendingtrades');
			$table->addKey('dbtech_shop_item_count', 'dbtech_shop_item_count');
		});
	}
	
	/**
	 *
	 */
	public function upgrade906010012Step3()
	{
		$this->deleteWidget('dbtech_shop_wallet');
		$this->insertNamedWidget('dbtech_shop_wallet');
	}
	
	/**
	 * @param array $stepParams
	 *
	 * @return array
	 */
	public function upgrade906010014Step1(array $stepParams)
	{
		$position = empty($stepParams[0]) ? 0 : $stepParams[0];
		
		return $this->entityColumnsToJson('DBTech\Shop:Item', ['code', 'item_fields', 'user_criteria'], $position, $stepParams);
	}
	
	/**
	 * @param array $stepParams
	 *
	 * @return array
	 */
	public function upgrade906010014Step2(array $stepParams)
	{
		$position = empty($stepParams[0]) ? 0 : $stepParams[0];
		
		return $this->entityColumnsToJson('DBTech\Shop:TransactionLog', ['info'], $position, $stepParams);
	}
	
	/**
	 * @param array $stepParams
	 *
	 * @return array
	 */
	public function upgrade906010014Step3(array $stepParams)
	{
		$position = empty($stepParams[0]) ? 0 : $stepParams[0];
		
		return $this->entityColumnsToJson('DBTech\Shop:Purchase', ['configuration'], $position, $stepParams);
	}
	
	/**
	 * @param array $stepParams
	 *
	 * @return array
	 */
	public function upgrade906010014Step4(array $stepParams)
	{
		$position = empty($stepParams[0]) ? 0 : $stepParams[0];
		
		return $this->entityColumnsToJson('DBTech\Shop:LotteryPrize', ['numbers'], $position, $stepParams);
	}
	
	/**
	 * @param array $stepParams
	 *
	 * @return array
	 */
	public function upgrade906010014Step5(array $stepParams)
	{
		$position = empty($stepParams[0]) ? 0 : $stepParams[0];
		
		return $this->entityColumnsToJson('DBTech\Shop:Category', ['prefix_cache', 'field_cache'], $position, $stepParams);
	}
	
	/**
	 * @param array $stepParams
	 *
	 * @return array
	 */
	public function upgrade906010014Step6(array $stepParams)
	{
		$position = empty($stepParams[0]) ? 0 : $stepParams[0];
		
		return $this->entityColumnsToJson('DBTech\Shop:Lottery', ['drawn_numbers'], $position, $stepParams);
	}
	
	/**
	 *
	 */
	public function upgrade906010014Step7()
	{
		$db = $this->db();
		
		$db->beginTransaction();
		
		$lotteries = $db->fetchAll('
			SELECT lottery_id, drawn_numbers
			FROM xf_dbtech_shop_lottery
		');
		foreach ($lotteries as $lottery)
		{
			$drawnNumbers = json_decode($lottery['drawn_numbers'], true);
			
			foreach ($drawnNumbers as $dateline => $numbers)
			{
				$db->insert('xf_dbtech_shop_lottery_history', [
					'lottery_id' => $lottery['lottery_id'],
					'drawn_numbers' => json_encode($numbers),
					'draw_date' => $dateline,
					'tickets_sold' => 0
				]);
			}
		}
		
		$db->commit();
	}

	/**
	 *
	 */
	public function upgrade906010015Step1()
	{
		$sm = $this->schemaManager();
		
		$tables = $this->getTables();
		
		if (!$sm->tableExists('xf_dbtech_shop_trade'))
		{
			$key = 'xf_dbtech_shop_trade';
			$sm->createTable($key, $tables[$key]);
		}
		else
		{
			$sm->alterTable('xf_dbtech_shop_trade', function(Alter $table)
			{
				$table->renameColumn('user1', 'creator_user_id');
				$table->renameColumn('user2', 'recipient_user_id');
				$table->renameColumn('status', 'trade_state');
				$table->renameColumn('user1_accepted', 'creator_accepted');
				$table->renameColumn('user2_accepted', 'recipient_accepted');
				$table->addColumn('creator_username', 'varchar', 50)->after('creator_user_id');
				$table->addColumn('recipient_username', 'varchar', 50)->after('recipient_user_id');
			});
		}
		
		if (!$sm->tableExists('xf_dbtech_shop_trade_offer'))
		{
			$key = 'xf_dbtech_shop_trade_offer';
			$sm->createTable($key, $tables[$key]);
		}
		else
		{
			$sm->alterTable('xf_dbtech_shop_trade_offer', function(Alter $table)
			{
				$table->changeColumn('feature')->resetDefinition()->type('varchar', 25)->setDefault('dbtech_shop_purchase')->renameTo('content_type');
				$table->renameColumn('featureid', 'content_id');
				$table->addColumn('finalized', 'tinyint')->setDefault(0);
			});
		}
	}
	
	/**
	 * @throws \XF\Db\Exception
	 */
	public function upgrade906010015Step2()
	{
		$db = $this->db();
		
		$db->beginTransaction();
		
		$db->query('
			UPDATE xf_dbtech_shop_trade AS trade
			SET creator_username = (SELECT username FROM xf_user WHERE user_id = trade.creator_user_id),
			    recipient_username = (SELECT username FROM xf_user WHERE user_id = trade.recipient_user_id)
		');
		$db->commit();
	}
	
	/**
	 * @throws \XF\Db\Exception
	 */
	public function upgrade906010015Step3()
	{
		$db = $this->db();
		
		$db->beginTransaction();
		
		$db->query("
			UPDATE xf_user AS user
			SET dbtech_shop_pendingtrades = (
				SELECT COUNT(*)
				FROM xf_dbtech_shop_trade
				WHERE trade_state IN('pending', 'open', 'awaiting_accept')
					AND (creator_user_id = user.user_id
			  			OR recipient_user_id = user.user_id)
			)
		");
		
		$db->commit();
	}
	
	/**
	 *
	 */
	public function upgrade906010015Step4()
	{
		$db = $this->db();
		
		$db->beginTransaction();
		
		$db->emptyTable('xf_dbtech_shop_trade');
		$db->emptyTable('xf_dbtech_shop_trade_offer');
		
		$db->commit();
	}
	
	/**
	 *
	 */
	public function upgrade906010015Step5()
	{
		$sm = $this->schemaManager();
		
		$tables = $this->getTables();
		
		$key = 'xf_dbtech_shop_trade_post';
		$sm->createTable($key, $tables[$key]);
		
		$key = 'xf_dbtech_shop_trade_post_comment';
		$sm->createTable($key, $tables[$key]);
	}
	
	/**
	 * @throws \XF\Db\Exception
	 */
	public function upgrade906010015Step6()
	{
		$this->executeUpgradeQuery("
			DELETE FROM xf_user_alert
			WHERE content_type = 'dbtech_shop_item'
				AND action IN('delete', 'undelete', 'edit', 'move', 'reassign_from', 'reassign_to')
		");
		
		$this->executeUpgradeQuery("
			UPDATE xf_user_alert
			SET content_type = 'user',
			    action = CONCAT_WS('_', 'dbt_shop_rating', action)
			WHERE content_type = 'dbtech_shop_rating'
				AND action IN('delete', 'edit')
		");
	}
	
	/**
	 *
	 */
	public function upgrade906010033Step1()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_dbtech_shop_item', function(Alter $table)
		{
			$table->addColumn('display_in_list', 'tinyint')->after('item_filters');
		});
	}
	
	/**
	 * @throws \XF\Db\Exception
	 */
	public function upgrade906010033Step2()
	{
		$this->executeUpgradeQuery("
			UPDATE xf_dbtech_shop_item
			SET display_in_list = 1
		");
	}
	
	/**
	 * @throws \XF\Db\Exception
	 */
	public function upgrade906010035Step1()
	{
		$defaultValue = [
			'enabled' => 1,
			'right_position' => false,
			'right_text' => true
		];
		
		$this->query("
			UPDATE xf_option
			SET default_value = ?
			WHERE option_id = 'dbtech_shop_navbar'
		", json_encode($defaultValue));
		
		$navbarDefaults = json_decode($this->db()->fetchOne("
			SELECT option_value
			FROM xf_option
			WHERE option_id = 'dbtech_shop_navbar'
		"), true);
		
		$update = false;
		foreach (array_keys($defaultValue) AS $key)
		{
			if (!isset($navbarDefaults[$key]))
			{
				$update = true;
				$navbarDefaults[$key] = $defaultValue[$key];
			}
		}
		
		if ($update)
		{
			$this->query("
				UPDATE xf_option
				SET option_value = ?
				WHERE option_id = 'dbtech_shop_navbar'
			", json_encode($navbarDefaults));
		}
	}
	
	public function upgrade906010036Step1()
	{
		$defaultValue = [
			'width' => '',
			'height' => '',
			'disableScaling' => false
		];
		
		$this->query("
			UPDATE xf_option
			SET default_value = ?
			WHERE option_id = 'dbtechShopItemIconMaxDimensions'
		", json_encode($defaultValue));
		
		$dimensionDefaults = json_decode($this->db()->fetchOne("
			SELECT option_value
			FROM xf_option
			WHERE option_id = 'dbtechShopItemIconMaxDimensions'
		"), true);
		
		$update = false;
		foreach (array_keys($defaultValue) AS $key)
		{
			if (!isset($dimensionDefaults[$key]))
			{
				$update = true;
				$dimensionDefaults[$key] = $defaultValue[$key];
			}
		}
		
		if ($update)
		{
			$this->query("
				UPDATE xf_option
				SET option_value = ?
				WHERE option_id = 'dbtechShopItemIconMaxDimensions'
			", json_encode($dimensionDefaults));
		}
	}
	
	
	
	/**
	 *
	 */
	public function upgrade906010037Step1()
	{
		$db = $this->db();
		
		$db->beginTransaction();
		
		$db->emptyTable('xf_dbtech_shop_lottery_history');
		
		$lotteries = $db->fetchAll('
			SELECT lottery_id, drawn_numbers
			FROM xf_dbtech_shop_lottery
		');
		foreach ($lotteries as $lottery)
		{
			$drawnNumbers = json_decode($lottery['drawn_numbers'], true);
			
			foreach ($drawnNumbers as $dateline => $numbers)
			{
				$db->insert('xf_dbtech_shop_lottery_history', [
					'lottery_id' => $lottery['lottery_id'],
					'drawn_numbers' => json_encode($numbers),
					'draw_date' => $dateline,
					'tickets_sold' => 0
				]);
			}
		}
		
		$db->commit();
	}
	
	/**
	 * @param $previousVersion
	 * @param array $stateChanges
	 */
	public function postUpgrade($previousVersion, array &$stateChanges)
	{
		if ($this->applyDefaultPermissions($previousVersion))
		{
			// since we're running this after data imports, we need to trigger a permission rebuild
			// if we changed anything
			$this->app->jobManager()->enqueueUnique(
				'permissionRebuild',
				'XF:PermissionRebuild',
				[],
				false
			);
		}
		
		/** @var \DBTech\Shop\Repository\ItemPrefix $itemPrefixRepo */
		$itemPrefixRepo = \XF::repository('DBTech\Shop:ItemPrefix');
		$itemPrefixRepo->rebuildPrefixCache();
		
		/** @var \DBTech\Shop\Repository\ItemField $itemFieldRepo */
		$itemFieldRepo = \XF::repository('DBTech\Shop:ItemField');
		$itemFieldRepo->rebuildFieldCache();
		
		if ($previousVersion && $previousVersion < 906010011)
		{
			/** @var \XF\Service\RebuildNestedSet $service */
			$service = \XF::service('XF:RebuildNestedSet', 'DBTech\Shop:Category', [
				'parentField' => 'parent_category_id'
			]);
			$service->rebuildNestedSetInfo();
			
			$this->app->jobManager()->enqueueUnique(
				'dbtechShopCategoryRebuild',
				'DBTech\Shop:Category',
				[],
				false
			);
		}
	}
	
	
	// ################################ UNINSTALL ####################
	
	public function uninstallStep1()
	{
		$sm = $this->schemaManager();
		
		foreach (array_keys($this->getTables()) AS $tableName)
		{
			$sm->dropTable($tableName);
		}
		
		foreach ($this->getDefaultWidgetSetup() AS $widgetKey => $widgetFn)
		{
			$this->deleteWidget($widgetKey);
		}
	}
	
	public function uninstallStep2()
	{
		$sm = $this->schemaManager();
		
		$sm->alterTable('xf_user', function (Alter $table)
		{
			$table->dropColumns([
				'dbtech_shop_points',
				'dbtech_shop_purchase',
				'dbtech_shop_purchases',
				'dbtech_shop_immunity',
				'dbtech_shop_pendingtrades',
				'dbtech_shop_item_count'
			]);
		});
	}
	
	public function uninstallStep3()
	{
		$db = $this->db();
		
		$contentTypes = [
			'dbtech_shop'
		];
		$this->uninstallContentTypeData($contentTypes);
		
		$db->beginTransaction();
		
		// Get rid of change logs
		$db->delete('xf_change_log', "content_type LIKE 'dbtech_shop_%'");
		$db->delete('xf_change_log', "field LIKE 'dbtech_shop_%'");
		
		foreach ($this->getAdminPermissions() AS $permissionId)
		{
			$db->delete('xf_admin_permission_entry', "admin_permission_id = '$permissionId'");
		}
		
		$db->delete('xf_permission_entry', "permission_group_id = 'dbtechShop'");
		$db->delete('xf_permission_entry', "permission_group_id = 'dbtechShopAdmin'");
		$db->delete('xf_permission_entry', "permission_group_id = 'dbtechShopTradePost'");
		$db->delete('xf_permission_entry_content', "permission_group_id = 'dbtechShop'");
		$db->delete('xf_permission_entry_content', "permission_group_id = 'dbtechShopAdmin'");
		$db->delete('xf_permission_entry_content', "permission_group_id = 'dbtechShopTradePost'");
		
		$registryEntries = [
			'dbtShopCategories',
			'dbtShopCurrencies',
			'dbtShopItemFieldsInfo',
			'dbtShopItems',
			'dbtShopPrefixes',
			'dbtShopUserNameStyle',
			'dbtShopUserTitleStyle'
		];
		foreach ($registryEntries AS $entry)
		{
			try
			{
				\XF::registry()->delete($entry);
			}
			catch (\Exception $e) {}
		}
		
		$db->commit();
	}
	
	// ############################# TABLE / DATA DEFINITIONS ##############################
	
	/**
	 * @return array
	 */
	protected function getTables()
	{
		$tables = [];
		
		$tables['xf_dbtech_shop_bank'] = function(Create $table)
		{
			$table->addColumn('user_id', 'int');
			$table->addColumn('currency_id', 'int');
			$table->addColumn('points', 'double')->unsigned(false)->setDefault(0);
			$table->addColumn('last_interest_date', 'int')->setDefault(1);
			$table->addPrimaryKey(['user_id', 'currency_id']);
		};
		
		$tables['xf_dbtech_shop_cart'] = function(Create $table)
		{
			$table->addColumn('user_id', 'int');
			$table->addColumn('item_id', 'int');
			$table->addColumn('recipient_user_id', 'int');
			$table->addColumn('recipient_username', 'varchar', 50);
			$table->addColumn('quantity', 'int')->setDefault(0);
			$table->addColumn('message', 'mediumblob')->nullable(true);
			$table->addPrimaryKey(['user_id', 'item_id']);
		};
		
		$tables['xf_dbtech_shop_category'] = function (Create $table)
		{
			$table->addColumn('category_id', 'int')->autoIncrement();
			$table->addColumn('title', 'varchar', 100);
			$table->addColumn('description', 'text');
			$table->addColumn('parent_category_id', 'int')->setDefault(0);
			$table->addColumn('display_order', 'int')->setDefault(0);
			$table->addColumn('lft', 'int')->setDefault(0);
			$table->addColumn('rgt', 'int')->setDefault(0);
			$table->addColumn('depth', 'smallint', 5)->setDefault(0);
			$table->addColumn('breadcrumb_data', 'blob');
			$table->addColumn('item_count', 'int')->setDefault(0);
			$table->addColumn('last_update', 'int')->setDefault(0);
			$table->addColumn('last_item_title', 'varchar', 100)->setDefault('');
			$table->addColumn('last_item_id', 'int')->setDefault(0);
			$table->addColumn('prefix_cache', 'mediumblob');
			$table->addColumn('field_cache', 'mediumblob');
			$table->addColumn('item_filters', 'blob');
			$table->addColumn('require_prefix', 'tinyint', 3)->setDefault(0);
			$table->addColumn('thread_node_id', 'int')->setDefault(0);
			$table->addColumn('thread_prefix_id', 'int')->setDefault(0);
			$table->addColumn('item_update_notify', 'enum')->values(['thread', 'reply'])->setDefault('thread');
			$table->addColumn('always_moderate_create', 'tinyint', 3)->setDefault(0);
			$table->addColumn('always_moderate_update', 'tinyint', 3)->setDefault(0);
			$table->addColumn('min_tags', 'smallint', 5)->setDefault(0);
			$table->addColumn('sales', 'int')->setDefault(0);
			$table->addColumn('sales_amounts', 'mediumblob')->nullable(true);
			$table->addColumn('latest_customer_id', 'int')->setDefault(0);
			$table->addColumn('latest_sale_id', 'int')->setDefault(0);
			$table->addColumn('beneficiary', 'int')->unsigned(false)->setDefault(-1);
			$table->addColumn('beneficiary_split', 'tinyint', 3)->setDefault(100);
			$table->addColumn('num_ratings', 'int')->setDefault(0);
			$table->addColumn('average_rating', 'double')->setDefault(0);
			$table->addColumn('positive_percent', 'double')->setDefault(0);
			$table->addColumn('negative_percent', 'double')->setDefault(0);
			$table->addColumn('neutral_percent', 'double')->setDefault(0);
			$table->addColumn('can_have_feedback', 'tinyint', 3)->setDefault(1);
			$table->addKey(['parent_category_id', 'lft']);
			$table->addKey(['lft', 'rgt']);
		};
		
		$tables['xf_dbtech_shop_category_field'] = function(Create $table)
		{
			$table->addColumn('category_id', 'int');
			$table->addColumn('field_id', 'varbinary', 25);
			$table->addPrimaryKey(['category_id', 'field_id']);
			$table->addKey('field_id');
		};
		
		$tables['xf_dbtech_shop_category_prefix'] = function (Create $table)
		{
			$table->addColumn('category_id', 'int');
			$table->addColumn('prefix_id', 'int');
			$table->addPrimaryKey(['category_id', 'prefix_id']);
			$table->addKey('prefix_id');
		};
		
		$tables['xf_dbtech_shop_category_watch'] = function (Create $table)
		{
			$table->addColumn('user_id', 'int');
			$table->addColumn('category_id', 'int');
			$table->addColumn('notify_on', 'enum')->values(['', 'item']);
			$table->addColumn('send_alert', 'tinyint', 3);
			$table->addColumn('send_email', 'tinyint', 3);
			$table->addColumn('include_children', 'tinyint', 3);
			$table->addPrimaryKey(['user_id', 'category_id']);
			$table->addKey(['category_id', 'notify_on'], 'category_id_notify_on');
		};
		
		$tables['xf_dbtech_shop_currency'] = function(Create $table)
		{
			$table->addColumn('currency_id', 'int')->autoIncrement();
			$table->addColumn('title', 'varchar', 50)->setDefault('');
			$table->addColumn('description', 'blob')->nullable(true);
			$table->addColumn('active', 'tinyint', 3)->setDefault(1);
			$table->addColumn('display_order', 'int')->setDefault(10);
			$table->addColumn('table', 'varchar', 255)->setDefault('');
			$table->addColumn('use_table_prefix', 'tinyint', 3)->setDefault(1);
			$table->addColumn('column', 'varchar', 255)->setDefault('');
			$table->addColumn('use_user_id', 'tinyint', 3)->setDefault(1);
			$table->addColumn('user_id_column', 'varchar', '255')->setDefault('user_id');
			$table->addColumn('decimals', 'tinyint', 2)->setDefault(0);
			$table->addColumn('privacy', 'tinyint', 3)->setDefault(2);
			$table->addColumn('blacklist', 'tinyint', 3)->setDefault(0);
			$table->addColumn('prefix', 'varchar', 50)->setDefault('');
			$table->addColumn('suffix', 'varchar', 50)->setDefault('');
			$table->addColumn('is_display_currency', 'tinyint', 3)->setDefault(0);
			$table->addColumn('can_bank', 'tinyint', 3)->setDefault(1);
			$table->addColumn('can_steal', 'tinyint', 3)->setDefault(1);
			$table->addColumn('can_trade', 'tinyint', 3)->setDefault(1);
			$table->addColumn('steal_protect', 'double')->setDefault('100.00');
			$table->addColumn('interest', 'double')->unsigned(false)->setDefault(0);
			$table->addColumn('customshops', 'tinyint', 3)->setDefault(1);
			$table->addColumn('per_reply', 'int')->setDefault(1);
			$table->addColumn('per_thread', 'int')->setDefault(1);
			$table->addColumn('credits_currency_id', 'int')->setDefault(0);
			$table->addColumn('sidebar', 'tinyint', 3)->setDefault(1);
			$table->addColumn('postbit', 'tinyint', 3)->setDefault(1);
		};
		
		$tables['xf_dbtech_shop_item'] = function(Create $table)
		{
			$table->addColumn('item_id', 'int')->autoIncrement();
			$table->addColumn('category_id', 'int')->setDefault(0);
			$table->addColumn('title', 'varchar', 50)->setDefault('');
			$table->addColumn('description', 'mediumblob')->nullable(true);
			$table->addColumn('item_state', 'enum')->values(['visible', 'moderated', 'deleted'])->setDefault('visible');
			$table->addColumn('display_order', 'int')->setDefault(10);
			$table->addColumn('creation_date', 'int')->setDefault(0);
			$table->addColumn('last_update', 'int')->setDefault(0);
			$table->addColumn('purchases', 'int')->setDefault(0);
			$table->addColumn('price', 'double')->setDefault(0);
			$table->addColumn('user_criteria', 'mediumblob')->nullable(true);
			$table->addColumn('code', 'mediumblob')->nullable(true);
			$table->addColumn('item_type_id', 'varchar', 50)->setDefault('');
			$table->addColumn('thread_node_id', 'int')->setDefault(0);
			$table->addColumn('thread_prefix_id', 'int')->setDefault(0);
			$table->addColumn('discussion_thread_id', 'int')->setDefault(0);
			$table->addColumn('field_cache', 'mediumblob');
			$table->addColumn('item_fields', 'mediumblob');
			$table->addColumn('item_filters', 'blob');
			$table->addColumn('display_in_list', 'tinyint')->after('item_filters');
			$table->addColumn('is_giftable', 'tinyint', 3)->setDefault(0);
			$table->addColumn('send_gift_pm', 'tinyint', 3)->setDefault(1);
			$table->addColumn('currency_id', 'int')->setDefault(0);
			$table->addColumn('length_amount', 'tinyint', 3);
			$table->addColumn('length_unit', 'enum')->values(['day', 'month', 'year', '']);
			$table->addColumn('user_id', 'int')->setDefault(0);
			$table->addColumn('username', 'varchar', 50);
			$table->addColumn('ip_id', 'int')->setDefault(0);
			$table->addColumn('reaction_score', 'int')->setDefault(0);
			$table->addColumn('reactions', 'blob');
			$table->addColumn('reaction_users', 'blob');
			$table->addColumn('warning_id', 'int')->setDefault(0);
			$table->addColumn('warning_message', 'varchar', 255)->setDefault('');
			$table->addColumn('is_unique', 'tinyint', 3)->setDefault(1);
			$table->addColumn('is_only_giftable', 'tinyint', 3)->setDefault(0);
			$table->addColumn('moderation', 'tinyint', 3)->setDefault(0);
			$table->addColumn('can_reconfigure', 'tinyint', 3)->setDefault(1);
			$table->addColumn('can_regift', 'tinyint', 3)->setDefault(1);
			$table->addColumn('is_always_hidden', 'tinyint', 3)->setDefault(0);
			$table->addColumn('purchasable_thread_creation', 'tinyint', 3)->setDefault(0);
			$table->addColumn('purchasable_thread_page', 'tinyint', 3)->setDefault(0);
			$table->addColumn('enabled_custom_shops', 'tinyint', 3)->setDefault(0);
			$table->addColumn('is_stealth_item', 'tinyint', 3)->setDefault(0);
			$table->addColumn('is_exclusive', 'tinyint', 3)->setDefault(0);
			$table->addColumn('auto_discard', 'tinyint', 3)->setDefault(0);
			$table->addColumn('auto_discard_expiry', 'tinyint', 3)->setDefault(0);
			$table->addColumn('buyback_currency_id', 'int')->setDefault(0);
			$table->addColumn('buyback_price', 'double')->setDefault(0);
			$table->addColumn('buyback_time', 'int')->setDefault(0);
			$table->addColumn('buyback_replenish', 'tinyint', 3)->setDefault(1);
			$table->addColumn('notifications', 'mediumblob')->nullable(true);
			$table->addColumn('notifications_config', 'mediumblob')->nullable(true);
			$table->addColumn('stock', 'int')->unsigned(false)->setDefault('0');
			$table->addColumn('maxstock', 'int')->unsigned(false)->setDefault('0');
			$table->addColumn('refill_time', 'int')->setDefault(0);
			$table->addColumn('last_refill_date', 'int')->setDefault(0);
			$table->addColumn('rating_count', 'int')->setDefault(0);
			$table->addColumn('rating_sum', 'int')->setDefault(0);
			$table->addColumn('rating_avg', 'float', '')->setDefault(0);
			$table->addColumn('rating_weighted', 'float', '')->setDefault(0);
			$table->addColumn('review_count', 'int')->setDefault(0);
			$table->addColumn('icon_date', 'int')->setDefault(0);
			$table->addColumn('prefix_id', 'int')->setDefault(0);
			$table->addColumn('tags', 'mediumblob');
			$table->addKey(['category_id', 'last_update'], 'category_last_update');
			$table->addKey(['category_id', 'rating_weighted'], 'category_rating_weighted');
			$table->addKey('last_update');
			$table->addKey('rating_weighted');
			$table->addKey(['user_id', 'last_update']);
			$table->addKey('discussion_thread_id');
			$table->addKey('prefix_id');
			
		};
		
		$tables['xf_dbtech_shop_item_field'] = function(Create $table)
		{
			$table->addColumn('field_id', 'varbinary', 25);
			$table->addColumn('display_group', 'varchar', 25)->setDefault('above_info');
			$table->addColumn('display_order', 'int')->setDefault(1);
			$table->addColumn('field_type', 'varbinary', 25)->setDefault('textbox');
			$table->addColumn('field_choices', 'blob');
			$table->addColumn('match_type', 'varbinary', 25)->setDefault('none');
			$table->addColumn('match_params', 'blob');
			$table->addColumn('max_length', 'int')->setDefault(0);
			$table->addColumn('required', 'tinyint', 3)->setDefault(0);
			$table->addColumn('user_editable', 'enum')->values(['yes', 'once', 'never'])->setDefault('yes');
			$table->addColumn('moderator_editable', 'tinyint', 3)->setDefault(0);
			$table->addColumn('display_template', 'text');
			$table->addPrimaryKey('field_id');
			$table->addKey(['display_group', 'display_order'], 'display_group_order');
		};
		
		$tables['xf_dbtech_shop_item_field_value'] = function(Create $table)
		{
			$table->addColumn('item_id', 'int');
			$table->addColumn('field_id', 'varbinary', 25);
			$table->addColumn('field_value', 'mediumtext');
			$table->addPrimaryKey(['item_id', 'field_id']);
			$table->addKey('field_id');
		};
		
		$tables['xf_dbtech_shop_item_filter_map'] = function(Create $table)
		{
			$table->addColumn('item_id', 'int');
			$table->addColumn('filter_id', 'varbinary', 25);
			$table->addPrimaryKey(['item_id', 'filter_id']);
			$table->addKey('filter_id');
		};
		
		$tables['xf_dbtech_shop_item_prefix'] = function(Create $table)
		{
			$table->addColumn('prefix_id', 'int')->autoIncrement();
			$table->addColumn('prefix_group_id', 'int');
			$table->addColumn('display_order', 'int');
			$table->addColumn('materialized_order', 'int');
			$table->addColumn('css_class', 'varchar', 50)->setDefault('');
			$table->addColumn('allowed_user_group_ids', 'blob');
			$table->addKey('materialized_order');
		};
		
		$tables['xf_dbtech_shop_item_prefix_group'] = function(Create $table)
		{
			$table->addColumn('prefix_group_id', 'int')->autoIncrement();
			$table->addColumn('display_order', 'int');
		};
		
		$tables['xf_dbtech_shop_item_rating'] = function(Create $table)
		{
			$table->addColumn('item_rating_id', 'int')->autoIncrement();
			$table->addColumn('user_id', 'int');
			$table->addColumn('rating', 'tinyint', 3);
			$table->addColumn('rating_date', 'int');
			$table->addColumn('message', 'mediumtext');
			$table->addColumn('item_id', 'int');
			$table->addColumn('author_response', 'mediumtext');
			$table->addColumn('is_review', 'tinyint', 3)->setDefault(0);
			$table->addColumn('count_rating', 'tinyint', 3)->setDefault(1);
			$table->addColumn('rating_state', 'enum')->values(['visible','deleted'])->setDefault('visible');
			$table->addColumn('warning_id', 'int')->setDefault(0);
			$table->addColumn('is_anonymous', 'tinyint', 3)->setDefault(0);
			$table->addUniqueKey(['item_id', 'user_id'], 'item_user_id');
			$table->addKey('user_id');
			$table->addKey(['count_rating', 'item_id']);
			$table->addKey(['item_id', 'rating_date']);
			$table->addKey('rating_date');
		};
		
		$tables['xf_dbtech_shop_item_watch'] = function(Create $table)
		{
			$table->addColumn('user_id', 'int');
			$table->addColumn('item_id', 'int');
			$table->addColumn('email_subscribe', 'tinyint', 3)->setDefault(0);
			$table->addPrimaryKey(['user_id', 'item_id']);
			$table->addKey(['item_id', 'email_subscribe']);
		};
		
		$tables['xf_dbtech_shop_lottery'] = function(Create $table)
		{
			$table->addColumn('lottery_id', 'int')->autoIncrement();
			$table->addColumn('title', 'varchar', 50)->setDefault('');
			$table->addColumn('description', 'mediumblob')->nullable(true);
			$table->addColumn('active', 'tinyint', 3)->setDefault(1);
			$table->addColumn('ticket_price', 'double')->setDefault(0);
			$table->addColumn('currency_id', 'int')->setDefault(0);
			$table->addColumn('numbers', 'mediumblob')->nullable(true);
			$table->addColumn('draw_interval_days', 'int')->setDefault(0);
			$table->addColumn('next_draw_date', 'int')->setDefault(0);
			$table->addColumn('previous_draw_date', 'int')->setDefault(0);
			$table->addColumn('prizes', 'mediumblob');
			$table->addColumn('drawn_numbers', 'mediumblob')->nullable(true);
			$table->addColumn('tickets_sold', 'int')->setDefault(0);
		};
		
		
		$tables['xf_dbtech_shop_lottery_history'] = function(Create $table)
		{
			$table->addColumn('lottery_history_id', 'int')->autoIncrement();
			$table->addColumn('lottery_id', 'int')->setDefault(0);
			$table->addColumn('drawn_numbers', 'mediumblob')->nullable(true);
			$table->addColumn('draw_date', 'int')->setDefault(0);
			$table->addColumn('tickets_sold', 'int')->setDefault(0);
		};
		
		$tables['xf_dbtech_shop_lottery_prize'] = function(Create $table)
		{
			$table->addColumn('lottery_prize_id', 'int')->autoIncrement();
			$table->addColumn('title', 'varchar', 50)->setDefault('');
			$table->addColumn('description', 'mediumblob')->nullable(true);
			$table->addColumn('active', 'tinyint', 3)->setDefault(1);
			$table->addColumn('numbers', 'mediumblob')->nullable(true);
		};
		
		$tables['xf_dbtech_shop_lottery_prize_map'] = function(Create $table)
		{
			$table->addColumn('lottery_id', 'int');
			$table->addColumn('lottery_prize_id', 'int');
			$table->addColumn('currency_id', 'int');
			$table->addColumn('prize_amount', 'double')->setDefault(0);
			$table->addPrimaryKey(['lottery_id', 'lottery_prize_id']);
			$table->addKey('currency_id');
		};
		
		$tables['xf_dbtech_shop_lottery_ticket'] = function(Create $table)
		{
			$table->addColumn('lottery_ticket_id', 'int')->autoIncrement();
			$table->addColumn('lottery_id', 'int')->setDefault(0);
			$table->addColumn('user_id', 'int')->setDefault(0);
			$table->addColumn('ticket_date', 'int')->setDefault(0);
			$table->addColumn('draw_date', 'int')->setDefault(0);
			$table->addColumn('numbers', 'mediumblob')->nullable(true);
			$table->addColumn('lottery_prize_id', 'int')->setDefault(0);
			$table->addKey(['lottery_id', 'user_id'], 'lottery_user_id');
			$table->addKey(['lottery_id', 'draw_date'], 'lottery_id_draw_date');
		};
		
		$tables['xf_dbtech_shop_purchase'] = function(Create $table)
		{
			$table->addColumn('purchase_id', 'int')->autoIncrement();
			$table->addColumn('user_id', 'int');
			$table->addColumn('buyer_user_id', 'int');
			$table->addColumn('buyer_username', 'varchar', 50)->setDefault('');
			$table->addColumn('item_id', 'int');
			$table->addColumn('dateline', 'int')->setDefault(0);
			$table->addColumn('configuration', 'mediumblob')->nullable(true);
			$table->addColumn('message', 'mediumblob')->nullable(true);
			$table->addColumn('active', 'tinyint', 3)->setDefault(1);
			$table->addColumn('hidden', 'tinyint', 3)->setDefault(0);
			$table->addColumn('configured', 'tinyint', 3)->setDefault(0);
			$table->addColumn('gifted', 'tinyint', 3)->setDefault(0);
			$table->addColumn('traded', 'tinyint', 3)->setDefault(0);
			$table->addColumn('feedback_status', 'tinyint', 3)->setDefault(0);
			$table->addColumn('expiry_date', 'int')->setDefault(0);
			$table->addColumn('discussion_thread_id', 'int')->setDefault(0);
			$table->addKey('item_id');
			$table->addKey('user_id');
			$table->addKey('buyer_user_id');
			$table->addKey('discussion_thread_id');
		};
		
		$tables['xf_dbtech_shop_thread_ban'] = function(Create $table)
		{
			$table->addColumn('thread_id', 'int')->setDefault(0);
			$table->addColumn('user_id', 'int')->setDefault(0);
			$table->addPrimaryKey(['thread_id', 'user_id']);
		};
		
		$tables['xf_dbtech_shop_trade'] = function(Create $table)
		{
			$table->addColumn('trade_id', 'int')->autoIncrement();
			$table->addColumn('creator_user_id', 'int')->setDefault(0);
			$table->addColumn('creator_username', 'varchar', 50);
			$table->addColumn('recipient_user_id', 'int')->setDefault(0);
			$table->addColumn('recipient_username', 'varchar', 50);
			$table->addColumn('created_date', 'int')->setDefault(0);
			$table->addColumn('updated_date', 'int')->setDefault(0);
			$table->addColumn('trade_state', 'enum')->values(['pending','open','awaiting_accept','accepted','cancelled'])->setDefault('pending');
			$table->addColumn('creator_accepted', 'tinyint', 3)->setDefault(0);
			$table->addColumn('recipient_accepted', 'tinyint', 3)->setDefault(0);
			$table->addColumn('conversation_id', 'int')->setDefault(0);
			$table->addKey('creator_user_id');
			$table->addKey('recipient_user_id');
		};
		
		$tables['xf_dbtech_shop_trade_offer'] = function(Create $table)
		{
			$table->addColumn('trade_id', 'int');
			$table->addColumn('user_id', 'int')->setDefault(0);
			$table->addColumn('content_type', 'varchar', 25)->setDefault('dbtech_shop_purchase');
			$table->addColumn('content_id', 'int');
			$table->addColumn('quantity', 'int')->setDefault(0);
			$table->addColumn('finalized', 'tinyint')->setDefault(0);
			$table->addPrimaryKey(['trade_id', 'user_id', 'content_type', 'content_id']);
		};
		
		$tables['xf_dbtech_shop_trade_post'] = function(Create $table)
		{
			$table->addColumn('trade_post_id', 'int')->autoIncrement();
			$table->addColumn('trade_id', 'int');
			$table->addColumn('user_id', 'int');
			$table->addColumn('username', 'varchar', 50);
			$table->addColumn('post_date', 'int');
			$table->addColumn('message', 'mediumtext');
			$table->addColumn('ip_id', 'int')->setDefault(0);
			$table->addColumn('message_state', 'enum')->values(['visible','moderated','deleted'])->setDefault('visible');
			$table->addColumn('attach_count', 'smallint', 5)->setDefault(0);
			$table->addColumn('reaction_score', 'int')->unsigned(false)->setDefault(0);
			$table->addColumn('reactions', 'blob')->nullable();
			$table->addColumn('reaction_users', 'blob');
			$table->addColumn('comment_count', 'int')->setDefault(0);
			$table->addColumn('first_comment_date', 'int')->setDefault(0);
			$table->addColumn('last_comment_date', 'int')->setDefault(0);
			$table->addColumn('latest_comment_ids', 'blob');
			$table->addColumn('warning_id', 'int')->setDefault(0);
			$table->addColumn('warning_message', 'varchar', 255)->setDefault('');
			$table->addColumn('embed_metadata', 'blob')->nullable();
			$table->addKey(['trade_id', 'post_date']);
			$table->addKey('user_id');
			$table->addKey('post_date');
		};
		
		$tables['xf_dbtech_shop_trade_post_comment'] = function(Create $table)
		{
			$table->addColumn('trade_post_comment_id', 'int')->autoIncrement();
			$table->addColumn('trade_post_id', 'int');
			$table->addColumn('user_id', 'int');
			$table->addColumn('username', 'varchar', 50);
			$table->addColumn('comment_date', 'int');
			$table->addColumn('message', 'mediumtext');
			$table->addColumn('ip_id', 'int')->setDefault(0);
			$table->addColumn('message_state', 'enum')->values(['visible','moderated','deleted'])->setDefault('visible');
			$table->addColumn('reaction_score', 'int')->unsigned(false)->setDefault(0);
			$table->addColumn('reactions', 'blob')->nullable();
			$table->addColumn('reaction_users', 'blob');
			$table->addColumn('warning_id', 'int')->setDefault(0);
			$table->addColumn('warning_message', 'varchar', 255)->setDefault('');
			$table->addColumn('embed_metadata', 'blob')->nullable();
			$table->addKey(['trade_post_id', 'comment_date']);
			$table->addKey('user_id');
			$table->addKey('comment_date');
		};
		
		$tables['xf_dbtech_shop_trading_card'] = function(Create $table)
		{
			$table->addColumn('trading_card_id', 'int')->autoIncrement();
			$table->addColumn('title', 'varchar', 50)->setDefault('');
			$table->addColumn('description', 'mediumblob')->nullable(true);
			$table->addColumn('active', 'tinyint', 3)->setDefault(1);
			$table->addColumn('rarity', 'tinyint', 3)->setDefault(1);
			$table->addColumn('filename', 'varchar', 255)->setDefault('');
		};
		
		$tables['xf_dbtech_shop_trading_card_collection'] = function(Create $table)
		{
			$table->addColumn('trading_card_id', 'int');
			$table->addColumn('user_id', 'int');
			$table->addColumn('trade_locked', 'tinyint', 3)->setDefault(0);
			$table->addPrimaryKey(['trading_card_id', 'user_id']);
		};
		
		$tables['xf_dbtech_shop_transaction_log'] = function(Create $table)
		{
			$table->addColumn('transaction_log_id', 'int')->autoIncrement();
			$table->addColumn('user_id', 'int')->setDefault(0);
			$table->addColumn('recipient_user_id', 'int')->setDefault(0);
			$table->addColumn('dateline', 'int')->setDefault(0);
			$table->addColumn('ip_id', 'int', 10)->setDefault(0);
			$table->addColumn('action', 'varchar', 50)->setDefault('');
			$table->addColumn('content_type', 'varbinary', 25);
			$table->addColumn('content_id', 'int')->setDefault(0);
			$table->addColumn('info', 'mediumblob')->nullable(true);
			$table->addKey('user_id');
			$table->addKey('recipient_user_id');
		};
		
		return $tables;
	}
	
	/**
	 * @return array
	 */
	protected function getAdminPermissions()
	{
		return [];
	}
	
	/**
	 * @return array
	 */
	protected function getDefaultWidgetSetup()
	{
		return [
			'dbtech_shop_profilemusic' => function($key, array $options = [])
			{
				$options = array_replace([], $options);
				
				$this->createWidget(
					$key,
					'dbtech_shop_profilemusic',
					[
						'positions' => [
							'member_view_sidebar' => 100
						],
						'options' => $options
					]
				);
			},
			'dbtech_shop_wallet' => function($key, array $options = [])
			{
				$options = array_replace([], $options);
				
				$this->createWidget(
					$key,
					'dbtech_shop_wallet',
					[
						'positions' => [
							'dbtech_shop_overview_sidenav' => 100,
							'dbtech_shop_category_sidenav' => 100,
							'dbtech_shop_item_sidebar' => 100,
							'dbtech_shop_bank_sidebar' => 100,
							'dbtech_shop_lottery_sidebar' => 100,
							'dbtech_shop_trade_sidebar' => 100,
							'dbtech_shop_steal_sidebar' => 100,
						],
						'options' => $options
					],
					'Wallet'
				);
			},
			'dbtech_shop_cart' => function($key, array $options = [])
			{
				$options = array_replace([], $options);
				
				$this->createWidget(
					$key,
					'dbtech_shop_cart',
					[
						'positions' => [
							'dbtech_shop_overview_sidenav' => 100,
							'dbtech_shop_category_sidenav' => 100,
							'dbtech_shop_item_sidebar' => 100
						],
						'options' => $options
					],
					'Cart'
				);
			},
			
			'dbtech_shop_list_top_items' => function($key, array $options = [])
			{
				$options = array_replace([], $options);
				
				$this->createWidget(
					$key,
					'dbt_shop_top_items',
					[
						'positions' => [
							'dbtech_shop_overview_sidenav' => 100,
							'dbtech_shop_category_sidenav' => 100,
						],
						'options' => $options
					]
				);
			},
			'dbtech_shop_overview_latest_reviews' => function($key, array $options = [])
			{
				$options = array_replace([], $options);
				
				$this->createWidget(
					$key,
					'dbt_shop_latest_reviews',
					[
						'positions' => ['dbtech_shop_overview_sidenav' => 200],
						'options' => $options
					]
				);
			},
			'dbtech_shop_overview_top_authors' => function($key, array $options = [])
			{
				$options = array_replace([
					'member_stat_key' => 'dbtech_shop_most_items'
				], $options);
				
				$this->createWidget(
					$key,
					'member_stat',
					[
						'positions' => ['dbtech_shop_overview_sidenav' => 300],
						'options' => $options
					]
				);
			},
			'dbtech_shop_whats_new_overview_new_items' => function($key, array $options = [])
			{
				$options = array_replace([
					'limit' => 10,
					'style' => 'full'
				], $options);
				
				$this->createWidget(
					$key,
					'dbt_shop_new_items',
					[
						'positions' => ['whats_new_overview' => 200],
						'options' => $options
					]
				);
			},
			'dbtech_shop_forum_overview_new_items' => function($key, array $options = [])
			{
				$options = array_replace([], $options);
				
				$this->createWidget(
					$key,
					'dbt_shop_new_items',
					[
						'positions' => [
							'forum_list_sidebar' => 38,
							'forum_new_posts_sidebar' => 28
						],
						'options' => $options
					]
				);
			},
		];
	}
	
	/**
	 * @param $key
	 * @param array $options
	 *
	 * @throws \InvalidArgumentException
	 */
	protected function insertNamedWidget($key, array $options = [])
	{
		$widgets = $this->getDefaultWidgetSetup();
		if (!isset($widgets[$key]))
		{
			throw new \InvalidArgumentException("Unknown widget '$key'");
		}
		
		$widgetFn = $widgets[$key];
		$widgetFn($key, $options);
	}
	
	/**
	 * @param $oldGroupId
	 * @param $oldPermissionId
	 * @param $newGroupId
	 * @param $newPermissionId
	 *
	 * @throws \XF\Db\Exception
	 */
	protected function renamePermission($oldGroupId, $oldPermissionId, $newGroupId, $newPermissionId)
	{
		$this->executeUpgradeQuery('
			UPDATE xf_permission_entry
			SET permission_group_id = ?, permission_id = ?
			WHERE permission_group_id = ?
				AND permission_id = ?
        ', [$newGroupId, $newPermissionId, $oldGroupId, $oldPermissionId]);
		
		$this->executeUpgradeQuery('
			UPDATE xf_permission_entry_content
			SET permission_group_id = ?, permission_id = ?
			WHERE permission_group_id = ?
				AND permission_id = ?
        ', [$newGroupId, $newPermissionId, $oldGroupId, $oldPermissionId]);
		
		$this->executeUpgradeQuery('
			DELETE FROM xf_permission_entry
			WHERE permission_group_id = ?
				AND permission_id = ?
        ', [$oldGroupId, $oldPermissionId]);
		
		$this->executeUpgradeQuery('
			DELETE FROM xf_permission_entry_content
			WHERE permission_group_id = ?
				AND permission_id = ?
        ', [$oldGroupId, $oldPermissionId]);
	}
	
	/**
	 * @param null $previousVersion
	 *
	 * @return bool
	 */
	protected function applyDefaultPermissions($previousVersion = null)
	{
		$applied = false;
		
		if (!$previousVersion)
		{
			// Regular perms
			$this->applyGlobalPermission('dbtech_shop', 'viewLottery', 'general', 'viewNode');
			$this->applyGlobalPermission('dbtech_shop', 'bank', 'general', 'viewNode');
			$this->applyGlobalPermission('dbtech_shop', 'steal', 'forum', 'postThread');
			$this->applyGlobalPermission('dbtech_shop', 'trade', 'forum', 'postThread');
			
			$applied = true;
		}
		
		if (!$previousVersion || $previousVersion < 906010011)
		{
			// Regular perms
			$this->applyGlobalPermission('dbtech_shop', 'view', 'general', 'viewNode');
			$this->applyGlobalPermission('dbtech_shop', 'purchase', 'general', 'postThread');
			$this->applyGlobalPermission('dbtech_shop', 'react', 'forum', 'react');
			$this->applyGlobalPermission('dbtech_shop', 'rate', 'forum', 'react');
			$this->applyGlobalPermission('dbtech_shop', 'add', 'forum', 'hardDeleteAnyPost');
			$this->applyGlobalPermission('dbtech_shop', 'updateOwn', 'forum', 'editOwnPost');
			$this->applyGlobalPermission('dbtech_shop', 'tagOwnItem', 'forum', 'tagOwnThread');
			$this->applyGlobalPermission('dbtech_shop', 'tagAnyItem', 'forum', 'tagAnyThread');
			$this->applyGlobalPermission('dbtech_shop', 'manageOthersTagsOwnItem', 'forum', 'manageOthersTagsOwnThread');
			$this->applyGlobalPermission('dbtech_shop', 'deleteOwn', 'forum', 'deleteOwnPost');
			
			// Moderator perms
			$this->applyGlobalPermission('dbtech_shop', 'inlineMod', 'forum', 'inlineMod');
			$this->applyGlobalPermission('dbtech_shop', 'viewDeleted', 'forum', 'viewDeleted');
			$this->applyGlobalPermission('dbtech_shop', 'deleteAny', 'forum', 'deleteAnyPost');
			$this->applyGlobalPermission('dbtech_shop', 'undelete', 'forum', 'undelete');
			$this->applyGlobalPermission('dbtech_shop', 'hardDeleteAny', 'forum', 'hardDeleteAnyPost');
			$this->applyGlobalPermission('dbtech_shop', 'viewDeletedReviews', 'forum', 'viewDeleted');
			$this->applyGlobalPermission('dbtech_shop', 'deleteAnyReview', 'forum', 'deleteAnyPost');
			$this->applyGlobalPermission('dbtech_shop', 'editAny', 'forum', 'editAnyPost');
			$this->applyGlobalPermission('dbtech_shop', 'updateAny', 'forum', 'editAnyPost');
			$this->applyGlobalPermission('dbtech_shop', 'reassign', 'forum', 'editAnyPost');
			$this->applyGlobalPermission('dbtech_shop', 'manageAnyTag', 'forum', 'manageAnyTag');
			$this->applyGlobalPermission('dbtech_shop', 'viewModerated', 'forum', 'viewModerated');
			$this->applyGlobalPermission('dbtech_shop', 'approveUnapprove', 'forum', 'approveUnapprove');
			$this->applyGlobalPermission('dbtech_shop', 'warn', 'forum', 'warn');
			
			$applied = true;
		}
		
		if (!$previousVersion || $previousVersion < 906010015)
		{
			// Regular perms
			$this->applyGlobalPermission('dbtechShopTradePost', 'view', 'profilePost', 'view');
			$this->applyGlobalPermission('dbtechShopTradePost', 'react', 'profilePost', 'react');
			$this->applyGlobalPermission('dbtechShopTradePost', 'manageOwn', 'profilePost', 'manageOwn');
			$this->applyGlobalPermission('dbtechShopTradePost', 'post', 'profilePost', 'post');
			$this->applyGlobalPermission('dbtechShopTradePost', 'comment', 'profilePost', 'comment');
			$this->applyGlobalPermission('dbtechShopTradePost', 'deleteOwn', 'profilePost', 'deleteOwn');
			$this->applyGlobalPermission('dbtechShopTradePost', 'editOwn', 'profilePost', 'editOwn');
			
			// Moderator perms
			$this->applyGlobalPermission('dbtechShopTradePost', 'inlineMod', 'profilePost', 'inlineMod');
			$this->applyGlobalPermission('dbtechShopTradePost', 'editAny', 'profilePost', 'editAny');
			$this->applyGlobalPermission('dbtechShopTradePost', 'deleteAny', 'profilePost', 'deleteAny');
			$this->applyGlobalPermission('dbtechShopTradePost', 'hardDeleteAny', 'profilePost', 'hardDeleteAny');
			$this->applyGlobalPermission('dbtechShopTradePost', 'warn', 'profilePost', 'warn');
			$this->applyGlobalPermission('dbtechShopTradePost', 'viewDeleted', 'profilePost', 'viewDeleted');
			$this->applyGlobalPermission('dbtechShopTradePost', 'viewModerated', 'profilePost', 'viewModerated');
			$this->applyGlobalPermission('dbtechShopTradePost', 'undelete', 'profilePost', 'undelete');
			$this->applyGlobalPermission('dbtechShopTradePost', 'approveUnapprove', 'profilePost', 'approveUnapprove');
			
			$applied = true;
		}
		
		return $applied;
	}
}