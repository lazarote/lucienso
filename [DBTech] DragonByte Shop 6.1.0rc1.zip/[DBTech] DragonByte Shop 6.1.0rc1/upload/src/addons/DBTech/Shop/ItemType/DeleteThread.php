<?php

namespace DBTech\Shop\ItemType;

/**
 * Class DeleteThread
 *
 * @package DBTech\Shop\ItemType
 */
class DeleteThread extends AbstractHandler implements ConfigurableInterface
{
	protected $defaultAdminConfig = [
		'excludedforums' => [],
		'onlyown' => true
	];
	
	protected $defaultUserConfig = [
		'threadid' => 0
	];
	
	/**
	 * @param $context
	 *
	 * @return array
	 */
	protected function getDefaultTemplateParams($context)
	{
		$params = parent::getDefaultTemplateParams($context);
		
		switch ($context)
		{
			case 'admin_config':
				/** @var \XF\Repository\Node $nodeRepo */
				$nodeRepo = $this->repository('XF:Node');
				
				$choices = $nodeRepo->getNodeOptionsData(false, 'Forum', 'option');
				$params['choices'] = array_map(function($v) {
					$v['label'] = \XF::escapeString($v['label']);
					return $v;
				}, $choices);
				break;
			
			case 'user_config_view':
				$params['thread'] = $this->em()->find('XF:Thread', $this->purchase->configuration['threadid']);
				break;
		}
		
		return $params;
	}
	
	/**
	 * @param array $config
	 *
	 * @return array
	 */
	public function filterAdminConfig(array $config = [])
	{
		return $this->app()->inputFilterer()->filterArray($config, [
			'excludedforums' => 'array-uint',
			'onlyown' => 'bool',
		]);
	}
	
	/**
	 * @param array $input
	 *
	 * @return array
	 */
	public function filterUserConfig(array $input = [])
	{
		return $this->app()->inputFilterer()->filterArray($input, [
			'threadid' => 'str'
		]);
	}
	
	/**
	 * @param array $configuration
	 * @param null $errors
	 *
	 * @return bool
	 */
	public function validateUserConfig(array &$configuration = [], &$errors = null)
	{
		if (is_numeric($configuration['threadid']))
		{
			$thread = $this->em()->find('XF:Thread', $configuration['threadid']);
			if (!$thread)
			{
				$errors = \XF::phraseDeferred('no_thread_could_be_found_with_id_x', ['thread_id' => $configuration['threadid']]);
				return false;
			}
		}
		else
		{
			$threadRepo = $this->app()->repository('XF:Thread');
			$thread = $threadRepo->getThreadFromUrl($configuration['threadid'], null, $errors);
			if (!$thread)
			{
				return false;
			}
			
			$configuration['threadid'] = $thread->thread_id;
		}
		
		if (in_array($thread->node_id, $this->item->code['excludedforums']))
		{
			// Excluded forum
			$errors = \XF::phraseDeferred('dbtech_shop_cannot_delete_threads_in_this_forum');
			return false;
		}
		
		if ($this->item->code['onlyown']
			&& $thread->user_id != $this->purchase->user_id)
		{
			$errors = \XF::phraseDeferred('dbtech_shop_you_can_only_delete_your_own_threads');
			return false;
		}
		
		if ($configuration['threadid'] != $this->purchase->configuration['threadid']
			&& $thread->discussion_state == 'deleted'
		)
		{
			// Excluded forum
			$errors = \XF::phraseDeferred('dbtech_shop_thread_already_deleted');
			return false;
		}
		
		return true;
	}
	
	/**
	 * @return string
	 */
	public function getConfigurationForConversation()
	{
		/** @var \XF\Entity\Thread $thread */
		$thread = $this->em()->find('XF:Thread', $this->purchase->configuration['threadid']);
		if (!$thread)
		{
			return '';
		}
		
		return \XF::phrase('dbtech_shop_configuration_notice_deletethread', [
			'thread_url' => $this->app()->router('public')->buildLink('full:threads', $thread),
			'thread' => new \XF\PreEscaped($thread->title)
		]);
	}
	
	/**
	 *
	 */
	protected function activateAlways()
	{
		/** @var \XF\Entity\Thread $thread */
		$thread = $this->em()->find('XF:Thread', $this->purchase->configuration['threadid']);
		if (!$thread)
		{
			return;
		}
		
		$reason = \XF::phrase('dbtech_shop_deleted_via_shop');
		
		/** @var \XF\Service\Thread\Deleter $deleter */
		$deleter = $this->service('XF:Thread\Deleter', $thread);
		$deleter->setUser($this->purchase->User);
		$deleter->setSendAlert(true, $reason);
		
		$deleter->delete('soft', $reason);
	}
	
	/**
	 * @param null $error
	 *
	 * @throws \XF\PrintableException
	 */
	protected function _deactivate(&$error = null)
	{
		/** @var \XF\Entity\Thread $thread */
		$thread = $this->em()->find('XF:Thread', $this->purchase->configuration['threadid']);
		if (!$thread)
		{
			return;
		}
		
		if ($thread->discussion_state == 'deleted')
		{
			$thread->discussion_state = 'visible';
			$thread->save();
		}
	}
}