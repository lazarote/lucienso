<?php

namespace DBTech\Shop\ItemType;

/**
 * Class UserTitleChangePreDefined
 *
 * @package DBTech\Shop\ItemType
 */
class UserTitleChangePreDefined extends AbstractHandler
{
	protected $defaultAdminConfig = [
		'usertitle' => '',
	];
	
	
	/**
	 * @param array $config
	 *
	 * @return array
	 */
	public function filterAdminConfig(array $config = [])
	{
		return $this->app()->inputFilterer()->filterArray($config, [
			'usertitle' => 'str',
		]);
	}
	
	/**
	 * @throws \XF\PrintableException
	 */
	public function afterPurchase()
	{
		if (!$this->purchase)
		{
			// We didn't set a purchase in the global config
			throw new \LogicException("Cannot activate a purchase without a purchase context set.");
		}
		
		if (!$this->item)
		{
			// We didn't set an item in the global config
			throw new \LogicException("Cannot activate a purchase without an item context set.");
		}
		
		if ($this->performValidations)
		{
			if ($this->item->isOnlyGiftable() && !$this->purchase->gifted)
			{
				return;
			}
		}
		
		$user = $this->purchase->User;
		$user->setOption('admin_edit', true);
		$user->custom_title = $this->item->code['usertitle'];
		
		if ($user->preSave())
		{
			$user->save();
		}
		else
		{
			$user->reset();
		}
	}
}