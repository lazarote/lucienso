<?php

namespace DBTech\Shop\ItemType;

/**
 * Class ProfileMusic
 *
 * @package DBTech\Shop\ItemType
 */
class ProfileMusic extends AbstractHandler implements ConfigurableInterface
{
	protected $defaultUserConfig = [
		'url' => ''
	];
	
	
	/**
	 * @return string
	 */
	public function getAdminConfigTemplate()
	{
		return '';
	}
	
	/**
	 * @param array $input
	 *
	 * @return array
	 */
	public function filterUserConfig(array $input = [])
	{
		return $this->app()->inputFilterer()->filterArray($input, [
			'url' => 'str',
		]);
	}
	
	/**
	 * @param array $configuration
	 * @param null $errors
	 *
	 * @return bool
	 */
	public function validateUserConfig(array &$configuration = [], &$errors = null)
	{
		return true;
	}
	
	/**
	 * @return string
	 */
	public function getConfigurationForConversation()
	{
		$userConfig = $this->purchase->configuration;
		
		return \XF::phrase('dbtech_shop_configuration_notice_profilemusic', [
			'url' => $userConfig['url'] ?: '',
			'url_text' => $userConfig['url']
				? new \XF\PreEscaped($userConfig['url'])
				: \XF::phrase('dbtech_shop_not_set'),
		]);
	}
}