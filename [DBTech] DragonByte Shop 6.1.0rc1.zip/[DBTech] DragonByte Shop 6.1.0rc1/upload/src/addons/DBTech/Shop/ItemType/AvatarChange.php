<?php

namespace DBTech\Shop\ItemType;

/**
 * Class AvatarChange
 *
 * @package DBTech\Shop\ItemType
 */
class AvatarChange extends AbstractHandler
{
	/**
	 * @return bool
	 */
	public function isActive()
	{
		return false;
	}
	
	/**
	 * @return bool
	 */
	public function canRevertConfiguration()
	{
		return false;
	}
}