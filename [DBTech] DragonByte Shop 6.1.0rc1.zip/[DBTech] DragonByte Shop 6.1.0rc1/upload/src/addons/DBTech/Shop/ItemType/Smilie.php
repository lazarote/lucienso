<?php

namespace DBTech\Shop\ItemType;

/**
 * Class Smilie
 *
 * @package DBTech\Shop\ItemType
 */
class Smilie extends AbstractHandler
{
	/**
	 * @return bool
	 */
	public function isActive()
	{
		return false;
	}
}