<?php

namespace DBTech\Shop\ItemType;

/**
 * Class SmilieCategory
 *
 * @package DBTech\Shop\ItemType
 */
class SmilieCategory extends AbstractHandler
{
	/**
	 * @return bool
	 */
	public function isActive()
	{
		return false;
	}
}