<?php

namespace DBTech\Shop\Alert;

use XF\Alert\AbstractHandler;

/**
 * Class Item
 *
 * @package DBTech\Shop\Alert
 */
class Item extends AbstractHandler
{
	/**
	 * @return array
	 */
	public function getEntityWith()
	{
		$visitor = \XF::visitor();

		return ['Permissions|' . $visitor->permission_combination_id, 'Category', 'Category.Permissions|' . $visitor->permission_combination_id];
	}

	/**
	 * @return array
	 */
	public function getOptOutActions()
	{
		return [
			'insert',
			'mention',
			'reaction',
			'gift'
		];
	}

	/**
	 * @return int
	 */
	public function getOptOutDisplayOrder()
	{
		return 89995;
	}
}