<?php

namespace DBTech\Shop\Alert;

use XF\Alert\AbstractHandler;

/**
 * Class Trade
 *
 * @package DBTech\Shop\Alert
 */
class Trade extends AbstractHandler
{
	/**
	 * @return array
	 */
	public function getEntityWith()
	{
		return ['Creator', 'Recipient'];
	}

	/**
	 * @return array
	 */
	public function getOptOutActions()
	{
		return [
			'invite',
			'invite_decline',
			'invite_accept',
			'cancel',
			'modify',
			'accept',
			'finalize',
		];
	}

	/**
	 * @return int
	 */
	public function getOptOutDisplayOrder()
	{
		return 89999;
	}
}