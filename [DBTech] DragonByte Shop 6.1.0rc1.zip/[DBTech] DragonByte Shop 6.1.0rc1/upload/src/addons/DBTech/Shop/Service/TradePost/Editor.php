<?php

namespace DBTech\Shop\Service\TradePost;

use DBTech\Shop\Entity\TradePost;

/**
 * Class Editor
 *
 * @package DBTech\Shop\Service\TradePost
 */
class Editor extends \XF\Service\AbstractService
{
	use \XF\Service\ValidateAndSavableTrait;

	/**
	 * @var TradePost
	 */
	protected $tradePost;

	/**
	 * @var \DBTech\Shop\Service\TradePost\Preparer
	 */
	protected $preparer;

	protected $alert = false;
	protected $alertReason = '';
	
	
	/**
	 * Editor constructor.
	 *
	 * @param \XF\App $app
	 * @param TradePost $tradePost
	 */
	public function __construct(\XF\App $app, TradePost $tradePost)
	{
		parent::__construct($app);
		$this->setTradePost($tradePost);
	}
	
	/**
	 * @param TradePost $tradePost
	 */
	protected function setTradePost(TradePost $tradePost)
	{
		$this->tradePost = $tradePost;
		$this->preparer = $this->service('DBTech\Shop:TradePost\Preparer', $tradePost);
	}
	
	/**
	 * @return TradePost
	 */
	public function getTradePost()
	{
		return $this->tradePost;
	}
	
	/**
	 * @return Preparer
	 */
	public function getPreparer()
	{
		return $this->preparer;
	}
	
	/**
	 * @param $message
	 * @param bool $format
	 *
	 * @return bool
	 */
	public function setMessage($message, $format = true)
	{
		return $this->preparer->setMessage($message, $format);
	}
	
	/**
	 * @param $alert
	 * @param null $reason
	 */
	public function setSendAlert($alert, $reason = null)
	{
		$this->alert = (bool)$alert;
		if ($reason !== null)
		{
			$this->alertReason = $reason;
		}
	}
	
	/**
	 *
	 */
	public function checkForSpam()
	{
		if ($this->tradePost->message_state == 'visible' && \XF::visitor()->isSpamCheckRequired())
		{
			$this->preparer->checkForSpam();
		}
	}
	
	/**
	 *
	 */
	protected function finalSetup() {}
	
	/**
	 * @return array
	 */
	protected function _validate()
	{
		$this->finalSetup();

		$this->tradePost->preSave();
		return $this->tradePost->getErrors();
	}
	
	/**
	 * @return TradePost
	 * @throws \XF\PrintableException
	 */
	protected function _save()
	{
		$db = $this->db();
		$db->beginTransaction();

		$tradePost = $this->tradePost;
		$visitor = \XF::visitor();

		$tradePost->save(true, false);

		$this->preparer->afterUpdate();

		if ($tradePost->message_state == 'visible' && $this->alert && $tradePost->user_id != $visitor->user_id)
		{
			/** @var \DBTech\Shop\Repository\TradePost $tradePostRepo */
			$tradePostRepo = $this->repository('DBTech\Shop:TradePost');
			$tradePostRepo->sendModeratorActionAlert($tradePost, 'edit', $this->alertReason);
		}

		$db->commit();

		return $tradePost;
	}
}