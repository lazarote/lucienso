<?php

namespace DBTech\Shop\Service\TradePost;

use DBTech\Shop\Entity\TradePost;
use XF\Entity\User;

/**
 * Class Deleter
 *
 * @package DBTech\Shop\Service\TradePost
 */
class Deleter extends \XF\Service\AbstractService
{
	/**
	 * @var TradePost
	 */
	protected $tradePost;

	/**
	 * @var User
	 */
	protected $user;

	protected $alert = false;
	protected $alertReason = '';
	
	
	/**
	 * Deleter constructor.
	 *
	 * @param \XF\App $app
	 * @param TradePost $tradePost
	 */
	public function __construct(\XF\App $app, TradePost $tradePost)
	{
		parent::__construct($app);
		$this->setTradePost($tradePost);
		$this->setUser(\XF::visitor());
	}
	
	/**
	 * @param TradePost $tradePost
	 */
	protected function setTradePost(TradePost $tradePost)
	{
		$this->tradePost = $tradePost;
	}
	
	/**
	 * @return TradePost
	 */
	public function getTradePost()
	{
		return $this->tradePost;
	}
	
	/**
	 * @param User $user
	 */
	protected function setUser(User $user)
	{
		$this->user = $user;
	}
	
	/**
	 * @return User
	 */
	public function getUser()
	{
		return $this->user;
	}
	
	/**
	 * @param $alert
	 * @param null $reason
	 */
	public function setSendAlert($alert, $reason = null)
	{
		$this->alert = (bool)$alert;
		if ($reason !== null)
		{
			$this->alertReason = $reason;
		}
	}
	
	/**
	 * @param $type
	 * @param string $reason
	 *
	 * @return bool
	 * @throws \XF\PrintableException
	 */
	public function delete($type, $reason = '')
	{
		$user = $this->user;

		$tradePost = $this->tradePost;
		$wasVisible = ($tradePost->message_state == 'visible');

		if ($type == 'soft')
		{
			$result = $tradePost->softDelete($reason, $user);
		}
		else
		{
			$result = $tradePost->delete();
		}

		if ($result && $wasVisible && $this->alert && $tradePost->user_id != $user->user_id)
		{
			/** @var \DBTech\Shop\Repository\TradePost $tradePostRepo */
			$tradePostRepo = $this->repository('DBTech\Shop:TradePost');
			$tradePostRepo->sendModeratorActionAlert($tradePost, 'delete', $this->alertReason);
		}

		return $result;
	}
}