<?php

namespace DBTech\Shop\Service\TradePostComment;

use DBTech\Shop\Entity\TradePostComment;
use XF\Entity\User;

/**
 * Class Deleter
 *
 * @package DBTech\Shop\Service\TradePostComment
 */
class Deleter extends \XF\Service\AbstractService
{
	/**
	 * @var TradePostComment
	 */
	protected $comment;

	/**
	 * @var User
	 */
	protected $user;

	protected $alert = false;
	protected $alertReason = '';
	
	
	/**
	 * Deleter constructor.
	 *
	 * @param \XF\App $app
	 * @param TradePostComment $content
	 */
	public function __construct(\XF\App $app, TradePostComment $content)
	{
		parent::__construct($app);
		$this->setComment($content);
		$this->setUser(\XF::visitor());
	}
	
	/**
	 * @param TradePostComment $content
	 */
	protected function setComment(TradePostComment $content)
	{
		$this->comment = $content;
	}
	
	/**
	 * @return TradePostComment
	 */
	public function getComment()
	{
		return $this->comment;
	}
	
	/**
	 * @param User $user
	 */
	protected function setUser(User $user)
	{
		$this->user = $user;
	}
	
	/**
	 * @return User
	 */
	public function getUser()
	{
		return $this->user;
	}
	
	/**
	 * @param $alert
	 * @param null $reason
	 */
	public function setSendAlert($alert, $reason = null)
	{
		$this->alert = (bool)$alert;
		if ($reason !== null)
		{
			$this->alertReason = $reason;
		}
	}
	
	/**
	 * @param $type
	 * @param string $reason
	 *
	 * @return bool
	 * @throws \XF\PrintableException
	 */
	public function delete($type, $reason = '')
	{
		$user = $this->user;

		$comment = $this->comment;
		$wasVisible = ($comment->message_state == 'visible');

		if ($type == 'soft')
		{
			$result = $comment->softDelete($reason, $user);
		}
		else
		{
			$result = $comment->delete();
		}

		if ($result && $wasVisible && $this->alert && $comment->user_id != $user->user_id)
		{
			/** @var \DBTech\Shop\Repository\TradePost $profilePostRepo */
			$profilePostRepo = $this->repository('DBTech\Shop:TradePost');
			$profilePostRepo->sendCommentModeratorActionAlert($comment, 'delete', $this->alertReason);
		}

		return $result;
	}
}