<?php

namespace DBTech\Shop\Service\TradePostComment;

use DBTech\Shop\Entity\TradePostComment;

/**
 * Class Editor
 *
 * @package DBTech\Shop\Service\TradePostComment
 */
class Editor extends \XF\Service\AbstractService
{
	use \XF\Service\ValidateAndSavableTrait;

	/**
	 * @var TradePostComment
	 */
	protected $comment;

	/**
	 * @var \DBTech\Shop\Service\TradePostComment\Preparer
	 */
	protected $preparer;

	protected $alert = false;
	protected $alertReason = '';
	
	
	/**
	 * Editor constructor.
	 *
	 * @param \XF\App $app
	 * @param TradePostComment $comment
	 */
	public function __construct(\XF\App $app, TradePostComment $comment)
	{
		parent::__construct($app);
		$this->setComment($comment);
	}
	
	/**
	 * @param TradePostComment $comment
	 */
	protected function setComment(TradePostComment $comment)
	{
		$this->comment = $comment;
		$this->preparer = $this->service('DBTech\Shop:TradePostComment\Preparer', $this->comment);
	}
	
	/**
	 * @return TradePostComment
	 */
	public function getComment()
	{
		return $this->comment;
	}
	
	/**
	 * @return Preparer
	 */
	public function getPreparer()
	{
		return $this->preparer;
	}
	
	/**
	 * @param $message
	 * @param bool $format
	 *
	 * @return bool
	 */
	public function setMessage($message, $format = true)
	{
		return $this->preparer->setMessage($message, $format);
	}
	
	/**
	 * @param $alert
	 * @param null $reason
	 */
	public function setSendAlert($alert, $reason = null)
	{
		$this->alert = (bool)$alert;
		if ($reason !== null)
		{
			$this->alertReason = $reason;
		}
	}
	
	/**
	 *
	 */
	public function checkForSpam()
	{
		if ($this->comment->message_state == 'visible' && \XF::visitor()->isSpamCheckRequired())
		{
			$this->preparer->checkForSpam();
		}
	}
	
	/**
	 *
	 */
	protected function finalSetup() {}
	
	/**
	 * @return array
	 */
	protected function _validate()
	{
		$this->finalSetup();

		$this->comment->preSave();
		return $this->comment->getErrors();
	}
	
	/**
	 * @return TradePostComment
	 * @throws \XF\PrintableException
	 */
	protected function _save()
	{
		$db = $this->db();
		$db->beginTransaction();

		$comment = $this->comment;
		$visitor = \XF::visitor();

		$comment->save(true, false);

		$this->preparer->afterUpdate();

		if ($comment->message_state == 'visible' && $this->alert && $comment->user_id != $visitor->user_id)
		{
			/** @var \DBTech\Shop\Repository\TradePost $profilePostRepo */
			$profilePostRepo = $this->repository('DBTech\Shop:TradePost');
			$profilePostRepo->sendCommentModeratorActionAlert($comment, 'edit', $this->alertReason);
		}

		$db->commit();

		return $comment;
	}
}