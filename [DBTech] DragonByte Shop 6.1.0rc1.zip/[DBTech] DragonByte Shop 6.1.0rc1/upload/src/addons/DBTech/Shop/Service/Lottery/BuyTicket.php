<?php

namespace DBTech\Shop\Service\Lottery;


use DBTech\Shop\Entity\Lottery;
use DBTech\Shop\Entity\LotteryTicket;

/**
 * Class BuyTicket
 *
 * @package DBTech\Shop\Service\Lottery
 */
class BuyTicket extends \XF\Service\AbstractService
{
	use \XF\Service\ValidateAndSavableTrait;
	
	/**
	 * @var Lottery
	 */
	protected $lottery;
	
	/**
	 * @var LotteryTicket
	 */
	protected $lotteryTicket;
	
	/**
	 * @var \XF\Entity\User|null
	 */
	protected $user;
	
	/**
	 * @var array
	 */
	protected $numbers = [];
	
	
	/**
	 * Complete constructor.
	 *
	 * @param \XF\App $app
	 * @param Lottery $lottery
	 */
	public function __construct(\XF\App $app, Lottery $lottery)
	{
		parent::__construct($app);
		$this->setUser(\XF::visitor());
		$this->setLottery($lottery);
		
		$this->setDefaults();
	}
	
	/**
	 *
	 */
	protected function setDefaults()
	{
	}
	
	/**
	 * @param \XF\Entity\User|null $user
	 */
	public function setUser(\XF\Entity\User $user = null)
	{
		$this->user = $user;
	}
	
	/**
	 * @return null|\XF\Entity\User
	 */
	public function getUser()
	{
		return $this->user;
	}
	
	/**
	 * @param Lottery|null $lottery
	 */
	public function setLottery(Lottery $lottery = null)
	{
		$this->lottery = $lottery;
	}
	
	/**
	 * @return null|Lottery
	 */
	public function getLottery()
	{
		return $this->lottery;
	}
	
	/**
	 * @param LotteryTicket|null $lotteryTicket
	 */
	public function setLotteryTicket(LotteryTicket $lotteryTicket = null)
	{
		$this->lotteryTicket = $lotteryTicket;
	}
	
	/**
	 * @return null|LotteryTicket
	 */
	public function getLotteryTicket()
	{
		return $this->lotteryTicket;
	}
	
	/**
	 * @param array $numbers
	 */
	public function setNumbers(array $numbers = [])
	{
		$this->numbers = $numbers;
	}
	
	/**
	 * @return array
	 */
	public function getNumbers()
	{
		return $this->numbers;
	}
	
	/**
	 *
	 */
	protected function finalSetup()
	{
		if (empty($this->numbers))
		{
			// TODO: Random numbers
		}
	}
	
	/**
	 * @return array
	 * @throws \Exception
	 */
	protected function _validate()
	{
		$this->finalSetup();
		
		$errors = [];
		
		$lottery = $this->lottery;
		
		$canBuyTicket = \XF::asVisitor($this->user, function() use ($lottery)
		{
			return $lottery->canBuyTicket();
		});
		if (!$canBuyTicket)
		{
			$errors[] = \XF::phraseDeferred('dbtech_shop_cannot_buy_ticket_for_this_lottery');
		}
		
		$numbers = $this->numbers;
		
		$usedNumbers = [];
		for ($i = 0; $i < $lottery->numbers['main']; $i++)
		{
			if (empty($numbers[$i]))
			{
				// Too large number
				$errors[] = \XF::phraseDeferred('dbtech_shop_missing_lottery_ticket_numbers');
				break;
			}
			
			if (array_key_exists($numbers[$i], $usedNumbers))
			{
				// Used same number several times
				$errors[] = \XF::phraseDeferred('dbtech_shop_cannot_reuse_numbers');
				break;
			}
			
			if ($numbers[$i] > $lottery->numbers['total'])
			{
				// Too large number
				$errors[] = \XF::phraseDeferred('dbtech_shop_too_large_number');
				break;
			}
			
			// Used number
			$usedNumbers[$numbers[$i]] = true;
		}
		
		if (count($numbers) > $lottery->numbers['main'])
		{
			$errors[] = \XF::phraseDeferred('dbtech_shop_too_many_numbers_max_x', [
				'max' => $lottery->numbers['main']
			]);
		}
		
		return $errors;
	}
	
	/**
	 * @throws \LogicException
	 * @throws \Exception
	 * @throws \XF\PrintableException
	 */
	protected function _save()
	{
		$lottery = $this->lottery;
		$user = $this->user;
		
		$db = $this->db();
		$db->beginTransaction();
		
		$ticket = $this->em()->create('DBTech\Shop:LotteryTicket');
		$ticket->lottery_id = $lottery->lottery_id;
		$ticket->user_id = $user->user_id;
		$ticket->draw_date = $lottery->next_draw_date;
		$ticket->numbers = $this->numbers;
		$ticket->save(true, false);
		
		$ticket->hydrateRelation('Lottery', $lottery);
		$ticket->hydrateRelation('User', $user);
		
		$this->setLotteryTicket($ticket);
		
		/** @var \DBTech\Shop\Repository\Currency $currencyRepo */
		$currencyRepo = $this->repository('DBTech\Shop:Currency');
		
		$currencyRepo->removeCurrencyAmount(
			$lottery->Currency,
			'lotteryticket',
			$lottery->ticket_price,
			$user,
			'dbtech_shop_ticket', $ticket->lottery_ticket_id
		);
		
		$this->afterPurchase();
		
		$db->commit();
	}
	
	/**
	 *
	 */
	public function afterPurchase()
	{
		$this->lottery->fastUpdate('tickets_sold', $this->lottery->tickets_sold + 1);
	}
}