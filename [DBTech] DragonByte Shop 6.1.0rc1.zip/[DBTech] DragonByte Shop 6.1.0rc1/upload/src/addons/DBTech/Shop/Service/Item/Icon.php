<?php

namespace DBTech\Shop\Service\Item;

use DBTech\Shop\Entity\Item;

/**
 * Class Icon
 * @package DBTech\Shop\Service\Item
 */
class Icon extends \XF\Service\AbstractService
{
	/**
	 * @var \DBTech\Shop\Entity\Item
	 */
	protected $item;

    /**
     * @var bool
     */
    protected $logIp = true;

    /**
     * @var
     */
    protected $fileName;

    /**
     * @var
     */
    protected $width;

    /**
     * @var
     */
    protected $height;

    /**
     * @var
     */
    protected $type;

    /**
     * @var null
     */
    protected $error;

    /**
     * @var array
     */
    protected $allowedTypes = [IMAGETYPE_GIF, IMAGETYPE_JPEG, IMAGETYPE_PNG];


    /**
     * Icon constructor.
     * @param \XF\App $app
     * @param Item $item
     */
    public function __construct(\XF\App $app, Item $item)
	{
		parent::__construct($app);
		$this->item = $item;
	}

    /**
     * @return Item
     */
    public function getItem()
	{
		return $this->item;
	}

    /**
     * @param $logIp
     */
    public function logIp($logIp)
	{
		$this->logIp = $logIp;
	}

    /**
     * @return null
     */
    public function getError()
	{
		return $this->error;
	}
	
	/**
	 * @param $fileName
	 *
	 * @return bool
	 * @throws \InvalidArgumentException
	 */
    public function setImage($fileName)
	{
		if (!$this->validateImageAsIcon($fileName, $error))
		{
			$this->error = $error;
			$this->fileName = null;
			return false;
		}

		$this->fileName = $fileName;
		return true;
	}
	
	/**
	 * @param \XF\Http\Upload $upload
	 *
	 * @return bool
	 * @throws \InvalidArgumentException
	 */
    public function setImageFromUpload(\XF\Http\Upload $upload)
	{
		$upload->requireImage();

		if (!$upload->isValid($errors))
		{
			$this->error = reset($errors);
			return false;
		}

		return $this->setImage($upload->getTempFile());
	}
	
	/**
	 * @param $fileName
	 * @param null $error
	 *
	 * @return bool
	 * @throws \InvalidArgumentException
	 */
    public function validateImageAsIcon($fileName, &$error = null)
	{
		$error = null;

		if (!file_exists($fileName))
		{
			throw new \InvalidArgumentException("Invalid file '$fileName' passed to icon service");
		}
		if (!is_readable($fileName))
		{
			throw new \InvalidArgumentException("'$fileName' passed to icon service is not readable");
		}

		$imageInfo = filesize($fileName) ? getimagesize($fileName) : false;
		if (!$imageInfo)
		{
			$error = \XF::phrase('provided_file_is_not_valid_image');
			return false;
		}

		$type = $imageInfo[2];
		if (!in_array($type, $this->allowedTypes))
		{
			$error = \XF::phrase('provided_file_is_not_valid_image');
			return false;
		}
		
		list($width, $height) = $imageInfo;

		if (!$this->app->imageManager()->canResize($width, $height))
		{
			$error = \XF::phrase('uploaded_image_is_too_big');
			return false;
		}

		// require 2:1 aspect ratio or squarer
		if ($width > 2 * $height || $height > 2 * $width)
		{
			$error = \XF::phrase('please_provide_an_image_whose_longer_side_is_no_more_than_twice_length');
			return false;
		}

		$this->width = $width;
		$this->height = $height;
		$this->type = $type;

		return true;
	}
	
	/**
	 * @return bool
	 * @throws \RuntimeException
	 * @throws \LogicException
	 * @throws \Exception
	 * @throws \XF\PrintableException
	 */
    public function updateIcon()
	{
		if (!$this->fileName)
		{
			throw new \LogicException('No source file for icon set');
		}
		
		$imageManager = $this->app->imageManager();
		
		if ($this->app->options()->offsetExists('dbtechShopItemIconMaxDimensions'))
		{
			$targetWidth = $this->app->options()->dbtechShopItemIconMaxDimensions['width'] ?:
				$this->app->container('avatarSizeMap')['l'];
			
			$targetHeight = $this->app->options()->dbtechShopItemIconMaxDimensions['height'] ?:
				$this->app->container('avatarSizeMap')['l'];
		}
		else
		{
			$targetWidth = $this->app->container('avatarSizeMap')['l'];
			$targetHeight = $this->app->container('avatarSizeMap')['l'];
		}
		
		$outputFile = null;
		
		if ($this->width != $targetWidth || $this->height != $targetHeight)
		{
			$image = $imageManager->imageFromFile($this->fileName);
			if (!$image)
			{
				return false;
			}
			
			$image->resizeAndCrop($targetWidth, $targetHeight);
			
			$newTempFile = \XF\Util\File::getTempFile();
			if ($newTempFile && $image->save($newTempFile))
			{
				$outputFile = $newTempFile;
			}
		}
		else
		{
			$outputFile = $this->fileName;
		}
		
		if (!$outputFile)
		{
			throw new \RuntimeException('Failed to save image to temporary file; check internal_data/data permissions');
		}

		$dataFile = $this->item->getAbstractedIconPath();
		\XF\Util\File::copyFileToAbstractedPath($outputFile, $dataFile);
		
		if (!$this->logIp)
        {
            $this->item->setOption('log_moderator', false);
            $this->item->setOption('is_automated', true);
        }

		$this->item->icon_date = \XF::$time;
		$this->item->save();

		if ($this->logIp)
		{
			$ip = ($this->logIp === true ? $this->app->request()->getIp() : $this->logIp);
			$this->writeIpLog('update', $ip);
		}

		return true;
	}
	
	/**
	 * @return bool
	 * @throws \LogicException
	 * @throws \Exception
	 * @throws \XF\PrintableException
	 */
    public function deleteIcon()
	{
		$this->deleteIconFiles();

		$this->item->icon_date = 0;
		$this->item->save();

		if ($this->logIp)
		{
			$ip = ($this->logIp === true ? $this->app->request()->getIp() : $this->logIp);
			$this->writeIpLog('delete', $ip);
		}

		return true;
	}

    /**
     * @return bool
     */
    public function deleteIconForItemDelete()
	{
		$this->deleteIconFiles();

		return true;
	}
	
	/**
	 *
	 */
	protected function deleteIconFiles()
	{
		if ($this->item->icon_date)
		{
			\XF\Util\File::deleteFromAbstractedPath($this->item->getAbstractedIconPath());
		}
	}

    /**
     * @param $action
     * @param $ip
     */
    protected function writeIpLog($action, $ip)
	{
		$item = $this->item;

		/** @var \XF\Repository\Ip $ipRepo */
		$ipRepo = $this->repository('XF:Ip');
		$ipRepo->logIp(\XF::visitor()->user_id, $ip, 'dbtech_shop_item', $item->item_id, 'icon_' . $action);
	}
}