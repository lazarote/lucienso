<?php

namespace DBTech\Shop\Service\TradePostComment;

use DBTech\Shop\Entity\TradePost;
use DBTech\Shop\Entity\TradePostComment;
use XF\Entity\User;

/**
 * Class Creator
 *
 * @package DBTech\Shop\Service\TradePostComment
 */
class Creator extends \XF\Service\AbstractService
{
	use \XF\Service\ValidateAndSavableTrait;

	/**
	 * @var TradePost
	 */
	protected $tradePost;

	/**
	 * @var TradePostComment
	 */
	protected $comment;

	/**
	 * @var User
	 */
	protected $user;

	/**
	 * @var \DBTech\Shop\Service\TradePostComment\Preparer
	 */
	protected $preparer;
	
	
	/**
	 * Creator constructor.
	 *
	 * @param \XF\App $app
	 * @param TradePost $tradePost
	 */
	public function __construct(\XF\App $app, TradePost $tradePost)
	{
		parent::__construct($app);
		$this->setTradePost($tradePost);
		$this->setUser(\XF::visitor());
		$this->setDefaults();
	}
	
	/**
	 * @param TradePost $tradePost
	 */
	protected function setTradePost(TradePost $tradePost)
	{
		$this->tradePost = $tradePost;
		$this->comment = $tradePost->getNewComment();
		$this->preparer = $this->service('DBTech\Shop:TradePostComment\Preparer', $this->comment);
	}
	
	/**
	 * @return TradePost
	 */
	public function getTradePost()
	{
		return $this->tradePost;
	}
	
	/**
	 * @return TradePostComment
	 */
	public function getComment()
	{
		return $this->comment;
	}
	
	/**
	 * @return Preparer
	 */
	public function getTradePostCommentPreparer()
	{
		return $this->preparer;
	}
	
	/**
	 * @param $logIp
	 */
	public function logIp($logIp)
	{
		$this->preparer->logIp($logIp);
	}
	
	/**
	 * @param User $user
	 */
	protected function setUser(User $user)
	{
		$this->user = $user;
	}
	
	/**
	 *
	 */
	protected function setDefaults()
	{
		$this->comment->message_state = $this->tradePost->getNewContentState();
		$this->comment->user_id = $this->user->user_id;
		$this->comment->username = $this->user->username;
	}
	
	/**
	 * @param $message
	 * @param bool $format
	 *
	 * @return bool
	 */
	public function setContent($message, $format = true)
	{
		return $this->preparer->setMessage($message, $format);
	}
	
	/**
	 *
	 */
	public function checkForSpam()
	{
		if ($this->comment->message_state == 'visible' && $this->user->isSpamCheckRequired())
		{
			$this->preparer->checkForSpam();
		}
	}
	
	/**
	 *
	 */
	protected function finalSetup()
	{
		$this->comment->comment_date = time();
	}
	
	/**
	 * @return array
	 */
	protected function _validate()
	{
		$this->finalSetup();

		$this->comment->preSave();
		return $this->comment->getErrors();
	}
	
	/**
	 * @return TradePostComment
	 * @throws \XF\PrintableException
	 */
	protected function _save()
	{
		$comment = $this->comment;
		$comment->save();

		$this->preparer->afterInsert();

		return $comment;
	}
	
	/**
	 * @throws \Exception
	 */
	public function sendNotifications()
	{
		if ($this->comment->isVisible())
		{
			/** @var \DBTech\Shop\Service\TradePostComment\Notifier $notifier */
			$notifier = $this->service('DBTech\Shop:TradePostComment\Notifier', $this->comment);
			$notifier->setNotifyMentioned($this->preparer->getMentionedUserIds());
			$notifier->notify();
		}
	}
}