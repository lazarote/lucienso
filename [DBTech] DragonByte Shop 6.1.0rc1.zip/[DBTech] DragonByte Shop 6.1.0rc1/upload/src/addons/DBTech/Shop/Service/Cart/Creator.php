<?php

namespace DBTech\Shop\Service\Cart;

use DBTech\Shop\Entity\Cart;
use DBTech\Shop\Entity\Item;

/**
 * Class Creator
 *
 * @package DBTech\Shop\Service\Cart
 */
class Creator extends \XF\Service\AbstractService
{
	use \XF\Service\ValidateAndSavableTrait;

	/**
	 * @var \XF\Mvc\Entity\ArrayCollection|Cart[]
	 */
	protected $cartItems;

	/**
	 * @var \XF\Entity\User|null
	 */
	protected $user;
	
	
	/**
	 * Creator constructor.
	 *
	 * @param \XF\App $app
	 */
	public function __construct(\XF\App $app)
	{
		parent::__construct($app);
		$this->setUser(\XF::visitor());
		
		$this->setDefaults();
	}
	
	/**
	 *
	 */
	protected function setDefaults()
	{
		$this->cartItems = $this->finder('DBTech\Shop:Cart')
			->with(['Item', 'Item.PurchaseCurrency'])
			->where('user_id', $this->user->user_id)
			->keyedBy('item_id')
			->fetch();
	}

	/**
	 * @param \XF\Entity\User|null $user
	 */
	public function setUser(\XF\Entity\User $user = null)
	{
		$this->user = $user;
	}

	/**
	 * @return null|\XF\Entity\User
	 */
	public function getUser()
	{
		return $this->user;
	}
	
	/**
	 * @param Item $item
	 * @param int $quantity
	 * @param \XF\Entity\User|int|string|null $toUser
	 * @param string $message
	 */
	public function addItem(Item $item, $quantity = 1, $toUser = null, $message = '')
	{
		$cartItems = $this->cartItems;
		
		if (!$cartItems->offsetExists($item->item_id))
		{
			/** @var Cart $cartItem */
			$cartItem = $this->em()->create('DBTech\Shop:Cart');
			$cartItem->item_id = $item->item_id;
			$cartItem->user_id = $this->user->user_id;
			$cartItem->quantity = 0; // Default to 0 since we want to add the passed quantity
			
			$cartItems->offsetSet($item->item_id, $cartItem);
		}
		else
		{
			/** @var Cart $cartItem */
			$cartItem = $cartItems->offsetGet($item->item_id);
		}
		
		if ($toUser)
		{
			if (is_int($toUser))
			{
				$toUser = $this->em()->find('XF:User', $toUser);
			}
			else if (is_string($toUser))
			{
				/** @var \XF\Entity\User $toUser */
				$toUser = $this->repository('XF:User')->getUserByNameOrEmail($toUser);
			}
			
			if ($toUser instanceof \XF\Entity\User)
			{
				$cartItem->recipient_user_id = $toUser->user_id;
				$cartItem->recipient_username = $toUser->username;
				$cartItem->message = $message;
				
				$cartItem->hydrateRelation('Recipient', $toUser);
			}
		}
		else
		{
			$cartItem->recipient_user_id = 0;
			$cartItem->recipient_username = '';
			$cartItem->message = '';
		}
		
		if ($item->isUnique() || $item->isExclusive())
		{
			// Unique items can only ever have 1 in the quantity, so enforce that here
			$cartItem->quantity = 1;
		}
		else
		{
			$cartItem->quantity += $quantity;
		}
	}
	
	/**
	 * @param Item $item
	 * @param int $quantity
	 */
	public function setQuantity(Item $item, $quantity)
	{
		$cartItems = $this->cartItems;
		
		if ($cartItems->offsetExists($item->item_id))
		{
			/** @var Cart $cartItem */
			$cartItem = $cartItems->offsetGet($item->item_id);
			$cartItem->quantity = $quantity;
		}
	}
	
	/**
	 * @param Item $item
	 * @param \XF\Entity\User|int|string|null $toUser
	 * @param string $message
	 */
	public function setGiftOptions(Item $item, $toUser = null, $message = '')
	{
		$cartItems = $this->cartItems;
		
		if ($cartItems->offsetExists($item->item_id))
		{
			/** @var Cart $cartItem */
			$cartItem = $cartItems->offsetGet($item->item_id);
			
			if ($toUser && $cartItem->Item->isGiftable())
			{
				if (is_int($toUser))
				{
					$toUser = $this->em()->find('XF:User', $toUser);
				}
				else if (is_string($toUser))
				{
					/** @var \XF\Entity\User $toUser */
					$toUser = $this->repository('XF:User')->getUserByNameOrEmail($toUser);
				}
				
				if ($toUser instanceof \XF\Entity\User)
				{
					$cartItem->recipient_user_id = $toUser->user_id;
					$cartItem->recipient_username = $toUser->username;
					$cartItem->message = $message;
					
					$cartItem->hydrateRelation('Recipient', $toUser);
				}
			}
			else
			{
				$cartItem->recipient_user_id = 0;
				$cartItem->recipient_username = '';
				$cartItem->message = '';
				
				$cartItem->hydrateRelation('Recipient', null);
			}
		}
	}
	
	/**
	 *
	 */
	protected function finalSetup()
	{
	}

	/**
	 * @return array
	 */
	protected function _validate()
	{
		$this->finalSetup();

		$errors = [];
		foreach ($this->cartItems as $cartItem)
		{
			$error = null;
			if (!$cartItem->Item
				|| !$cartItem->Item->canView()
				|| !$cartItem->Item->canPurchase()
			)
			{
				$errors[] = $error ?: \XF::phrase('dbtech_shop_cannot_purchase_item_x', [
					'item' => $cartItem->Item->title
				]);
				
				$error = null;
			}
			
			if ($cartItem->Item->stock != -1
				&& $cartItem->quantity > $cartItem->Item->stock
			)
			{
				$errors[] = \XF::phrase('dbtech_shop_cannot_purchase_this_many_of_item_x', [
					'item' => $cartItem->Item->title
				]);
			}
			
			if (!$cartItem->Item->isGiftable()
				&& $cartItem->recipient_user_id
			)
			{
				$errors[] = \XF::phrase('dbtech_shop_cannot_gift_item_x', [
					'item' => $cartItem->Item->title
				]);
			}
			
			if ($cartItem->Item->isOnlyGiftable()
				&& !$cartItem->recipient_user_id)
			{
				$errors[] = \XF::phrase('dbtech_shop_must_gift_item_x', [
					'item' => $cartItem->Item->title
				]);
			}
			
			if ($cartItem->recipient_user_id)
			{
				if (!$cartItem->Item->canPurchaseForUser($cartItem->Recipient, $error))
				{
					$errors[] = $error ?: \XF::phrase('dbtech_shop_cannot_gift_item_x', [
						'item' => $cartItem->Item->title
					]);
					
					$error = null;
				}
			}
			else
			{
				if (!$cartItem->Item->canPurchaseForSelf(false, $error))
				{
					$errors[] = $error ?: \XF::phrase('dbtech_shop_cannot_purchase_item_x', [
						'item' => $cartItem->Item->title
					]);
					
					$error = null;
				}
			}

			$cartItem->preSave();
			$errors = array_merge($errors, $cartItem->getErrors());
		}

		return $errors;
	}
	
	/**
	 * @throws \LogicException
	 * @throws \Exception
	 * @throws \XF\PrintableException
	 */
	protected function _save()
	{
		foreach ($this->cartItems as $cartItem)
		{
			$cartItem->save();
		}
	}
}