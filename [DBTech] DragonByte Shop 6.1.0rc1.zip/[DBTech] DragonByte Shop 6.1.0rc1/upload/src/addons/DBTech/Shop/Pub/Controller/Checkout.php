<?php

namespace DBTech\Shop\Pub\Controller;

use XF\Mvc\Entity\ArrayCollection;
use XF\Mvc\ParameterBag;
use XF\Pub\Controller\AbstractController;

/**
 * Class Checkout
 *
 * @package DBTech\Shop\Pub\Controller
 */
class Checkout extends AbstractController
{
	/**
	 * @param $action
	 * @param ParameterBag $params
	 *
	 * @throws \XF\Mvc\Reply\Exception
	 */
	protected function preDispatchController($action, ParameterBag $params)
	{
		/** @var \DBTech\Shop\XF\Entity\User $visitor */
		$visitor = \XF::visitor();
		
		if (!$visitor->canViewDbtechShopItems($error))
		{
			throw $this->exception($this->noPermission($error));
		}
		
		if (!$visitor->canPurchaseDbtechShopItems($error))
		{
			throw $this->exception($this->noPermission($error));
		}
	}
	
	
	/**
	 * @return \XF\Mvc\Reply\View
	 * @throws \XF\Mvc\Reply\Exception
	 */
	public function actionIndex()
	{
		$this->assertCanonicalUrl($this->buildLink('dbtech-shop/checkout'));
		
		/** @var \DBTech\Shop\Entity\Cart[]|ArrayCollection $cartItems */
		$cartItems = $this->getCart();
		
		$totalPrices = $currencies = [];
		foreach ($cartItems as $cartItem)
		{
			$currency = $cartItem->getCurrency();
			
			if (!isset($totalPrices[$currency->currency_id]))
			{
				$totalPrices[$currency->currency_id] = [
					'total' => 0.00,
					'currency' => $currency
				];
			}
			
			$totalPrices[$currency->currency_id]['total'] += $cartItem->getPrice();
			$currencies[$currency->currency_id] = $currency;
		}
		
		$viewParams = [
			'cartItems' => $cartItems,
			'totalPrices' => $totalPrices,
			'currencies' => $currencies
		];
		return $this->view('DBTech\Shop:Checkout\Index', 'dbtech_shop_checkout', $viewParams);
	}
	
	/**
	 * @param ParameterBag $params
	 *
	 * @return \XF\Mvc\Reply\Redirect|\XF\Mvc\Reply\View
	 * @throws \XF\Mvc\Reply\Exception
	 * @throws \XF\PrintableException
	 */
	public function actionRemoveItem(ParameterBag $params)
	{
		$cartItems = $this->getCart();
		$item = $this->assertItemExists($params->item_id);
		
		if ($this->isPost())
		{
			if ($cartItems->offsetExists($item->item_id))
			{
				/** @var \DBTech\Shop\Entity\Cart $cartItem */
				$cartItem = $cartItems->offsetGet($item->item_id);
				$cartItem->delete();
			}
			
			return $this->redirect($this->getDynamicRedirect($this->buildLink('dbtech-shop/checkout')));
		}
		else
		{
			$viewParams = [
				'item' => $item,
			];
			return $this->view('DBTech\Shop:Checkout\RemoveItem', 'dbtech_shop_checkout_remove_item', $viewParams);
		}
	}
	
	/**
	 * @return \XF\Mvc\Reply\Error|\XF\Mvc\Reply\Redirect|\XF\Mvc\Reply\Reroute
	 * @throws \XF\Mvc\Reply\Exception
	 * @throws \XF\PrintableException
	 */
	public function actionUpdate()
	{
		$this->assertPostOnly();
		
		$cartItems = $this->getCart();
		
		if ($this->filter('delete', 'bool'))
		{
			foreach ($this->filter('item_ids', 'array-uint') as $itemId)
			{
				if ($cartItems->offsetExists($itemId))
				{
					/** @var \DBTech\Shop\Entity\Cart $cartItem */
					$cartItem = $cartItems->offsetGet($itemId);
					$cartItem->delete();
					
					$cartItems->offsetUnset($itemId);
				}
			}
			
			if (!$cartItems->count())
			{
				return $this->redirect($this->buildLink('dbtech-shop'), \XF::phrase('dbtech_shop_cart_updated'));
			}
		}
		else
		{
			foreach ($this->filter('quantity', 'array-uint') as $itemId => $quantity)
			{
				if ($cartItems->offsetExists($itemId))
				{
					/** @var \DBTech\Shop\Entity\Cart $cartItem */
					$cartItem = $cartItems->offsetGet($itemId);
					
					/** @var \DBTech\Shop\Service\Cart\Creator $creator */
					$creator = $this->service('DBTech\Shop:Cart\Creator');
					$creator->setQuantity($cartItem->Item, $quantity);
					
					if (!$creator->validate($errors))
					{
						return $this->error($errors);
					}
					
					$creator->save();
				}
			}
			
			if ($this->request->exists('purchase'))
			{
				return $this->rerouteController(__CLASS__, 'complete');
			}
		}
		
		return $this->redirect($this->buildLink('dbtech-shop/checkout'), \XF::phrase('dbtech_shop_cart_updated'));
	}
	
	/**
	 * @param ParameterBag $params
	 *
	 * @return \XF\Mvc\Reply\Error|\XF\Mvc\Reply\Redirect|\XF\Mvc\Reply\View
	 */
	public function actionRecipient(ParameterBag $params)
	{
		$cartItems = $this->getCart();
		
		if (!$cartItems->offsetExists($params->item_id))
		{
			return $this->error(\XF::phrase('dbtech_shop_this_item_is_not_in_cart'));
		}
		
		/** @var \DBTech\Shop\Entity\Cart $cartItem */
		$cartItem = $cartItems->offsetGet($params->item_id);
		
		if ($this->isPost())
		{
			$toUser = null;
			if ($cartItem->Item->isGiftable())
			{
				if ($cartItem->Item->isOnlyGiftable() || $this->request->exists('is_gift'))
				{
					/** @var \XF\Entity\User $toUser */
					$toUser = $this->repository('XF:User')
						->getUserByNameOrEmail($this->filter('recipient', 'str'))
					;
					if (!$toUser)
					{
						return $this->error(\XF::phrase('requested_user_not_found'));
					}
				}
			}
			
			/** @var \DBTech\Shop\Service\Cart\Creator $creator */
			$creator = $this->service('DBTech\Shop:Cart\Creator');
			$creator->setGiftOptions($cartItem->Item, $toUser, $this->filter('message', 'str'));
			
			if (!$creator->validate($errors))
			{
				return $this->error($errors);
			}
			
			$creator->save();
			
			return $this->redirect($this->buildLink('dbtech-shop/checkout'), \XF::phrase('dbtech_shop_gift_options_updated'));
		}
		
		$viewParams = [
			'cartItem' => $cartItem,
			'item' => $cartItem->Item
		];
		return $this->view('DBTech\Shop:Checkout\Recipient', 'dbtech_shop_checkout_recipient', $viewParams);
	}
	
	/**
	 * @return \XF\Mvc\Reply\Error|\XF\Mvc\Reply\Redirect|\XF\Mvc\Reply\Reroute|\XF\Mvc\Reply\View
	 */
	public function actionComplete()
	{
		/** @var \DBTech\Shop\Service\Cart\Complete $purchase */
		$purchase = \XF::app()->service('DBTech\Shop:Cart\Complete');
		
		if (!$purchase->validate($errors))
		{
			return $this->error($errors);
		}
		
		$purchase->save();
		
		return $this->redirect($this->buildLink('dbtech-shop/inventory'), \XF::phrase('dbtech_shop_purchase_completed'));
	}
	
	/**
	 * @return \DBTech\Shop\Entity\Cart[]|ArrayCollection
	 */
	public function getCart()
	{
		return $this->repository('DBTech\Shop:Purchase')
			->getCart()
			->keyedBy('item_id')
			->fetch();
	}
	
	/**
	 * @param string $id
	 * @param array|string|null $with
	 * @param null|string $phraseKey
	 *
	 * @return \DBTech\Shop\Entity\Item|\XF\Mvc\Entity\Entity
	 * @throws \XF\Mvc\Reply\Exception
	 */
	protected function assertItemExists($id, $with = null, $phraseKey = null)
	{
		return $this->assertRecordExists('DBTech\Shop:Item', $id, $with, $phraseKey);
	}

	/**
	 * @param array $activities
	 *
	 * @return bool|\XF\Phrase
	 */
	public static function getActivityDetails(array $activities)
	{
		return \XF::phrase('dbtech_shop_viewing_cart');
	}
}