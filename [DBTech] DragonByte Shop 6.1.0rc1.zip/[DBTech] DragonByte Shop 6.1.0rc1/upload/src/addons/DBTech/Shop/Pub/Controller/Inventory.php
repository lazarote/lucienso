<?php

namespace DBTech\Shop\Pub\Controller;

use XF\Mvc\Entity\ArrayCollection;
use XF\Mvc\ParameterBag;
use XF\Pub\Controller\AbstractController;

/**
 * Class Inventory
 *
 * @package DBTech\Shop\Pub\Controller
 */
class Inventory extends AbstractController
{
	/**
	 * @param $action
	 * @param ParameterBag $params
	 *
	 * @throws \XF\Mvc\Reply\Exception
	 */
	protected function preDispatchController($action, ParameterBag $params)
	{
		/** @var \DBTech\Shop\XF\Entity\User $visitor */
		$visitor = \XF::visitor();
		
		if (!$visitor->canViewDbtechShopItems($error))
		{
			throw $this->exception($this->noPermission($error));
		}
	}
	
	
	/**
	 * @param ParameterBag $params
	 *
	 * @return \XF\Mvc\Reply\Error|\XF\Mvc\Reply\View
	 * @throws \XF\Mvc\Reply\Exception
	 */
	public function actionIndex(ParameterBag $params)
	{
		if ($params->purchase_id)
		{
			$purchase = $this->assertViewablePurchase($params->purchase_id, [
				'Buyer',
			]);
			
			$viewParams = [
				'purchase' => $purchase,
				'item' => $purchase->Item
			];
			return $this->view('DBTech\Shop:Inventory\Purchase\View', 'dbtech_shop_inventory_purchase_view', $viewParams);
		}
		
		$this->assertCanonicalUrl($this->buildLink('dbtech-shop/inventory'));
		
		$userId = $this->filter('user_id', 'uint');
		$inventoryUser = $userId ? $this->em()->find('XF:User', $userId) : \XF::visitor();
		if (!$inventoryUser)
		{
			return $this->error(\XF::phrase('requested_user_not_found'));
		}
		
		/** @var \DBTech\Shop\Entity\Purchase[]|ArrayCollection $inventory */
		$inventory = $this->repository('DBTech\Shop:Purchase')
			->findInventoryForUser($inventoryUser->user_id)
			->order([['expiry_date', 'ASC'], ['dateline', 'DESC']], 'ASC')
			->fetch()
			->filterViewable()
		;
		$currentPurchases = $inventory->filter(function(\DBTech\Shop\Entity\Purchase $purchase)
		{
			if (!$purchase->isExpired())
			{
				return $purchase;
			}
			
			return null;
		});
		$expiredPurchases = $inventory->filter(function(\DBTech\Shop\Entity\Purchase $purchase)
		{
			if ($purchase->isExpired())
			{
				return $purchase;
			}
			
			return null;
		});
		
		$inventoryGrouped = $currentPurchases->groupBy('active');
		
		$viewParams = [
			'inventory' => $inventory,
			'inventoryUser' => $inventoryUser,
			'activePurchases' => isset($inventoryGrouped[1]) ? $inventoryGrouped[1] : [],
			'inactivePurchases' => isset($inventoryGrouped[0]) ? $inventoryGrouped[0] : [],
			'expiredPurchases' => $expiredPurchases
		];
		return $this->view('DBTech\Shop:Inventory\Index', 'dbtech_shop_inventory', $viewParams);
	}
	
	/**
	 * @param ParameterBag $params
	 *
	 * @return \XF\Mvc\Reply\Error|\XF\Mvc\Reply\Redirect|\XF\Mvc\Reply\View
	 * @throws \XF\Mvc\Reply\Exception
	 * @throws \XF\PrintableException
	 */
	public function actionSettings(ParameterBag $params)
	{
		$purchase = $this->assertViewablePurchase($params->purchase_id);
		if (!$purchase->canEditSettings())
		{
			return $this->error(\XF::phrase('dbtech_shop_cannot_edit_settings_for_this_purchase'));
		}
		
		if ($this->isPost())
		{
			$handler = $purchase->handler;
			
			$isActive = $this->filter('active', 'bool');
			
			if ($purchase->isActive() && !$isActive)
			{
				$success = $handler->deactivate($error);
				if (!$success)
				{
					return $this->error($error);
				}
			}
			else if (!$purchase->isActive() && $isActive)
			{
				$success = $handler->activate($error);
				if (!$success)
				{
					return $this->error($error);
				}
			}
			
			$purchase->hidden = $this->filter('hidden', 'bool');
			$purchase->saveIfChanged();
			
			return $this->redirect($this->buildLink('dbtech-shop/inventory'));
		}
		
		$viewParams = [
			'purchase' => $purchase,
			'item' => $purchase->Item
		];
		return $this->view('DBTech\Shop:Inventory\Settings', 'dbtech_shop_inventory_settings', $viewParams);
	}
	
	/**
	 * @param ParameterBag $params
	 *
	 * @return \XF\Mvc\Reply\Error|\XF\Mvc\Reply\Redirect|\XF\Mvc\Reply\View
	 * @throws \XF\Mvc\Reply\Exception
	 * @throws \XF\PrintableException
	 */
	public function actionDiscard(ParameterBag $params)
	{
		$purchase = $this->assertViewablePurchase($params->purchase_id);
		if (!$purchase->canDiscard())
		{
			return $this->error(\XF::phrase('dbtech_shop_cannot_discard_this_purchase'));
		}
		
		if ($this->isPost())
		{
			$handler = $purchase->handler;
			
			$success = $handler->discard($error, 'manual');
			if (!$success)
			{
				return $this->error($error);
			}
			
			return $this->redirect(
				$this->buildLink('dbtech-shop/inventory'),
				\XF::phrase('dbtech_shop_item_discarded')
			);
		}
		
		$viewParams = [
			'purchase' => $purchase,
			'item' => $purchase->Item
		];
		return $this->view('DBTech\Shop:Inventory\Discard', 'dbtech_shop_inventory_discard', $viewParams);
	}
	
	/**
	 * @param ParameterBag $params
	 *
	 * @return \XF\Mvc\Reply\Error|\XF\Mvc\Reply\Redirect|\XF\Mvc\Reply\View
	 * @throws \XF\Mvc\Reply\Exception
	 */
	public function actionSell(ParameterBag $params)
	{
		$purchase = $this->assertViewablePurchase($params->purchase_id);
		if (!$purchase->canSellBack())
		{
			return $this->error(\XF::phrase('dbtech_shop_cannot_sell_back_purchase_please_discard'));
		}
		
		if ($this->isPost())
		{
			/** @var \DBTech\Shop\Service\Purchase\Sellback $purchaseService */
			$purchaseService = \XF::app()->service('DBTech\Shop:Purchase\Sellback', $purchase);
			
			if (!$purchaseService->validate($errors))
			{
				return $this->error($errors);
			}
			
			$purchaseService->save();
			
			return $this->redirect(
				$this->buildLink('dbtech-shop/inventory'),
				\XF::phrase('dbtech_shop_item_sold_back')
			);
		}
		
		$viewParams = [
			'purchase' => $purchase,
			'item' => $purchase->Item,
			'currency' => $purchase->Item->BuybackCurrency,
		];
		return $this->view('DBTech\Shop:Inventory\Sell', 'dbtech_shop_inventory_sell', $viewParams);
	}
	
	/**
	 * @param ParameterBag $params
	 *
	 * @return \XF\Mvc\Reply\Error|\XF\Mvc\Reply\Redirect|\XF\Mvc\Reply\View
	 * @throws \XF\Mvc\Reply\Exception
	 */
	public function actionGift(ParameterBag $params)
	{
		$purchase = $this->assertViewablePurchase($params->purchase_id);
		if (!$purchase->canGift())
		{
			return $this->error(\XF::phrase('dbtech_shop_cannot_gift_this_purchase'));
		}
		
		if ($this->isPost())
		{
			/** @var \XF\Entity\User $toUser */
			$toUser = $this->repository('XF:User')
				->getUserByNameOrEmail($this->filter('recipient', 'str'))
			;
			if (!$toUser)
			{
				return $this->error(\XF::phrase('requested_user_not_found'));
			}
			
			if ($toUser->user_id == \XF::visitor()->user_id)
			{
				return $this->error(\XF::phrase('dbtech_shop_cannot_gift_item_to_self'));
			}
			
			/** @var \DBTech\Shop\Service\Purchase\Transfer $purchaseService */
			$purchaseService = \XF::app()->service('DBTech\Shop:Purchase\Transfer', $purchase, $toUser);
			$purchaseService->setIsGift(true);
			$purchaseService->setMessage($this->filter('message', 'str'));
			
			if ($purchase->canGiftAsNew())
			{
				$purchaseService->removeConfiguration($this->filter('remove_configuration', 'bool', false));
			}
			
			if (!$purchaseService->validate($errors))
			{
				return $this->error($errors);
			}
			
			$purchaseService->save();
			
			return $this->redirect(
				$this->buildLink('dbtech-shop/inventory'),
				\XF::phrase('dbtech_shop_item_gifted')
			);
		}
		
		$viewParams = [
			'purchase' => $purchase,
			'item' => $purchase->Item
		];
		return $this->view('DBTech\Shop:Inventory\Gift', 'dbtech_shop_inventory_gift', $viewParams);
	}
	
	/**
	 * @param ParameterBag $params
	 *
	 * @return \XF\Mvc\Reply\Error|\XF\Mvc\Reply\Redirect|\XF\Mvc\Reply\View
	 * @throws \XF\Mvc\Reply\Exception
	 * @throws \XF\PrintableException
	 */
	public function actionConfigure(ParameterBag $params)
	{
		$purchase = $this->assertViewablePurchase($params->purchase_id);
		if (!$purchase->canConfigure())
		{
			return $this->error(\XF::phrase('dbtech_shop_cannot_configure_this_purchase'));
		}
		
		if ($this->isPost())
		{
			/** @var \DBTech\Shop\ItemType\AbstractHandler|\DBTech\Shop\ItemType\ConfigurableInterface $handler */
			$handler = $purchase->handler;
			
			$configuration = $this->filter('code', 'array');
			$configuration = $handler->filterUserConfig($configuration);
			
			$errors = null;
			if (!$handler->validateUserConfig($configuration, $errors))
			{
				return $this->error($errors);
			}
			
			$handler->configure($configuration);
			
			return $this->redirect(
				$this->buildLink('dbtech-shop/inventory'),
				\XF::phrase('dbtech_shop_item_configured')
			);
		}
		
		$viewParams = [
			'purchase' => $purchase,
			'item' => $purchase->Item
		];
		return $this->view('DBTech\Shop:Inventory\Configure', 'dbtech_shop_inventory_configure', $viewParams);
	}
	
	/**
	 * @return \DBTech\Shop\Repository\Currency|\XF\Mvc\Entity\Repository
	 */
	protected function getCurrencyRepo()
	{
		return $this->repository('DBTech\Shop:Currency');
	}
	
	/**
	 * @param string $purchaseId
	 * @param array $extraWith
	 *
	 * @return \DBTech\Shop\Entity\Purchase|\XF\Mvc\Entity\Entity
	 * @throws \XF\Mvc\Reply\Exception
	 */
	protected function assertViewablePurchase($purchaseId, array $extraWith = [])
	{
		$visitor = \XF::visitor();
		
		$extraWith[] = 'Item.Permissions|' . $visitor->permission_combination_id;
		$extraWith[] = 'Item.User';
		$extraWith[] = 'Item.Category';
		$extraWith[] = 'Item.Category.Permissions|' . $visitor->permission_combination_id;
		$extraWith[] = 'Item.Discussion';
		$extraWith[] = 'Item.Discussion.Forum';
		$extraWith[] = 'Item.Discussion.Forum.Node';
		$extraWith[] = 'Item.Discussion.Forum.Node.Permissions|' . $visitor->permission_combination_id;
		
		/** @var \DBTech\Shop\Entity\Purchase $purchase */
		$purchase = $this->em()->find('DBTech\Shop:Purchase', $purchaseId, $extraWith);
		if (!$purchase)
		{
			throw $this->exception($this->notFound(\XF::phrase('dbtech_shop_requested_purchase_not_found')));
		}
		
		if (!$purchase->canView($error))
		{
			throw $this->exception($this->noPermission($error));
		}
		
		return $purchase;
	}

	/**
	 * @param array $activities
	 *
	 * @return bool|\XF\Phrase
	 */
	public static function getActivityDetails(array $activities)
	{
		return \XF::phrase('dbtech_shop_viewing_inventory');
	}
}