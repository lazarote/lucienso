<?php

namespace DBTech\Shop\Entity;

use XF\Entity\AbstractPrefixGroup;
use XF\Mvc\Entity\Structure;

/**
 * COLUMNS
 * @property int|null prefix_group_id
 * @property int display_order
 *
 * GETTERS
 * @property \XF\Phrase|string title
 *
 * RELATIONS
 * @property \XF\Entity\Phrase MasterTitle
 * @property \DBTech\Shop\Entity\ItemPrefix[] Prefixes
 */
class ItemPrefixGroup extends AbstractPrefixGroup
{
	/**
	 * @return string
	 */
	protected function getClassIdentifier()
	{
		return 'DBTech\Shop:ItemPrefix';
	}
	
	/**
	 * @return string
	 */
	protected static function getContentType()
	{
		return 'dbtechShopItem';
	}
	
	/**
	 * @param Structure $structure
	 *
	 * @return Structure
	 */
	public static function getStructure(Structure $structure)
	{
		self::setupDefaultStructure(
			$structure,
			'xf_dbtech_shop_item_prefix_group',
			'DBTech\Shop:ItemPrefixGroup',
			'DBTech\Shop:ItemPrefix'
		);

		return $structure;
	}
}