<?php

namespace DBTech\Shop\Entity;

use XF\Mvc\Entity\Structure;
use XF\Entity\AbstractFieldMap;

/**
 * COLUMNS
 * @property int category_id
 * @property string field_id
 *
 * RELATIONS
 * @property \DBTech\Shop\Entity\ItemField Field
 * @property \DBTech\Shop\Entity\Category Category
 */
class CategoryField extends AbstractFieldMap
{
	/**
	 * @return string
	 */
	public static function getContainerKey()
	{
		return 'category_id';
	}
	
	/**
	 * @param Structure $structure
	 *
	 * @return Structure
	 */
	public static function getStructure(Structure $structure)
	{
		self::setupDefaultStructure($structure, 'xf_dbtech_shop_category_field', 'DBTech\Shop:CategoryField', 'DBTech\Shop:ItemField');

		$structure->relations['Category'] = [
			'entity' => 'DBTech\Shop:Category',
			'type' => self::TO_ONE,
			'conditions' => 'category_id',
			'primary' => true
		];

		return $structure;
	}
}