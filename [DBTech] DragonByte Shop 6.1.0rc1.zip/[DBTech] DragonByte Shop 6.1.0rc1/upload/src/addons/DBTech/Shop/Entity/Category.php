<?php

namespace DBTech\Shop\Entity;

use XF\Entity\AbstractCategoryTree;
use XF\Mvc\Entity\Structure;

/**
 * COLUMNS
 * @property int|null category_id
 * @property string title
 * @property string description
 * @property int item_count
 * @property int last_update
 * @property string last_item_title
 * @property int last_item_id
 * @property array prefix_cache
 * @property array field_cache
 * @property array item_filters
 * @property bool require_prefix
 * @property int thread_node_id
 * @property int thread_prefix_id
 * @property string item_update_notify
 * @property bool always_moderate_create
 * @property bool always_moderate_update
 * @property int min_tags
 * @property int sales
 * @property array sales_amounts
 * @property int latest_customer_id
 * @property int latest_sale_id
 * @property int beneficiary
 * @property int beneficiary_split
 * @property int num_ratings
 * @property float average_rating
 * @property int positive_percent
 * @property int negative_percent
 * @property int neutral_percent
 * @property int parent_category_id
 * @property int display_order
 * @property int lft
 * @property int rgt
 * @property int depth
 * @property array breadcrumb_data
 *
 * GETTERS
 * @property \XF\Mvc\Entity\ArrayCollection prefixes
 *
 * RELATIONS
 * @property \XF\Entity\Forum ThreadForum
 * @property \XF\Entity\User Beneficiary
 * @property \DBTech\Shop\Entity\Item LatestSale
 * @property \XF\Entity\User LatestCustomer
 * @property \DBTech\Shop\Entity\CategoryWatch[] Watch
 * @property \XF\Entity\PermissionCacheContent[] Permissions
 */
class Category extends AbstractCategoryTree
{
	/**
	 * @var array
	 */
	protected $_viewableDescendants = [];
	
	/**
	 * @param null $error
	 *
	 * @return mixed
	 */
	public function canView(&$error = null)
	{
		return $this->hasPermission('view');
	}
	
	/**
	 * @return mixed
	 */
	public function canViewDeletedItems()
	{
		return $this->hasPermission('viewDeleted');
	}
	
	/**
	 * @return mixed
	 */
	public function canViewModeratedItems()
	{
		return $this->hasPermission('viewModerated');
	}
	
	/**
	 * @param Item|null $item
	 * @param null $error
	 *
	 * @return bool
	 */
	public function canEditTags(Item $item = null, &$error = null)
	{
		if (!$this->app()->options()->enableTagging)
		{
			return false;
		}
		
		$visitor = \XF::visitor();
		
		// if no item, assume will be owned by this person
		if (!$item || $item->user_id == $visitor->user_id)
		{
			if ($this->hasPermission('tagOwnItem'))
			{
				return true;
			}
		}
		
		return (
			$this->hasPermission('tagAnyItem')
			|| $this->hasPermission('manageAnyTag')
		);
	}
	
	/**
	 * @param null $error
	 *
	 * @return mixed
	 */
	public function canUseInlineModeration(&$error = null)
	{
		return $this->hasPermission('inlineMod');
	}
	
	/**
	 * @param null $error
	 *
	 * @return bool
	 */
	public function canAddItem(&$error = null)
	{
		return \XF::visitor()->user_id && $this->hasPermission('add');
	}
	
	/**
	 * @param null $error
	 *
	 * @return bool
	 */
	public function canPurchase(&$error = null)
	{
		return \XF::visitor()->user_id && $this->hasPermission('purchase');
	}
	
	/**
	 * @param null $error
	 *
	 * @return bool
	 */
	public function canWatch(&$error = null)
	{
		return (\XF::visitor()->user_id ? true : false);
	}
	
	/**
	 * @param $permission
	 *
	 * @return mixed
	 */
	public function hasPermission($permission)
	{
		/** @var \DBTech\Shop\XF\Entity\User $visitor */
		$visitor = \XF::visitor();
		return $visitor->hasDbtechShopCategoryPermission($this->category_id, $permission);
	}
	
	/**
	 * @return mixed
	 */
	public function getViewableDescendants()
	{
		$userId = \XF::visitor()->user_id;
		if (!isset($this->_viewableDescendants[$userId]))
		{
			/** @var \DBTech\Shop\Repository\Category $categoryRepos */
			$categoryRepos = $this->repository('DBTech\Shop:Category');
			$viewable = $categoryRepos->getViewableCategories($this);
			$this->_viewableDescendants[$userId] = $viewable->toArray();
		}
		
		return $this->_viewableDescendants[$userId];
	}
	
	/**
	 * @param array $descendents
	 * @param null $userId
	 */
	public function cacheViewableDescendents(array $descendents, $userId = null)
	{
		if ($userId === null)
		{
			$userId = \XF::visitor()->user_id;
		}
		
		$this->_viewableDescendants[$userId] = $descendents;
	}
	
	/**
	 * @param null $forcePrefix
	 *
	 * @return mixed
	 */
	public function getUsablePrefixes($forcePrefix = null)
	{
		$prefixes = $this->prefixes;
		
		if ($forcePrefix instanceof ItemPrefix)
		{
			$forcePrefix = $forcePrefix->prefix_id;
		}
		
		$prefixes = $prefixes->filter(function($prefix) use ($forcePrefix)
		{
			if ($forcePrefix && $forcePrefix == $prefix->prefix_id)
			{
				return true;
			}
			return $this->isPrefixUsable($prefix);
		});
		
		return $prefixes->groupBy('prefix_group_id');
	}
	
	/**
	 * @return mixed
	 */
	public function getPrefixesGrouped()
	{
		return $this->prefixes->groupBy('prefix_group_id');
	}
	
	/**
	 * @return \XF\Mvc\Entity\ArrayCollection
	 */
	public function getPrefixes()
	{
		if (!$this->prefix_cache)
		{
			return $this->_em->getEmptyCollection();
		}
		
		$prefixes = $this->finder('DBTech\Shop:ItemPrefix')
			->where('prefix_id', $this->prefix_cache)
			->order('materialized_order')
			->fetch();
		
		return $prefixes;
	}
	
	/**
	 * @param $prefix
	 * @param \XF\Entity\User|null $user
	 *
	 * @return bool
	 */
	public function isPrefixUsable($prefix, \XF\Entity\User $user = null)
	{
		if (!$this->isPrefixValid($prefix))
		{
			return false;
		}
		
		if (!($prefix instanceof ItemPrefix))
		{
			$prefix = $this->em()->find('DBTech\Shop:ItemPrefix', $prefix);
			if (!$prefix)
			{
				return false;
			}
		}
		
		return $prefix->isUsableByUser($user);
	}
	
	/**
	 * @param $prefix
	 *
	 * @return bool
	 */
	public function isPrefixValid($prefix)
	{
		if ($prefix instanceof ItemPrefix)
		{
			$prefix = $prefix->prefix_id;
		}
		
		return (!$prefix || isset($this->prefix_cache[$prefix]));
	}
	
	/**
	 * @param string $itemType
	 *
	 * @return Item
	 * @throws \InvalidArgumentException
	 */
	public function getNewItem($itemType)
	{
		/** @var Item $item */
		$item = $this->_em->create('DBTech\Shop:Item');
		$item->item_type_id = $itemType;
		$item->category_id = $this->category_id;
		$item->hydrateRelation('Category', $this);
		
		return $item;
	}
	
	/**
	 * @param Item|null $item
	 *
	 * @return string
	 */
	public function getNewContentState(Item $item = null)
	{
		$visitor = \XF::visitor();
		
		if ($visitor->user_id && $this->hasPermission('approveUnapprove'))
		{
			return 'visible';
		}
		
		if (!$visitor->hasPermission('general', 'submitWithoutApproval'))
		{
			return 'moderated';
		}
		
		if ($item)
		{
			return $this->always_moderate_update ? 'moderated' : 'visible';
		}
		
		return $this->always_moderate_create ? 'moderated' : 'visible';
	}
	
	/**
	 * @param bool $includeSelf
	 * @param string $linkType
	 *
	 * @return array
	 */
	public function getBreadcrumbs($includeSelf = true, $linkType = 'public')
	{
		if ($linkType == 'public')
		{
			$link = 'dbtech-shop/categories';
		}
		else
		{
			$link = 'dbtech-shop/categories';
		}
		return $this->_getBreadcrumbs($includeSelf, $linkType, $link);
	}
	
	/**
	 * @return array
	 */
	public function getCategoryListExtras()
	{
		return [
			'item_count' => $this->item_count,
			'last_update' => $this->last_update,
			'last_item_title' => $this->last_item_title,
			'last_item_id' => $this->last_item_id
		];
	}
	
	/**
	 * @param Item $item
	 */
	public function itemAdded(Item $item)
	{
		$this->item_count++;
		
		if ($item->last_update >= $this->last_update)
		{
			$this->last_update = $item->last_update;
			$this->last_item_title = $item->title;
			$this->last_item_id = $item->item_id;
		}
	}
	
	/**
	 * @param Item $item
	 *
	 * @throws \InvalidArgumentException
	 */
	public function itemDataChanged(Item $item)
	{
		if ($item->isChanged(['last_update', 'title']))
		{
			if ($item->last_update >= $this->last_update)
			{
				$this->last_update = $item->last_update;
				$this->last_item_title = $item->title;
				$this->last_item_id = $item->item_id;
			}
			else if ($item->getExistingValue('last_update') == $this->last_update)
			{
				$this->rebuildLastItem();
			}
		}
	}
	
	/**
	 * @param Item $item
	 */
	public function itemRemoved(Item $item)
	{
		$this->item_count--;
		
		if ($item->last_update == $this->last_update)
		{
			$this->rebuildLastItem();
		}
	}
	
	/**
	 * @return bool
	 */
	public function rebuildCounters()
	{
		$this->rebuildItemCount();
		$this->rebuildLastItem();
		$this->rebuildLastSale();
		$this->rebuildRating();
//		$this->rebuildSalesAmounts();
		
		return true;
	}
	
	/**
	 * @return bool|mixed|null
	 */
	public function rebuildItemCount()
	{
		$this->item_count = $this->db()->fetchOne("
			SELECT COUNT(*)
			FROM xf_dbtech_shop_item
			WHERE category_id = ?
				AND item_state = 'visible'
		", $this->category_id);
		
		return $this->item_count;
	}
	
	/**
	 *
	 */
	public function rebuildLastItem()
	{
		/** @var \DBTech\Shop\Entity\Item $item */
		$item = $this->finder('DBTech\Shop:Item')
			->where('category_id', $this->category_id)
			->where('item_state', 'visible')
			->order('last_update', 'desc')
			->fetchOne();
		
		if ($item)
		{
			$this->last_update = $item->last_update;
			$this->last_item_title = $item->title;
			$this->last_item_id = $item->item_id;
		}
		else
		{
			$this->last_update = 0;
			$this->last_item_title = '';
			$this->last_item_id = 0;
		}
	}
	
	/**
	 *
	 */
	public function rebuildLastSale()
	{
		$finder = $this->finder('DBTech\Shop:Purchase');
		
		$finder->where($finder->expression('
			item_id IN(SELECT item_id FROM xf_dbtech_shop_item WHERE category_id = ' . $this->category_id . ')
		'));
		
		/** @var \DBTech\Shop\Entity\Purchase $purchase */
		$purchase = $finder->order('dateline', 'desc')
			->fetchOne()
		;
		
		if ($purchase)
		{
			$this->latest_customer_id = $purchase->buyer_user_id;
			$this->latest_sale_id = $purchase->item_id;
		}
		else
		{
			$this->latest_customer_id = 0;
			$this->latest_sale_id = 0;
		}
	}
	
	/**
	 * @return bool
	 */
	public function rebuildRating()
	{
		$ratings = $this->db()->fetchOne("
			SELECT COUNT(item_rating_id)
			FROM xf_dbtech_shop_item_rating AS rating
			LEFT JOIN xf_dbtech_shop_item AS item USING(item_id)
			WHERE item.category_id = ?
		", $this->category_id);
		
		$totalPositive = $this->db()->fetchOne("
			SELECT COUNT(item_rating_id)
			FROM xf_dbtech_shop_item_rating AS rating
			LEFT JOIN xf_dbtech_shop_item AS item USING(item_id)
			WHERE item.category_id = ?
				AND rating >= 4
		", $this->category_id);
		
		$totalNegative = $this->db()->fetchOne("
			SELECT COUNT(item_rating_id)
			FROM xf_dbtech_shop_item_rating AS rating
			LEFT JOIN xf_dbtech_shop_item AS item USING(item_id)
			WHERE item.category_id = ?
				AND rating <= 2
		", $this->category_id);
		
		$averageRating = $this->db()->fetchOne("
			SELECT AVG(rating)
			FROM xf_dbtech_shop_item_rating AS rating
			LEFT JOIN xf_dbtech_shop_item AS item USING(item_id)
			WHERE item.category_id = ?
				AND rating <= 2
		", $this->category_id);
		
		$this->num_ratings = $ratings;
		$this->average_rating = round($averageRating, 2);
		$this->positive_percent = $ratings ? round(($totalPositive / $ratings) * 100, 2) : 0;
		$this->negative_percent = $ratings ? round(($totalNegative / $ratings) * 100, 2) : 0;
		$this->neutral_percent = $ratings ? round((($ratings - $totalNegative - $totalPositive) / $ratings) * 100, 2) : 0;
		
		return true;
	}
	
	/**
	 * @param $itemId
	 *
	 * @return bool
	 */
	protected function verifyItemId(&$itemId)
	{
		return $this->_em->find('DBTech\Shop:Item', $itemId) !== NULL;
	}
	
	/**
	 * @param $userId
	 *
	 * @return bool
	 */
	protected function verifyUserIdOrZero(&$userId)
	{
		if ($userId == 0)
		{
			return true;
		}
		
		return $this->_em->find('XF:User', $userId) !== NULL;
	}
	
	/**
	 * @param $userId
	 *
	 * @return bool
	 */
	protected function verifyBeneficiary(&$userId)
	{
		if ($userId == -1 || $userId == 0)
		{
			// 0 or -1 is valid in this case
			return true;
		}
		
		return $this->_em->find('XF:User', $userId) !== NULL;
	}
	
	protected function _preSave()
	{
		if ($this->isChanged(['thread_node_id', 'thread_prefix_id']))
		{
			if (!$this->thread_node_id)
			{
				$this->thread_prefix_id = 0;
			}
			else
			{
				if (!$this->ThreadForum)
				{
					$this->thread_node_id = 0;
					$this->thread_prefix_id = 0;
				}
				else if ($this->thread_prefix_id && !$this->ThreadForum->isPrefixValid($this->thread_prefix_id))
				{
					$this->thread_prefix_id = 0;
				}
			}
		}
	}
	
	/**
	 *
	 */
	protected function _postDelete()
	{
		if ($this->getOption('delete_items'))
		{
			$this->app()->jobManager()->enqueueUnique('dbtechShopCategoryDelete' . $this->category_id, 'DBTech\Shop:CategoryDelete', [
				'category_id' => $this->category_id
			]);
		}
	}
	
	/**
	 * @param Structure $structure
	 * @return Structure
	 */
	public static function getStructure(Structure $structure)
	{
		$structure->table = 'xf_dbtech_shop_category';
		$structure->shortName = 'DBTech\Shop:Category';
		$structure->primaryKey = 'category_id';
		$structure->contentType = 'dbtech_shop_category';
		$structure->columns = [
			'category_id'            => ['type' => self::UINT, 'autoIncrement' => true, 'nullable' => true],
			'title'                  => [
				'type'      => self::STR,
				'maxLength' => 100,
				'required'  => 'please_enter_valid_title'
			],
			'description'            => ['type' => self::STR, 'default' => ''],
			'item_count'             => ['type' => self::UINT, 'default' => 0, 'forced' => true],
			'last_update'            => ['type' => self::UINT, 'default' => 0],
			'last_item_title'        => [
				'type'      => self::STR,
				'default'   => '',
				'maxLength' => 100,
				'censor'    => true
			],
			'last_item_id'           => ['type' => self::UINT, 'default' => 0],
			'prefix_cache'           => ['type' => self::JSON_ARRAY, 'default' => []],
			'field_cache'            => ['type' => self::JSON_ARRAY, 'default' => []],
			'item_filters'           => ['type' => self::JSON_ARRAY, 'default' => []],
			'require_prefix'         => ['type' => self::BOOL, 'default' => false],
			'thread_node_id'         => ['type' => self::UINT, 'default' => 0],
			'thread_prefix_id'       => ['type' => self::UINT, 'default' => 0],
			'item_update_notify'     => [
				'type'          => self::STR,
				'default'       => 'thread',
				'allowedValues' => ['thread', 'reply']
			],
			'always_moderate_create' => ['type' => self::BOOL, 'default' => false],
			'always_moderate_update' => ['type' => self::BOOL, 'default' => false],
			'min_tags'               => ['type' => self::UINT, 'forced' => true, 'default' => 0, 'max' => 100],
			'sales'                  => ['type' => self::UINT, 'default' => 0],
			'sales_amounts'          => ['type' => self::JSON_ARRAY, 'default' => []],
			'latest_customer_id'     => ['type' => self::UINT, 'verify' => 'verifyUserIdOrZero'],
			'latest_sale_id'         => ['type' => self::UINT, 'verify' => 'verifyItemId'],
			'beneficiary'            => ['type' => self::INT, 'default' => 0],
			'beneficiary_split'      => ['type' => self::UINT, 'default' => 100, 'min' => 0, 'max' => 100],
			'num_ratings'            => ['type' => self::INT, 'default' => 0],
			'average_rating'         => ['type' => self::FLOAT, 'default' => 0],
			'positive_percent'       => ['type' => self::UINT, 'default' => 0],
			'negative_percent'       => ['type' => self::UINT, 'default' => 0],
			'neutral_percent'        => ['type' => self::UINT, 'default' => 0],
		];
		$structure->behaviors = [];
		$structure->getters = [
			'prefixes' => true,
		];
		$structure->relations = [
			'ThreadForum' => [
				'entity' => 'XF:Forum',
				'type' => self::TO_ONE,
				'conditions' => [
					['node_id', '=', '$thread_node_id']
				],
				'primary' => true,
				'with' => 'Node'
			],
			'Beneficiary' => [
				'entity' => 'XF:User',
				'type' => self::TO_ONE,
				'conditions' => [
					['user_id', '=', '$beneficiary']
				],
				'primary' => true
			],
			'LatestSale' => [
				'entity' => 'DBTech\Shop:Item',
				'type' => self::TO_ONE,
				'conditions' => [
					['item_id', '=', '$latest_sale_id']
				],
				'primary' => true
			],
			'LatestCustomer' => [
				'entity' => 'XF:User',
				'type' => self::TO_ONE,
				'conditions' => [
					['user_id', '=', '$latest_customer_id']
				],
				'primary' => true
			],
			'Watch' => [
				'entity' => 'DBTech\Shop:CategoryWatch',
				'type' => self::TO_MANY,
				'conditions' => 'category_id',
				'key' => 'user_id'
			]
		];
		$structure->options = [
			'delete_items' => true
		];
		
		static::addCategoryTreeStructureElements($structure);
		
		return $structure;
	}
	
	/**
	 * @return \DBTech\Shop\Repository\Category|\XF\Mvc\Entity\Repository
	 */
	protected function getCategoryRepo()
	{
		return $this->repository('DBTech\Shop:Category');
	}
}