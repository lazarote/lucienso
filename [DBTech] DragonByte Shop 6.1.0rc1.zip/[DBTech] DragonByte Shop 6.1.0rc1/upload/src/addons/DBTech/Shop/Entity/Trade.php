<?php

namespace DBTech\Shop\Entity;

use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;

/**
 * COLUMNS
 * @property int trade_id
 * @property int creator_user_id
 * @property string creator_username
 * @property int recipient_user_id
 * @property string recipient_username
 * @property int created_date
 * @property int updated_date
 * @property string trade_state
 * @property bool creator_accepted
 * @property bool recipient_accepted
 * @property int conversation_id
 *
 * GETTERS
 * @property \XF\Phrase title
 * @property string other_username
 *
 * RELATIONS
 * @property \DBTech\Shop\Entity\TradeOffer[] Offers
 * @property \XF\Entity\User Creator
 * @property \XF\Entity\User Recipient
 * @property \XF\Entity\ConversationMaster Conversation
 */
class Trade extends Entity
{
	/**
	 * @return \XF\Phrase
	 */
	public function getTitle()
	{
		return \XF::phrase('dbtech_shop_trade_x_y_with_z', [
			'tradeId' => $this->trade_id,
			'creator' => $this->Creator->username,
			'recipient' => $this->Recipient->username,
		]);;
	}
	
	/**
	 * @return string
	 */
	public function getOtherUsername()
	{
		return ($this->creator_user_id == \XF::visitor()->user_id
			? $this->recipient_username
			: $this->creator_username
		);
	}
	
	/**
	 * @return bool
	 */
	public function canView()
	{
		return $this->isParticipant();
	}
	
	/**
	 * @return bool
	 */
	public function canEdit()
	{
		return (
			($this->trade_state != 'pending' || $this->creator_user_id == \XF::visitor()->user_id)
			&& $this->trade_state != 'accepted'
		);
	}
	
	/**
	 * @param null $error
	 *
	 * @return bool
	 */
	public function canAcceptInvite(&$error = null)
	{
		if ($this->trade_state != 'pending')
		{
			$error = \XF::phraseDeferred('dbtech_shop_trade_not_pending');
			return false;
		}
		
		if ($this->recipient_user_id != \XF::visitor()->user_id)
		{
			$error = \XF::phraseDeferred('dbtech_shop_not_your_trade_to_accept_invite');
			return false;
		}
		
		return true;
	}
	
	/**
	 * @param null $error
	 *
	 * @return bool
	 */
	public function canAccept(&$error = null)
	{
		if (!in_array($this->trade_state, ['open', 'awaiting_accept']))
		{
			$error = \XF::phraseDeferred('dbtech_shop_trade_not_awaiting_accept');
			return false;
		}
		
		if (!$this->isParticipant())
		{
			$error = \XF::phraseDeferred('dbtech_shop_not_your_trade_to_accept');
			return false;
		}
		
		return true;
	}
	
	/**
	 * @param null $error
	 *
	 * @return bool
	 */
	public function canCancel(&$error = null)
	{
		if (!$this->isParticipant())
		{
			$error = \XF::phraseDeferred('dbtech_shop_not_your_trade_to_cancel');
			return false;
		}
		
		if (in_array($this->trade_state, ['accepted', 'cancelled']))
		{
			$error = \XF::phraseDeferred('dbtech_shop_trade_finalised');
			return false;
		}
		
		return true;
	}
	
	/**
	 * @param null $error
	 *
	 * @return bool
	 */
	public function canViewPostsInTrade(&$error = null)
	{
		return $this->isParticipant() && \XF::visitor()->hasPermission('dbtechShopTradePost', 'view');
	}
	
	/**
	 * @return bool
	 */
	public function canViewDeletedPostsInTrade()
	{
		return \XF::visitor()->hasPermission('dbtechShopTradePost', 'viewDeleted');
	}
	
	/**
	 * @return bool
	 */
	public function canViewModeratedPostsInTrade()
	{
		return \XF::visitor()->hasPermission('dbtechShopTradePost', 'viewModerated');
	}
	
	/**
	 * @return bool
	 */
	public function canPostInTrade()
	{
		$visitor = \XF::visitor();
		
		return ($visitor->user_id
			&& $visitor->hasPermission('dbtechShopTradePost', 'view')
			&& $visitor->hasPermission('dbtechShopTradePost', 'post')
			&& $this->isParticipant()
		);
	}
	
	/**
	 * @return bool
	 */
	public function isParticipant()
	{
		$visitor = \XF::visitor();
		
		return ($this->creator_user_id == $visitor->user_id
			|| $this->recipient_user_id == $visitor->user_id
		);
	}
	
	/**
	 * @return bool
	 */
	public function hasAccepted()
	{
		return ($this->creator_user_id == \XF::visitor()->user_id
			? $this->creator_accepted
			: $this->recipient_accepted
		);
	}
	
	/**
	 * @return bool
	 */
	public function hasBothUsersAccepted()
	{
		return ($this->creator_accepted
			&& $this->recipient_accepted
		);
	}
	
	/**
	 * @param string $contentType
	 * @param int $contentId
	 * @param int $quantity
	 *
	 * @return TradeOffer
	 * @throws \InvalidArgumentException
	 */
	public function getNewTradeOffer($contentType, $contentId, $quantity = 1)
	{
		/** @var \DBTech\Shop\Entity\TradeOffer $tradeOffer */
		$tradeOffer = $this->_em->create('DBTech\Shop:TradeOffer');
		
		$tradeOffer->trade_id = $this->trade_id;
		$tradeOffer->hydrateRelation('Trade', $this);
		
		$tradeOffer->user_id = \XF::visitor()->user_id;
		$tradeOffer->content_type = $contentType;
		$tradeOffer->content_id = $contentId;
		$tradeOffer->quantity = $quantity;
		
		return $tradeOffer;
	}
	
	/**
	 * @return TradePost|Entity
	 */
	public function getNewTradePost()
	{
		$tradePost = $this->_em->create('DBTech\Shop:TradePost');
		$tradePost->trade_id = $this->trade_id;
		
		return $tradePost;
	}
	
	/**
	 * @param $amount
	 * @param null $userId
	 *
	 * @throws \XF\Db\Exception
	 */
	protected function adjustUserPendingTradeCountIfNeeded($amount, $userId = null)
	{
		if ($userId === null)
		{
			$userId = $this->creator_user_id;
		}
		
		if ($userId)
		{
			$this->db()->query('
				UPDATE xf_user
				SET dbtech_shop_pendingtrades = GREATEST(0, CAST(dbtech_shop_pendingtrades AS SIGNED) + ?)
				WHERE user_id = ?
			', [$amount, $userId]);
		}
	}
	
	/**
	 *
	 */
	protected function _preSave()
	{
		if ($this->isUpdate()
			&& !$this->isChanged('updated_date')
		)
		{
			$this->updated_date = \XF::$time;
		}
	}
	
	/**
	 * @throws \XF\Db\Exception
	 */
	protected function _postSave()
	{
		if ($this->isInsert())
		{
			$this->adjustUserPendingTradeCountIfNeeded(1, $this->creator_user_id);
			$this->adjustUserPendingTradeCountIfNeeded(1, $this->recipient_user_id);
		}
		else
		{
			// check for entering accepted/cancelled
			$acceptedChange = $this->isStateChanged('trade_state', 'accepted');
			$cancelledChange = $this->isStateChanged('trade_state', 'cancelled');
			
			if ($acceptedChange == 'enter')
			{
				$this->adjustUserPendingTradeCountIfNeeded(-1, $this->creator_user_id);
				$this->adjustUserPendingTradeCountIfNeeded(-1, $this->recipient_user_id);
			}
			else if ($cancelledChange == 'enter')
			{
				$this->adjustUserPendingTradeCountIfNeeded(-1, $this->creator_user_id);
				$this->adjustUserPendingTradeCountIfNeeded(-1, $this->recipient_user_id);
			}
		}
	}
	
	/**
	 * @param Structure $structure
	 *
	 * @return Structure
	 */
	public static function getStructure(Structure $structure)
	{
		$structure->table = 'xf_dbtech_shop_trade';
		$structure->shortName = 'DBTech\Shop:Trade';
		$structure->primaryKey = 'trade_id';
		$structure->columns = [
			'trade_id'           => ['type' => self::UINT, 'autoIncrement' => true],
			'creator_user_id'    => ['type' => self::UINT, 'required' => true],
			'creator_username'   => ['type' => self::STR, 'maxLength' => 50],
			'recipient_user_id'  => ['type' => self::UINT, 'required' => true],
			'recipient_username' => ['type' => self::STR, 'maxLength' => 50],
			'created_date'       => ['type' => self::UINT, 'default' => \XF::$time],
			'updated_date'       => ['type' => self::UINT, 'default' => \XF::$time],
			'trade_state'             => [
				'type'          => self::STR,
				'default'       => 'pending',
				'allowedValues' => ['pending', 'open', 'awaiting_accept', 'accepted', 'cancelled']
			],
			'creator_accepted'   => ['type' => self::BOOL, 'default' => false],
			'recipient_accepted' => ['type' => self::BOOL, 'default' => false],
			'conversation_id'    => ['type' => self::UINT, 'default' => 0],
		];
		$structure->getters = [
			'title' => true,
			'other_username' => true,
		];
		$structure->relations = [
			'Offers' => [
				'entity' => 'DBTech\Shop:TradeOffer',
				'type' => self::TO_MANY,
				'conditions' => 'trade_id',
				'with' => ['Trade', 'User']
			],
			'Creator' => [
				'entity' => 'XF:User',
				'type' => self::TO_ONE,
				'conditions' => [
					['user_id', '=', '$creator_user_id']
				],
				'primary' => true
			],
			'Recipient' => [
				'entity' => 'XF:User',
				'type' => self::TO_ONE,
				'conditions' => [
					['user_id', '=', '$recipient_user_id']
				],
				'primary' => true
			],
			'Conversation' => [
				'entity' => 'XF:ConversationMaster',
				'type' => self::TO_ONE,
				'conditions' => 'conversation_id',
				'primary' => true
			],
		];

		return $structure;
	}
}