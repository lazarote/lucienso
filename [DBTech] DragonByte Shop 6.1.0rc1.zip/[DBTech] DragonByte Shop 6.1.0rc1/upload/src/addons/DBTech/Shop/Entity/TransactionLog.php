<?php

namespace DBTech\Shop\Entity;

use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;

/**
 * COLUMNS
 * @property int transaction_log_id
 * @property int user_id
 * @property int recipient_user_id
 * @property int dateline
 * @property int ip_id
 * @property string action
 * @property string content_type
 * @property int content_id
 * @property array info
 *
 * RELATIONS
 * @property \XF\Entity\User User
 * @property \XF\Entity\User Recipient
 * @property \XF\Entity\Ip Ip
 */
class TransactionLog extends Entity
{
	/**
	 * @return \XF\Mvc\Entity\ArrayCollection|Entity|null
	 */
	public function getContent()
	{
		return \XF::app()->findByContentType($this->content_type, $this->content_id);
	}
	
	/**
	 * @param Structure $structure
	 *
	 * @return Structure
	 */
	public static function getStructure(Structure $structure)
	{
		$structure->table = 'xf_dbtech_shop_transaction_log';
		$structure->shortName = 'DBTech\Shop:TransactionLog';
		$structure->primaryKey = 'transaction_log_id';
		$structure->columns = [
			'transaction_log_id' => ['type' => self::UINT, 'autoIncrement' => true],
			'user_id'            => ['type' => self::UINT, 'required' => true],
			'recipient_user_id'  => ['type' => self::UINT, 'required' => true],
			'dateline'           => ['type' => self::UINT, 'default' => \XF::$time],
			'ip_id'              => ['type' => self::UINT, 'default' => 0],
			'action'             => ['type' => self::STR, 'required' => true],
			'content_type'       => ['type' => self::STR, 'maxLength' => 25, 'default' => ''],
			'content_id'         => ['type' => self::UINT, 'default' => 0],
			'info'               => ['type' => self::JSON_ARRAY, 'default' => []],
		];
		$structure->relations = [
			'User' => [
				'entity' => 'XF:User',
				'type' => self::TO_ONE,
				'conditions' => 'user_id',
				'primary' => true
			],
			'Recipient' => [
				'entity' => 'XF:User',
				'type' => self::TO_ONE,
				'conditions' => [
					['user_id', '=', '$recipient_user_id']
				],
				'primary' => true
			],
			'Ip' => [
				'entity' => 'XF:Ip',
				'type' => self::TO_ONE,
				'conditions' => 'ip_id',
				'primary' => true
			]
		];

		return $structure;
	}
}