<?php

namespace DBTech\Shop\XF\Entity;

use XF\Mvc\Entity\Structure;

/**
 * RELATIONS
 * @property \DBTech\Shop\Entity\ThreadBan[] DBTechShopThreadBans
 */
class Thread extends XFCP_Thread
{
	/**
	 * @throws \XF\PrintableException
	 */
	protected function _postSave()
	{
		$previous = parent::_postSave();

		if ($this->isUpdate())
		{
			return $previous;
		}

		if (!$this->user_id)
		{
			return $previous;
		}
		
		$container = \XF::app()->container();
		if (isset($container['dbtechShop.currencies']) && $currencies = $container['dbtechShop.currencies'])
		{
			/** @var \DBTech\Shop\Entity\Currency[]|\XF\Mvc\Entity\ArrayCollection $currencies */
			$currencies = $currencies->filter(function (\DBTech\Shop\Entity\Currency $currency)
			{
				if (!$currency->isActive())
				{
					return null;
				}
				
				if ($currency->isIntegrated())
				{
					return null;
				}
				
				if (!$currency->per_thread)
				{
					return null;
				}
				
				return $currency;
			})
			;
			
			$currencyRepo = $this->repository('DBTech\Shop:Currency');
			foreach ($currencies as $currency)
			{
				$currencyRepo->addCurrencyAmount(
					$currency,
					'perthread',
					$currency->per_thread,
					$this->User,
					'thread', $this->thread_id
				);
			}
		}

		return $previous;
	}
	
	/**
	 * @param null $error
	 *
	 * @return bool
	 */
	public function canView(&$error = null)
	{
		$visitor = \XF::visitor();
		
		$previous = parent::canView($error);
		if ($previous && $visitor->user_id && $this->DBTechShopThreadBans[$visitor->user_id])
		{
			return false;
		}

		return $previous;
	}
	
	/**
	 * @param Structure $structure
	 *
	 * @return Structure
	 */
	public static function getStructure(Structure $structure)
	{
		$structure = parent::getStructure($structure);
		
		$structure->relations['DBTechShopThreadBans'] = [
			'entity' => 'DBTech\Shop:ThreadBan',
			'type' => self::TO_MANY,
			'conditions' => 'thread_id',
			'key' => 'user_id'
		];
		
		$visitor = \XF::visitor();
		if ($visitor->user_id)
		{
			$structure->defaultWith[] = 'DBTechShopThreadBans|' . $visitor->user_id;
		}
		
		return $structure;
	}
}