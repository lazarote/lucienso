<?php

namespace DBTech\Shop\XF\Entity;

class Post extends XFCP_Post
{
	/**
	 * @throws \XF\PrintableException
	 */
	protected function _postSave()
	{
		$previous = parent::_postSave();

		if ($this->isUpdate() || $this->isFirstPost())
		{
			return $previous;
		}

		if (!$this->user_id)
		{
			return $previous;
		}
		
		$container = \XF::app()->container();
		if (isset($container['dbtechShop.currencies']) && $currencies = $container['dbtechShop.currencies'])
		{
			/** @var \DBTech\Shop\Entity\Currency[]|\XF\Mvc\Entity\ArrayCollection $currencies */
			$currencies = $currencies->filter(function (\DBTech\Shop\Entity\Currency $currency)
				{
					if (!$currency->isActive())
					{
						return null;
					}
					
					if ($currency->isIntegrated())
					{
						return null;
					}
					
					if (!$currency->per_reply)
					{
						return null;
					}
					
					return $currency;
				})
			;
			
			$currencyRepo = $this->repository('DBTech\Shop:Currency');
			foreach ($currencies as $currency)
			{
				$currencyRepo->addCurrencyAmount(
					$currency,
					'perreply',
					$currency->per_reply,
					$this->User,
					'post', $this->post_id
				);
			}
		}

		return $previous;
	}
}