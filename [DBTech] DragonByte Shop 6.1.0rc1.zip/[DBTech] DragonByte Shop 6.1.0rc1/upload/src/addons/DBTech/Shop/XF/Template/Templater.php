<?php

namespace DBTech\Shop\XF\Template;

use XF\Mvc\Entity\ArrayCollection;

class Templater extends XFCP_Templater
{
	/**
	 * @param $templater
	 * @param $escape
	 * @param $user
	 * @param bool $withBanner
	 * @param array $attributes
	 *
	 * @return string
	 */
	public function fnUserTitle($templater, &$escape, $user, $withBanner = false, $attributes = [])
	{
		/** @var \DBTech\Shop\XF\Entity\User $user */
		
		$userIsValid = ($user instanceof \XF\Entity\User);
		if (!$userIsValid)
		{
			return parent::fnUserTitle($templater, $escape, $user, $withBanner, $attributes);
		}
		
		/** @var \DBTech\Shop\XF\Entity\User $user */
		
		if (!$user->user_id)
		{
			return parent::fnUserTitle($templater, $escape, $user, $withBanner, $attributes);
		}
		
		if (!empty($attributes['preview']))
		{
			return parent::fnUserTitle($templater, $escape, $user, $withBanner, $attributes);
		}
		
		$classes = [];
		
		/** @var \DBTech\Shop\Entity\Purchase[]|ArrayCollection $purchases */
		$purchases = \XF::repository('DBTech\Shop:Purchase')->filterActivePurchasesForUser($user);
		
		foreach ($purchases as $purchase)
		{
			$handler = $purchase->handler;
			$handler->fire('user_title_style_classes', [&$classes]);
		}

		if ($classes)
		{
			// Make sure this is set
			$attributes['class'] = isset($attributes['class']) ? $attributes['class'] : '';

			// Ensure we only add the span if needed
			$attributes['class'] .= ' ' . implode(' ', $classes);
		}

		return parent::fnUserTitle($templater, $escape, $user, $withBanner, $attributes);
	}
	
	/**
	 * @param $templater
	 * @param $escape
	 * @param $user
	 * @param bool $includeGroupStyling
	 *
	 * @return string
	 */
	public function fnUsernameClasses($templater, &$escape, $user, $includeGroupStyling = true)
	{
		$parentClasses = parent::fnUsernameClasses($templater, $escape, $user, $includeGroupStyling);
		
		if (empty($user['user_id']))
		{
			return $parentClasses;
		}
		
		$userIsValid = ($user instanceof \XF\Entity\User);
		if (!$userIsValid)
		{
			if (!\XF::options()->dbtech_shop_forceformatting)
			{
				return $parentClasses;
			}
			
			/** @var \DBTech\Shop\XF\Entity\User $user */
			$user = \XF::em()->find('XF:User', $user['user_id']);
		}
		
		if (!$user)
		{
			return $parentClasses;
		}
		
		
		$classes = [];
		
		/** @var \DBTech\Shop\Entity\Purchase[]|ArrayCollection $purchases */
		$purchases = \XF::repository('DBTech\Shop:Purchase')->filterActivePurchasesForUser($user);
		
		foreach ($purchases as $purchase)
		{
			$handler = $purchase->handler;
			$handler->fire('username_style_classes', [&$classes]);
		}
		
		$escape = false; // note: not doing this explicitly, shouldn't be needed for the output format
		
		if (empty($classes))
		{
			return $parentClasses;
		}
		
		return $parentClasses . ' ' . implode(' ', $classes);
	}
}