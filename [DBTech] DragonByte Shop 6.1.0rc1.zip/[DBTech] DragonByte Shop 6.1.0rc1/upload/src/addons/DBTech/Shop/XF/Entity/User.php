<?php

namespace DBTech\Shop\XF\Entity;

use XF\Mvc\Entity\ArrayCollection;
use XF\Mvc\Entity\Structure;
use XF\Mvc\Entity\Entity;

/**
 * COLUMNS
 * @property mixed|null dbtech_shop_purchase_
 * @property int dbtech_shop_purchases
 * @property int dbtech_shop_immunity
 * @property int dbtech_shop_pendingtrades
 *
 * GETTERS
 * @property float dbtech_shop_currency
 * @property ArrayCollection dbtech_shop_purchase
 */
class User extends XFCP_User
{
	/**
	 * @param null $error
	 * @return bool
	 */
	public function canViewDbtechShopItems(&$error = null)
	{
		return $this->hasPermission('dbtech_shop', 'view');
	}
	
	/**
	 * @param null $error
	 * @return bool
	 */
	public function canPurchaseDbtechShopItems(&$error = null)
	{
		return $this->hasPermission('dbtech_shop', 'purchase');
	}
	
	/**
	 * @param null $error
	 * @return bool
	 */
	public function canUseDbtechShopBank(&$error = null)
	{
		return $this->hasPermission('dbtech_shop', 'bank');
	}
	
	/**
	 * @param null $error
	 * @return bool
	 */
	public function canUseDbtechShopSteal(&$error = null)
	{
		return $this->hasPermission('dbtech_shop', 'steal');
	}
	
	/**
	 * @param null $error
	 * @return bool
	 */
	public function canUseDbtechShopTrade(&$error = null)
	{
		return $this->hasPermission('dbtech_shop', 'trade');
	}
	
	/**
	 * @param null $error
	 * @return bool
	 */
	public function canViewDbtechShopLotteries(&$error = null)
	{
		return $this->hasPermission('dbtech_shop', 'viewLottery');
	}
	
	/**
	 * @param null $error
	 * @return bool
	 */
	public function canViewDbtechShopTradePosts(&$error = null)
	{
		return $this->hasPermission('dbtechShopTradePost', 'view');
	}
	
	/**
	 * @param null $error
	 * @return bool
	 */
	public function canAddDbtechShopItem(&$error = null)
	{
		return ($this->user_id && $this->hasPermission('dbtech_shop', 'add'));
	}
	
	/**
	 * @param $contentId
	 * @param $permission
	 *
	 * @return bool
	 */
	public function hasDbtechShopCategoryPermission($contentId, $permission)
	{
		return $this->PermissionSet->hasContentPermission('dbtech_shop_category', $contentId, $permission);
	}
	
	/**
	 * @param $contentId
	 * @param $permission
	 *
	 * @return bool
	 */
	public function hasDbtechShopItemPermission($contentId, $permission)
	{
		return $this->PermissionSet->hasContentPermission('dbtech_shop_item', $contentId, $permission);
	}
	
	/**
	 * @param \DBTech\Shop\Entity\Currency $currency
	 *
	 * @return mixed|null
	 */
	public function getDbtechShopCurrency(\DBTech\Shop\Entity\Currency $currency)
	{
		if (!$this->offsetExists($currency->column))
		{
			throw new \LogicException("Attempted to access column {$currency->column} on user, which did not exist.");
		}
		
		return $this->{$currency->column};
	}
	
	/**
	 * @return ArrayCollection
	 * @throws \XF\PrintableException
	 */
	public function getDbtechShopPurchase()
	{
		if (!$this->user_id)
		{
			// Don't do it for guests, but allow this to be transformed into a member later
			return $this->_em->getEmptyCollection();
		}
		
		// Check the raw values, since normal getter will convert into an empty array, which is a valid value
		if (array_key_exists('dbtech_shop_purchase', $this->_newValues))
		{
			$purchases = $this->_newValues['dbtech_shop_purchase'];
		}
		else if (array_key_exists('dbtech_shop_purchase', $this->_values))
		{
			$purchases = $this->_values['dbtech_shop_purchase'];
		}
		else
		{
			$purchases = null;
		}
		
		if ($purchases === null)
		{
			// Raw value is null, so rebuild the cache and get the resulting array
			$purchaseRepo = $this->repository('DBTech\Shop:Purchase');
			$purchases = $purchaseRepo->rebuildCacheForUser($this);
		}
		else
		{
			// Raw value is not null, so we have a valid value. Fetch the source decoded value (i.e. an array)
			$purchases = $this->dbtech_shop_purchase_;
		}
		
		$container = $this->app()->container();
		
		if (!isset($container['dbtechShop.items']))
		{
			$container['dbtechShop.items'] = $this->finder('DBTech\Shop:Item')
				->forFullView()
				->fetch()
			;
		}
		
		/** @var ArrayCollection $items */
		$items = $container['dbtechShop.items'];
		
		$entities = [];
		foreach ($purchases as $purchaseId => $purchase)
		{
			/** @var \DBTech\Shop\Entity\Purchase $purchaseEntity */
			$purchaseEntity = $this->_em->instantiateEntity('DBTech\Shop:Purchase', $purchase);
			
			// Add User entity to the Purchase entity
			$purchaseEntity->hydrateRelation('User', $this);
			
			if ($items !== NULL)
			{
				if (!$items->offsetExists($purchaseEntity->item_id))
				{
					$purchaseEntity->delete(false);
					continue;
				}
				
				// Add Item entity to the Purchase entity
				$purchaseEntity->hydrateRelation('Item', $items->offsetGet($purchaseEntity->item_id));
			}
			
			$entities[$purchaseId] = $purchaseEntity;
		}
		
		return $this->_em->getBasicCollection($entities);
	}
	
	/**
	 * @param $group
	 * @param $permission
	 *
	 * @return bool
	 */
	public function hasPermission($group, $permission)
	{
		$retval = parent::hasPermission($group, $permission);
		
		if (!$this->user_id)
		{
			// Don't do it for guests, but allow this to be transformed into a member later
			return $retval;
		}
		
		/** @var \DBTech\Shop\Entity\Purchase[]|ArrayCollection $purchases */
		$purchases = $this->repository('DBTech\Shop:Purchase')
			->filterActivePurchasesForUser($this)
		;
		foreach ($purchases as $purchase)
		{
			$handler = $purchase->handler;
			$handler->fire('has_permission', [$group, $permission, &$retval]);
		}
		
		return $retval;
	}
	
	/**
	 * @param $contentType
	 * @param $contentId
	 * @param $permission
	 *
	 * @return bool
	 */
	public function hasContentPermission($contentType, $contentId, $permission)
	{
		$retval = parent::hasContentPermission($contentType, $contentId, $permission);
		
		if ($contentType == 'node')
		{
			/** @var \DBTech\Shop\Entity\Purchase[]|ArrayCollection $purchases */
			$purchases = $this->repository('DBTech\Shop:Purchase')
				->filterActivePurchasesForUser($this)
			;
			foreach ($purchases as $purchase)
			{
				$handler = $purchase->handler;
				$handler->fire('has_node_permission', [$contentId, $permission, &$retval], $contentId);
			}
		}
		
		return $retval;
	}
	
	/**
	 * @param $contentId
	 * @param $permission
	 *
	 * @return bool
	 */
	public function hasNodePermission($contentId, $permission)
	{
		$retval = parent::hasNodePermission($contentId, $permission);
		
		/** @var \DBTech\Shop\Entity\Purchase[]|ArrayCollection $purchases */
		$purchases = $this->repository('DBTech\Shop:Purchase')
			->filterActivePurchasesForUser($this)
		;
		foreach ($purchases as $purchase)
		{
			$handler = $purchase->handler;
			$handler->fire('has_node_permission', [$contentId, $permission, &$retval], $contentId);
		}
		
		return $retval;
	}
	
	/**
	 *
	 */
	protected function _preSave()
	{
		if ($this->isInsert() && !$this->isChanged('dbtech_shop_purchase'))
		{
			$this->dbtech_shop_purchase = [];
		}
		
		parent::_preSave();
	}
	
	/**
	 * @param bool $allowGetters
	 *
	 * @return array
	 */
	public function toArray($allowGetters = true)
	{
		$array = parent::toArray($allowGetters);
		
		if (!isset($array['dbtech_shop_purchase']))
		{
			return $array;
		}
		
		if ($array['dbtech_shop_purchase'] instanceof ArrayCollection)
		{
			$array['dbtech_shop_purchase'] = $this->dbtech_shop_purchase_;
		}
		
		return $array;
	}
	
	/**
	 * @param Structure $structure
	 *
	 * @return Structure
	 */
	public static function getStructure(Structure $structure)
	{
		$structure = parent::getStructure($structure);
		
		$structure->getters['dbtech_shop_currency'] = true;
		$structure->getters['dbtech_shop_purchase'] = true;
		
		$container = \XF::app()->container();
		if (isset($container['dbtechShop.currencies']) && $currencies = $container['dbtechShop.currencies'])
		{
			/** @var \DBTech\Shop\Entity\Currency[] $currencies */
			foreach ($currencies as $currencyId => $currency)
			{
				// Add all currencies matching
				$structure->columns[$currency->column] = ['type' => Entity::FLOAT, 'default' => 0, 'changeLog' => false];
			}
		}
		
		$structure->columns['dbtech_shop_purchase'] = ['type' => Entity::JSON_ARRAY, 'changeLog' => false];
		$structure->columns['dbtech_shop_purchases'] = ['type' => Entity::UINT, 'default' => 0, 'changeLog' => false];
		$structure->columns['dbtech_shop_immunity'] = ['type' => Entity::UINT, 'default' => 0, 'changeLog' => false];
		$structure->columns['dbtech_shop_pendingtrades'] = ['type' => Entity::UINT, 'default' => 0, 'changeLog' => false];
		$structure->columns['dbtech_shop_item_count'] = ['type' => Entity::UINT, 'default' => 0, 'changeLog' => false];
		
		return $structure;
	}
}